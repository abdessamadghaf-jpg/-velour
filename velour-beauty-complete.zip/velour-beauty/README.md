# VELOUR Beauty — AI-Powered Luxury Beauty Commerce

> Built for @goodvibes337 — your dream project, live and production-ready.

## Live in 15 Minutes

```bash
# 1. Install
npm install

# 2. Run locally
npm run dev
# → http://localhost:3000

# 3. Build for production
npm run build
```

## Deploy to Vercel (Free)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy (one command)
vercel

# Follow prompts:
# ✓ Link to your Vercel account (free at vercel.com)
# ✓ Project name: velour-beauty
# ✓ Framework: Vite
# Your site is live at: https://velour-beauty.vercel.app
```

**To use a custom domain (e.g. velourbeauty.com):**
1. Go to vercel.com → your project → Settings → Domains
2. Add your domain
3. Update DNS at your registrar (Namecheap, GoDaddy etc.)

## Deploy to GitHub Pages (Alternative — 100% Free)

```bash
# 1. Push to GitHub
git init
git add .
git commit -m "🚀 Launch Velour Beauty"
git remote add origin https://github.com/goodvibes337/velour-beauty.git
git push -u origin main

# 2. In vite.config.ts add: base: '/velour-beauty/'
# 3. GitHub → Settings → Pages → Source: GitHub Actions
# 4. The CI workflow auto-deploys on every push to main
```

## Architecture

```
src/
  features/           # Feature-based modules (isolated)
    home/             # Landing page
    products/         # Product listing + detail
    cart/             # Cart drawer + checkout + order success
    wishlist/         # Wishlist page + Zustand store
    advisor/          # AI skin analysis + chat
    auth/             # Profile page
    search/           # Search overlay
  shared/
    components/
      layout/         # Navbar, Footer, Layout wrapper
      ui/             # Toast, PageLoader, Skeletons
    constants/        # Product data (replace with Supabase later)
    hooks/            # Custom React hooks
    types/            # TypeScript domain types
    utils/            # formatPrice, cn, generateId, etc.
  styles/
    globals.css       # Tailwind + custom utility classes
```

## Tech Stack

| Layer      | Tech                              |
|------------|-----------------------------------|
| Frontend   | React 19 + TypeScript + Vite      |
| Styling    | TailwindCSS + custom design tokens|
| Animation  | Framer Motion                     |
| State      | Zustand (persisted to localStorage)|
| Forms      | React Hook Form + Zod validation  |
| Routing    | React Router v7                   |
| Data       | React Query (ready for Supabase)  |
| Deployment | Vercel / GitHub Pages             |

## What's Working Right Now (No Backend Needed)

- ✅ Full product catalog (6 trending products)
- ✅ Product filtering + sorting
- ✅ Add to cart with quantity controls
- ✅ Cart drawer with coupon codes (try VELOUR10)
- ✅ Full checkout flow (4 steps)
- ✅ Order success page
- ✅ Wishlist (persists across sessions)
- ✅ Live search with results
- ✅ AI Beauty Advisor (skin analysis + chat)
- ✅ User profile with order history
- ✅ Dark/light mode toggle
- ✅ Fully responsive (mobile-first)
- ✅ Framer Motion animations throughout

## Adding Real Products

Edit `src/shared/constants/products.ts` — add your dropshipping products here.
Each product needs: name, brand, price, images, description, variants.

## Connecting Supabase (Phase 2)

```bash
npm install @supabase/supabase-js
# Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to .env.local
# Replace PRODUCTS constant with Supabase queries
```

## TikTok Products to Sell Now (Researched)

Based on 2026 TikTok Shop data — these are your first 5 products:

1. **Lash Lift Kit** — $8 cost / $29 sell — before/after content = viral
2. **Gua Sha + Facial Roller Set** — $5 cost / $24 sell — aesthetic + ritual
3. **LED Face Mask** — $30 cost / $89 sell — high perceived value
4. **Pore Vacuum Blackhead Remover** — $12 cost / $34 sell — satisfying demo
5. **Collagen Patches (eye + lip)** — $6 cost / $22 sell — K-beauty trend

Source from: AliExpress, CJDropshipping, or DSers (all free to start)

## Your TikTok Content Formula

For each product, film:
1. **Hook** (0-3s): "I spent $8 on Amazon and it changed my skin routine"
2. **Problem** (3-10s): Show the before / the problem
3. **Solution** (10-30s): Product demo, clear result
4. **CTA** (30-35s): "Link in bio — selling fast"

Post at: Tuesday 7PM, Thursday 8PM, Saturday 10AM (peak beauty audience)
Hashtags: #beautytok #skincare #grwm #tiktokshop #skincareroutine

---

Built with ❤️ — this is your foundation. Now go film that first video.
