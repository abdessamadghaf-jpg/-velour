// src/App.tsx
import { lazy, Suspense, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { Layout } from '@/shared/components/layout/Layout'
import { PageLoader } from '@/shared/components/ui/PageLoader'
import { ToastContainer } from '@/shared/components/ui/Toast'
import { CartDrawer } from '@/features/cart/CartDrawer'
import { SearchOverlay } from '@/features/search/SearchOverlay'
import { useUIStore } from '@/features/wishlist/store'

// Lazy-loaded pages for code splitting
const HomePage       = lazy(() => import('@/features/home/HomePage'))
const ProductsPage   = lazy(() => import('@/features/products/ProductsPage'))
const ProductDetail  = lazy(() => import('@/features/products/ProductDetail'))
const WishlistPage   = lazy(() => import('@/features/wishlist/WishlistPage'))
const AdvisorPage    = lazy(() => import('@/features/advisor/AdvisorPage'))
const ProfilePage    = lazy(() => import('@/features/auth/ProfilePage'))
const CheckoutPage   = lazy(() => import('@/features/cart/CheckoutPage'))
const OrderSuccess   = lazy(() => import('@/features/cart/OrderSuccess'))
const NotFound       = lazy(() => import('@/shared/components/ui/NotFound'))

export default function App() {
  const { theme } = useUIStore()

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark')
  }, [theme])

  return (
    <>
      <Suspense fallback={<PageLoader />}>
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<HomePage />} />
            <Route path="products" element={<ProductsPage />} />
            <Route path="products/:handle" element={<ProductDetail />} />
            <Route path="wishlist" element={<WishlistPage />} />
            <Route path="advisor" element={<AdvisorPage />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="checkout" element={<CheckoutPage />} />
            <Route path="order-success" element={<OrderSuccess />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </Suspense>

      {/* Global overlays */}
      <CartDrawer />
      <SearchOverlay />
      <ToastContainer />
    </>
  )
}
