// src/shared/types/index.ts

// ── Product ──────────────────────────────────────────────────────────
export interface ProductImage {
  id: string
  url: string
  alt: string
  isPrimary: boolean
}

export interface ProductVariant {
  id: string
  name: string
  price: number
  compareAtPrice: number | null
  stock: number
  sku: string
}

export type SkinType = 'oily' | 'dry' | 'combination' | 'normal' | 'sensitive'
export type ProductCategory = 'serum' | 'moisturizer' | 'cleanser' | 'mask' | 'toner' | 'eye-care' | 'sunscreen' | 'treatment' | 'mist' | 'oil'
export type ProductGrade = 'A' | 'B' | 'C' | 'D'

export interface ProductIngredient {
  name: string
  benefit: string
  concentration?: string
}

export interface Product {
  id: string
  handle: string
  name: string
  brand: string
  tagline: string
  description: string
  category: ProductCategory
  skinTypes: SkinType[]
  concerns: string[]
  images: ProductImage[]
  variants: ProductVariant[]
  ingredients: ProductIngredient[]
  howToUse: string[]
  tags: string[]
  isTrending: boolean
  trendLabel: string | null
  trendScore: number // 0-100
  trendGrade: ProductGrade
  rating: number
  reviewCount: number
  isNew: boolean
  isBestSeller: boolean
  isLimitedEdition: boolean
  isVegan: boolean
  isCrueltyFree: boolean
  isClean: boolean
  availableForSale: boolean
  createdAt: string
}

// ── Cart ─────────────────────────────────────────────────────────────
export interface CartItem {
  id: string // cartItemId
  productId: string
  variantId: string
  product: Pick<Product, 'id' | 'name' | 'brand' | 'handle' | 'images'>
  variant: ProductVariant
  quantity: number
  addedAt: string
}

export interface Cart {
  id: string
  items: CartItem[]
  subtotal: number
  total: number
  discount: number
  couponCode: string | null
  checkoutUrl: string | null
}

// ── User / Auth ───────────────────────────────────────────────────────
export interface UserProfile {
  id: string
  email: string
  name: string
  avatarUrl: string | null
  skinType: SkinType | null
  skinConcerns: string[]
  birthYear: number | null
  rewardPoints: number
  tier: 'bronze' | 'silver' | 'gold' | 'platinum'
  createdAt: string
}

// ── Orders ────────────────────────────────────────────────────────────
export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded'

export interface OrderItem {
  productId: string
  productName: string
  variantName: string
  price: number
  quantity: number
  imageUrl: string
}

export interface Order {
  id: string
  orderNumber: string
  status: OrderStatus
  items: OrderItem[]
  subtotal: number
  shipping: number
  tax: number
  total: number
  shippingAddress: Address
  placedAt: string
  updatedAt: string
  trackingNumber: string | null
  estimatedDelivery: string | null
}

// ── Address ───────────────────────────────────────────────────────────
export interface Address {
  firstName: string
  lastName: string
  line1: string
  line2?: string
  city: string
  state: string
  postalCode: string
  country: string
}

// ── Review ────────────────────────────────────────────────────────────
export interface Review {
  id: string
  productId: string
  userId: string
  userName: string
  userAvatar: string | null
  rating: number
  title: string
  body: string
  verifiedPurchase: boolean
  helpful: number
  skinType: SkinType | null
  createdAt: string
}

// ── AI Advisor ────────────────────────────────────────────────────────
export interface SkinAnalysisResult {
  skinType: SkinType
  concerns: string[]
  hydrationLevel: number // 0-100
  oilinessLevel: number
  sensitivityLevel: number
  overallScore: number
  confidence: number
  recommendedProducts: Array<{
    product: Product
    reason: string
    priority: 'essential' | 'recommended' | 'optional'
  }>
  routine: {
    morning: RoutineStep[]
    evening: RoutineStep[]
    weekly: RoutineStep[]
  }
}

export interface RoutineStep {
  order: number
  product: Product
  instruction: string
  when: string
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: string
  products?: Product[]
  rating?: 1 | 2 | 3 | 4 | 5
}

// ── Wishlist ──────────────────────────────────────────────────────────
export interface WishlistItem {
  id: string
  productId: string
  product: Product
  addedAt: string
}

// ── Filter / Sort ─────────────────────────────────────────────────────
export type SortOption = 'relevance' | 'price-asc' | 'price-desc' | 'rating' | 'newest' | 'trending'

export interface ProductFilters {
  categories: ProductCategory[]
  skinTypes: SkinType[]
  concerns: string[]
  minPrice: number | null
  maxPrice: number | null
  brands: string[]
  tags: string[]
  onlyAvailable: boolean
  onlyNew: boolean
  onlyTrending: boolean
}

// ── UI ────────────────────────────────────────────────────────────────
export type Theme = 'light' | 'dark'

export interface NotificationToast {
  id: string
  type: 'success' | 'error' | 'info' | 'warning'
  title: string
  message?: string
  duration?: number
}
