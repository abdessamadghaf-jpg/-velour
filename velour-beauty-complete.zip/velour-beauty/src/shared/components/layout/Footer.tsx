// src/shared/components/layout/Footer.tsx
import { Link } from 'react-router-dom'
import { Instagram, Youtube } from 'lucide-react'

const FOOTER_LINKS = {
  Shop:    [{ to: '/products', label: 'All Products' }, { to: '/products?filter=trending', label: 'Trending' }, { to: '/products?filter=new', label: 'New Arrivals' }, { to: '/products?filter=bestseller', label: 'Bestsellers' }],
  Help:    [{ to: '/faq', label: 'FAQ' }, { to: '/shipping', label: 'Shipping' }, { to: '/returns', label: 'Returns' }, { to: '/contact', label: 'Contact' }],
  Company: [{ to: '/about', label: 'About VELOUR' }, { to: '/advisor', label: 'AI Advisor' }, { to: '/sustainability', label: 'Sustainability' }, { to: '/press', label: 'Press' }],
}

export function Footer() {
  return (
    <footer className="border-t border-white/5 bg-obsidian mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="font-display text-2xl tracking-[0.12em] text-ivory block mb-4">
              VELOUR
            </Link>
            <p className="text-sm text-ivory/40 leading-relaxed max-w-xs mb-6">
              Luxury AI-powered beauty. Products selected by real trend intelligence, not paid placements.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-ivory/40 hover:text-gold hover:bg-gold/10 transition-all">
                <Instagram className="w-3.5 h-3.5" />
              </a>
              <a href="#" className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-ivory/40 hover:text-gold hover:bg-gold/10 transition-all">
                <Youtube className="w-3.5 h-3.5" />
              </a>
              <a href="#" className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-ivory/40 hover:text-gold hover:bg-gold/10 transition-all text-xs font-bold">
                TK
              </a>
            </div>
          </div>

          {Object.entries(FOOTER_LINKS).map(([section, links]) => (
            <div key={section}>
              <h4 className="label-luxury mb-4">{section}</h4>
              <ul className="space-y-2.5">
                {links.map(link => (
                  <li key={link.to}>
                    <Link to={link.to} className="text-sm text-ivory/40 hover:text-ivory transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-ivory/25">© 2026 VELOUR Beauty. All rights reserved.</p>
          <div className="flex gap-6">
            {['Privacy', 'Terms', 'Accessibility'].map(item => (
              <Link key={item} to="#" className="text-xs text-ivory/25 hover:text-ivory/60 transition-colors">
                {item}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
