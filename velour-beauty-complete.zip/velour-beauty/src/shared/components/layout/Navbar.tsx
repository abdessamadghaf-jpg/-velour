// src/shared/components/layout/Navbar.tsx
import { useState, useEffect } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { ShoppingBag, Search, Heart, Sun, Moon, Menu, X, Sparkles } from 'lucide-react'
import { useCartStore } from '@/features/cart/store'
import { useWishlistStore, useUIStore } from '@/features/wishlist/store'
import { cn } from '@/shared/utils'

const NAV_LINKS = [
  { to: '/products', label: 'Shop' },
  { to: '/products?category=serum', label: 'Serums' },
  { to: '/products?category=mask', label: 'Masks' },
  { to: '/advisor', label: 'AI Advisor' },
]

export function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const { cart, openCart } = useCartStore()
  const { items: wishlistItems } = useWishlistStore()
  const { theme, toggleTheme, openSearch } = useUIStore()
  const location = useLocation()

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', handler, { passive: true })
    return () => window.removeEventListener('scroll', handler)
  }, [])

  useEffect(() => { setMobileOpen(false) }, [location.pathname])

  const cartCount = cart.items.reduce((s, i) => s + i.quantity, 0)

  return (
    <>
      <motion.header
        initial={{ y: -80 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-500',
          scrolled
            ? 'bg-obsidian/90 backdrop-blur-xl border-b border-white/5 shadow-luxury'
            : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16 sm:h-20">
            {/* Logo */}
            <Link to="/" className="group flex items-center gap-2">
              <motion.span
                className="font-display text-2xl sm:text-3xl font-light tracking-[0.12em] text-ivory"
                whileHover={{ letterSpacing: '0.18em' }}
                transition={{ duration: 0.3 }}
              >
                VELOUR
              </motion.span>
            </Link>

            {/* Desktop nav */}
            <nav className="hidden md:flex items-center gap-8">
              {NAV_LINKS.map(link => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  className={({ isActive }) => cn(
                    'relative text-sm font-medium transition-colors duration-200',
                    isActive ? 'text-gold' : 'text-ivory/60 hover:text-ivory'
                  )}
                >
                  {({ isActive }) => (
                    <>
                      {link.label}
                      {isActive && (
                        <motion.div
                          layoutId="nav-indicator"
                          className="absolute -bottom-1 left-0 right-0 h-px bg-gradient-gold"
                        />
                      )}
                    </>
                  )}
                </NavLink>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-1 sm:gap-2">
              <button
                onClick={openSearch}
                className="btn-icon text-ivory/60 hover:text-ivory transition-colors"
                aria-label="Search"
              >
                <Search className="w-4 h-4" />
              </button>

              <button
                onClick={toggleTheme}
                className="btn-icon text-ivory/60 hover:text-ivory transition-colors hidden sm:flex"
                aria-label="Toggle theme"
              >
                {theme === 'dark'
                  ? <Sun className="w-4 h-4" />
                  : <Moon className="w-4 h-4" />
                }
              </button>

              <Link to="/wishlist" className="btn-icon relative text-ivory/60 hover:text-ivory transition-colors">
                <Heart className="w-4 h-4" />
                {wishlistItems.length > 0 && (
                  <motion.span
                    initial={{ scale: 0 }} animate={{ scale: 1 }}
                    className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-gold text-obsidian text-[9px] font-bold flex items-center justify-center"
                  >
                    {wishlistItems.length}
                  </motion.span>
                )}
              </Link>

              <button
                onClick={openCart}
                className="btn-icon relative text-ivory/60 hover:text-ivory transition-colors"
                aria-label="Cart"
              >
                <ShoppingBag className="w-4 h-4" />
                <AnimatePresence>
                  {cartCount > 0 && (
                    <motion.span
                      key={cartCount}
                      initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}
                      className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-gold text-obsidian text-[9px] font-bold flex items-center justify-center"
                    >
                      {cartCount > 9 ? '9+' : cartCount}
                    </motion.span>
                  )}
                </AnimatePresence>
              </button>

              <Link to="/advisor" className="hidden sm:flex btn-gold btn-sm ml-2 gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                AI Advisor
              </Link>

              {/* Mobile menu */}
              <button
                onClick={() => setMobileOpen(o => !o)}
                className="md:hidden btn-icon text-ivory/60 hover:text-ivory"
                aria-label="Menu"
              >
                {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-40 bg-obsidian/98 backdrop-blur-xl flex flex-col items-center justify-center gap-8"
          >
            {NAV_LINKS.map((link, i) => (
              <motion.div
                key={link.to}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
              >
                <NavLink
                  to={link.to}
                  className={({ isActive }) => cn(
                    'font-display text-4xl font-light italic',
                    isActive ? 'text-gold' : 'text-ivory/70 hover:text-ivory'
                  )}
                >
                  {link.label}
                </NavLink>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
