// src/shared/components/ui/PageLoader.tsx
import { motion } from 'framer-motion'

export function PageLoader() {
  return (
    <div className="fixed inset-0 bg-obsidian z-[300] flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center gap-6"
      >
        <motion.span
          className="font-display text-3xl tracking-[0.15em] text-ivory"
          animate={{ opacity: [0.4, 1, 0.4] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        >
          VELOUR
        </motion.span>
        <div className="flex gap-1.5">
          {[0, 1, 2].map(i => (
            <motion.div
              key={i}
              className="w-1.5 h-1.5 rounded-full bg-gold"
              animate={{ opacity: [0.2, 1, 0.2], scale: [0.8, 1.2, 0.8] }}
              transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
            />
          ))}
        </div>
      </motion.div>
    </div>
  )
}

// src/shared/components/ui/NotFound.tsx
export function NotFound() {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4">
      <p className="font-display text-[10rem] font-light text-white/5 leading-none select-none">404</p>
      <h1 className="font-display text-display-lg text-ivory -mt-8 mb-4">Page not found</h1>
      <p className="text-ivory/40 mb-8">The page you're looking for has been moved or doesn't exist.</p>
      <a href="/" className="btn-gold">Return Home</a>
    </div>
  )
}

// Skeleton components
export function ProductCardSkeleton() {
  return (
    <div className="space-y-3">
      <div className="skeleton aspect-[3/4] rounded-2xl" />
      <div className="skeleton h-3 w-16 rounded-lg" />
      <div className="skeleton h-4 w-full rounded-lg" />
      <div className="skeleton h-3 w-24 rounded-lg" />
    </div>
  )
}

export function ProductGridSkeleton({ count = 8 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <ProductCardSkeleton key={i} />
      ))}
    </div>
  )
}

export function TextSkeleton({ lines = 3 }: { lines?: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: lines }).map((_, i) => (
        <div
          key={i}
          className="skeleton h-4 rounded-lg"
          style={{ width: `${100 - (i * 15) % 40}%` }}
        />
      ))}
    </div>
  )
}
