// src/shared/components/ui/NotFound.tsx
export { NotFound as default } from './PageLoader'
