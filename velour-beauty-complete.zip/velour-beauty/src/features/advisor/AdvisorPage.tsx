// src/features/advisor/AdvisorPage.tsx
import { useState, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Sparkles, Upload, Send, Star, Loader, ChevronRight, RotateCcw } from 'lucide-react'
import { Link } from 'react-router-dom'
import { PRODUCTS } from '@/shared/constants/products'
import { formatPrice, generateId, cn } from '@/shared/utils'
import type { ChatMessage } from '@/shared/types'

// ── Skin Analysis ─────────────────────────────────────────────────────
function SkinAnalysisSection() {
  const [step, setStep] = useState<'upload' | 'analyzing' | 'results'>('upload')
  const [preview, setPreview] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  function handleFile(file: File) {
    if (!file.type.startsWith('image/')) return
    const reader = new FileReader()
    reader.onload = e => {
      setPreview(e.target?.result as string)
      setStep('analyzing')
      setTimeout(() => setStep('results'), 3200)
    }
    reader.readAsDataURL(file)
  }

  const mockResults = {
    skinType: 'Combination',
    hydration: 68,
    oiliness: 72,
    sensitivity: 35,
    concerns: ['Enlarged pores', 'Minor dehydration', 'Slight texture unevenness'],
    confidence: 89,
    recommended: [PRODUCTS[0], PRODUCTS[1], PRODUCTS[4]],
    reasons: [
      'AHA/BHA in Zero Pore Pad targets your enlarged pores directly.',
      'Bio-Collagen Mask addresses the dehydration your T-zone shows.',
      'Glycolic Acid Toner will smooth the texture unevenness detected.',
    ],
  }

  return (
    <div className="mb-16">
      <div className="card-gold rounded-3xl p-8 sm:p-10">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gold/20 border border-gold/30 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-gold" />
          </div>
          <div>
            <h2 className="font-display text-2xl italic text-ivory">AI Skin Analysis</h2>
            <p className="text-xs text-ivory/30">Powered by computer vision · Results in seconds</p>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {step === 'upload' && (
            <motion.div key="upload" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <input ref={fileRef} type="file" accept="image/*" className="hidden"
                onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
              <div
                onClick={() => fileRef.current?.click()}
                onDragOver={e => e.preventDefault()}
                onDrop={e => { e.preventDefault(); e.dataTransfer.files[0] && handleFile(e.dataTransfer.files[0]) }}
                className="border-2 border-dashed border-gold/20 rounded-2xl p-12 text-center cursor-pointer hover:border-gold/40 hover:bg-gold/5 transition-all"
              >
                <Upload className="w-10 h-10 text-gold/40 mx-auto mb-4" />
                <p className="text-ivory/50 mb-1">Drop a photo of your skin here</p>
                <p className="text-xs text-ivory/20">or click to upload · JPG, PNG, HEIC · Private & secure</p>
                <button className="btn-outline btn-sm mt-6">Choose Photo</button>
              </div>

              <div className="grid grid-cols-3 gap-4 mt-6">
                {[
                  { icon: '🔒', label: 'Private', sub: 'Never stored or shared' },
                  { icon: '⚡', label: 'Instant', sub: 'Results in 3 seconds' },
                  { icon: '🎯', label: 'Precise', sub: '89%+ accuracy' },
                ].map(f => (
                  <div key={f.label} className="card-glass p-3 text-center">
                    <div className="text-xl mb-1">{f.icon}</div>
                    <p className="text-xs font-medium text-ivory">{f.label}</p>
                    <p className="text-[10px] text-ivory/25">{f.sub}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {step === 'analyzing' && (
            <motion.div key="analyzing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="flex flex-col items-center py-16">
              {preview && (
                <div className="w-32 h-32 rounded-2xl overflow-hidden mb-8 relative">
                  <img src={preview} alt="" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-obsidian/60 to-transparent" />
                  <motion.div
                    animate={{ top: ['0%', '100%', '0%'] }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
                    className="absolute left-0 right-0 h-0.5 bg-gold/60"
                    style={{ boxShadow: '0 0 8px rgba(200,169,110,0.8)' }}
                  />
                </div>
              )}
              <div className="flex items-center gap-3 mb-4">
                <Loader className="w-4 h-4 text-gold animate-spin" />
                <p className="text-ivory/60 text-sm">Analysing skin characteristics…</p>
              </div>
              {['Detecting skin type', 'Measuring hydration', 'Identifying concerns', 'Matching products'].map((s, i) => (
                <motion.p key={s} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.6 }} className="text-xs text-gold/50 mb-1">
                  ✓ {s}
                </motion.p>
              ))}
            </motion.div>
          )}

          {step === 'results' && (
            <motion.div key="results" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <div className="grid sm:grid-cols-2 gap-6 mb-8">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <p className="label-luxury">Analysis Results</p>
                    <span className="badge-gold">{mockResults.confidence}% confidence</span>
                  </div>
                  <div className="card-glass p-5 space-y-4">
                    <div>
                      <p className="text-xs text-ivory/30 mb-1">Skin Type</p>
                      <p className="text-lg font-display italic text-ivory">{mockResults.skinType}</p>
                    </div>
                    {[
                      { label: 'Hydration', value: mockResults.hydration },
                      { label: 'Oiliness', value: mockResults.oiliness },
                      { label: 'Sensitivity', value: mockResults.sensitivity },
                    ].map(m => (
                      <div key={m.label}>
                        <div className="flex justify-between text-xs mb-1.5">
                          <span className="text-ivory/40">{m.label}</span>
                          <span className="text-ivory">{m.value}%</span>
                        </div>
                        <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                          <motion.div
                            className="h-full rounded-full bg-gradient-gold"
                            initial={{ width: 0 }}
                            animate={{ width: `${m.value}%` }}
                            transition={{ duration: 0.8, delay: 0.3 }}
                          />
                        </div>
                      </div>
                    ))}
                    <div>
                      <p className="text-xs text-ivory/30 mb-2">Concerns detected</p>
                      <div className="flex flex-wrap gap-1.5">
                        {mockResults.concerns.map(c => (
                          <span key={c} className="badge bg-red-500/10 text-red-400/80 border border-red-500/20 text-[10px]">{c}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <p className="label-luxury mb-4">Why these products</p>
                  <div className="space-y-3">
                    {mockResults.recommended.map((p, i) => (
                      <Link key={p.id} to={`/products/${p.handle}`}
                        className="flex items-center gap-3 card-glass p-3 hover:border-gold/30 transition-all group">
                        <div className="w-12 h-12 rounded-xl overflow-hidden shrink-0 bg-white/5">
                          <img src={p.images[0]?.url} alt="" className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-ivory truncate">{p.name}</p>
                          <p className="text-[10px] text-ivory/25 mt-0.5 line-clamp-2">{mockResults.reasons[i]}</p>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 text-ivory/15 group-hover:text-gold transition-colors shrink-0" />
                      </Link>
                    ))}
                  </div>
                </div>
              </div>

              <button
                onClick={() => { setStep('upload'); setPreview(null) }}
                className="flex items-center gap-2 text-xs text-ivory/30 hover:text-ivory transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Analyse a different photo
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

// ── AI Chat ───────────────────────────────────────────────────────────
const MOCK_RESPONSES: Record<string, string> = {
  default: "I'm VELOUR's AI Beauty Advisor. I can help you find the right products for your skin type, build a personalised routine, or answer ingredient questions. What would you like to know?",
  routine: "For a combination skin routine, I recommend starting with a gentle cleanser, followed by the Medicube Zero Pore Pad 3x per week, then a light hyaluronic serum, and finishing with an SPF 50. In the evening, swap SPF for the Biodance Collagen Mask once or twice per week.",
  peptide: "Copper peptides (GHK-Cu) are one of the most well-researched anti-aging ingredients. They signal your skin to produce more collagen and elastin, accelerate healing, and strengthen the barrier. The Lanmeri 1% GHK-Cu in our catalogue is an excellent entry point — gentler than retinoids with comparable long-term results.",
  pores: "For enlarged pores, I recommend AHA/BHA exfoliation. The Medicube Zero Pore Pad uses a 4% AHA complex that visibly refines pore size in 2-4 weeks. Consistency is key — use 3x per week and always follow with SPF the next morning.",
}

function getResponse(input: string): { text: string; products: typeof PRODUCTS } {
  const lower = input.toLowerCase()
  if (lower.includes('routine') || lower.includes('morning') || lower.includes('night')) {
    return { text: MOCK_RESPONSES.routine, products: [PRODUCTS[0], PRODUCTS[1]] }
  }
  if (lower.includes('peptide') || lower.includes('copper') || lower.includes('aging')) {
    return { text: MOCK_RESPONSES.peptide, products: [PRODUCTS[5]] }
  }
  if (lower.includes('pore') || lower.includes('texture')) {
    return { text: MOCK_RESPONSES.pores, products: [PRODUCTS[0]] }
  }
  return { text: MOCK_RESPONSES.default, products: [] }
}

function ChatSection() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '0', role: 'assistant', content: MOCK_RESPONSES.default, timestamp: new Date().toISOString() },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  async function sendMessage() {
    if (!input.trim() || loading) return
    const userMsg: ChatMessage = { id: generateId(), role: 'user', content: input, timestamp: new Date().toISOString() }
    const query = input
    setInput('')
    setMessages(m => [...m, userMsg])
    setLoading(true)

    await new Promise(r => setTimeout(r, 1200))
    const { text, products } = getResponse(query)
    const assistantMsg: ChatMessage = {
      id: generateId(), role: 'assistant', content: text,
      timestamp: new Date().toISOString(), products: products.length > 0 ? products : undefined,
    }
    setMessages(m => [...m, assistantMsg])
    setLoading(false)
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 100)
  }

  const SUGGESTIONS = ['Build my morning routine', 'What are peptides?', 'Help with enlarged pores', 'Sensitive skin products']

  return (
    <div className="card-glass rounded-3xl flex flex-col" style={{ height: '600px' }}>
      <div className="flex items-center gap-3 p-6 border-b border-white/5">
        <div className="w-9 h-9 rounded-xl bg-gold/20 border border-gold/30 flex items-center justify-center">
          <Sparkles className="w-4 h-4 text-gold" />
        </div>
        <div>
          <p className="text-sm font-semibold text-ivory">VELOUR Beauty Advisor</p>
          <p className="text-[10px] text-ivory/30">AI-powered · Grounded in real products</p>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[10px] text-ivory/30">Online</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-5 space-y-4 scrollbar-hide">
        <AnimatePresence initial={false}>
          {messages.map(msg => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn('flex', msg.role === 'user' ? 'justify-end' : 'justify-start')}
            >
              <div className={cn(
                'max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed',
                msg.role === 'user'
                  ? 'bg-gold text-obsidian font-medium'
                  : 'bg-white/5 border border-white/5 text-ivory/80'
              )}>
                <p>{msg.content}</p>
                {msg.products && msg.products.length > 0 && (
                  <div className="mt-3 space-y-2 pt-3 border-t border-white/10">
                    {msg.products.map(p => (
                      <Link key={p.id} to={`/products/${p.handle}`}
                        className="flex items-center gap-2.5 hover:opacity-80 transition-opacity">
                        <div className="w-8 h-8 rounded-lg overflow-hidden shrink-0">
                          <img src={p.images[0]?.url} alt="" className="w-full h-full object-cover" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-[11px] font-semibold text-ivory truncate">{p.name}</p>
                          <p className="text-[10px] text-ivory/40">{formatPrice(p.variants[0].price)} → View product</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          ))}
          {loading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
              <div className="bg-white/5 border border-white/5 rounded-2xl px-4 py-3 flex items-center gap-2">
                {[0, 1, 2].map(i => (
                  <motion.div key={i} className="w-1.5 h-1.5 rounded-full bg-gold/50"
                    animate={{ opacity: [0.3, 1, 0.3], scale: [0.8, 1.2, 0.8] }}
                    transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.2 }} />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={bottomRef} />
      </div>

      <div className="p-4 border-t border-white/5 space-y-3">
        <div className="flex flex-wrap gap-1.5">
          {SUGGESTIONS.map(s => (
            <button key={s} onClick={() => setInput(s)}
              className="text-[10px] px-2.5 py-1 rounded-full bg-white/5 text-ivory/30 hover:text-ivory hover:bg-white/10 transition-all">
              {s}
            </button>
          ))}
        </div>
        <form onSubmit={e => { e.preventDefault(); sendMessage() }} className="flex gap-2">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="Ask about your skin, ingredients, routines…"
            className="input-luxury flex-1 text-sm"
          />
          <button type="submit" disabled={!input.trim() || loading}
            className="btn-gold btn-icon shrink-0 disabled:opacity-30">
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  )
}

// ── Page ──────────────────────────────────────────────────────────────
export default function AdvisorPage() {
  return (
    <div className="min-h-screen py-16 px-4 sm:px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="mb-12 text-center">
          <p className="label-luxury mb-3">AI-Powered</p>
          <h1 className="font-display font-light text-display-xl text-ivory mb-4">
            Your personal <em className="text-gradient-gold">Beauty Advisor</em>
          </h1>
          <p className="text-ivory/40 max-w-lg mx-auto">
            Upload a photo for AI skin analysis, or chat to build your perfect routine — grounded in real products, no hallucinations.
          </p>
        </motion.div>

        <SkinAnalysisSection />
        <ChatSection />
      </div>
    </div>
  )
}
