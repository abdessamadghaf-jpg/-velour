// src/features/home/HomePage.tsx
import { useRef } from 'react'
import { Link } from 'react-router-dom'
import { motion, useScroll, useTransform } from 'framer-motion'
import { ArrowRight, Sparkles, TrendingUp, Shield, Leaf, Star } from 'lucide-react'
import { ProductCard } from '@/features/products/ProductCard'
import { PRODUCTS } from '@/shared/constants/products'
import { formatNumber } from '@/shared/utils'

// ── Ticker ────────────────────────────────────────────────────────────
function Ticker() {
  const items = [
    '↑ Hypochlorous Acid +132% Search',
    'Free Shipping on Orders $40+',
    '↑ Collagen Masks — TikTok Viral',
    'New: Copper Peptide GHK-Cu',
    '↑ Lash Serums +35% Sales Growth',
    '24,000+ Customers · 4.8★',
  ]
  const doubled = [...items, ...items]

  return (
    <div className="border-y border-white/5 bg-obsidian-50/50 py-2.5 overflow-hidden">
      <motion.div
        className="flex whitespace-nowrap"
        animate={{ x: [0, '-50%'] }}
        transition={{ duration: 28, repeat: Infinity, ease: 'linear' }}
      >
        {doubled.map((item, i) => (
          <span key={i} className="inline-flex items-center gap-8 px-8">
            <span className="text-xs font-medium tracking-wider text-ivory/50 uppercase">{item}</span>
            <span className="w-1 h-1 rounded-full bg-gold/50 shrink-0" />
          </span>
        ))}
      </motion.div>
    </div>
  )
}

// ── Hero ──────────────────────────────────────────────────────────────
function Hero() {
  const heroRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] })
  const y = useTransform(scrollYProgress, [0, 1], [0, 120])
  const opacity = useTransform(scrollYProgress, [0, 0.6], [1, 0])

  return (
    <section ref={heroRef} className="relative min-h-[95vh] flex items-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <motion.div style={{ y }} className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=1600&q=85&auto=format"
            alt=""
            className="w-full h-full object-cover object-center scale-110"
            aria-hidden
          />
        </motion.div>
        <div className="absolute inset-0 bg-gradient-to-r from-obsidian via-obsidian/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-obsidian via-transparent to-obsidian/30" />
      </div>

      {/* Decorative elements */}
      <div className="absolute right-0 top-1/4 w-px h-64 bg-gradient-to-b from-transparent via-gold/30 to-transparent" />
      <div className="absolute top-20 right-20 w-40 h-40 rounded-full bg-gold/5 blur-3xl" />

      <motion.div
        style={{ opacity }}
        className="relative max-w-7xl mx-auto px-4 sm:px-6 w-full pt-20 pb-32"
      >
        <div className="max-w-2xl">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 badge-gold mb-8 py-1.5 px-3"
          >
            <TrendingUp className="w-3 h-3" />
            <span>Trend Intelligence Active</span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="font-display font-light text-display-2xl text-ivory leading-none mb-6"
          >
            Beauty that{' '}
            <em className="text-gradient-gold not-italic">actually</em>
            <br />
            works.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg text-ivory/50 leading-relaxed max-w-md mb-10"
          >
            Science-backed beauty ranked by real demand signals — not influencer deals or paid placements. Trending before it sells out.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap gap-3 mb-14"
          >
            <Link to="/products" className="btn-gold btn-lg">
              Shop Trending
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link to="/advisor" className="btn-ghost btn-lg">
              <Sparkles className="w-4 h-4" />
              AI Skin Advisor
            </Link>
          </motion.div>

          {/* Trust bar */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="flex flex-wrap items-center gap-6"
          >
            {[
              { icon: Star, label: '4.8/5 Rating', sub: '24k+ Reviews' },
              { icon: Shield, label: 'Clean Beauty', sub: 'Verified Ingredients' },
              { icon: Leaf, label: 'Sustainable', sub: 'Carbon Neutral' },
            ].map(({ icon: Icon, label, sub }) => (
              <div key={label} className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center">
                  <Icon className="w-3.5 h-3.5 text-gold" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-ivory">{label}</p>
                  <p className="text-[10px] text-ivory/40">{sub}</p>
                </div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Floating stat card */}
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          animate-float
          className="hidden lg:block absolute right-8 top-1/2 -translate-y-1/2 card-glass p-6 w-56"
          style={{ animation: 'float 4s ease-in-out infinite' }}
        >
          <p className="label-luxury mb-3">Clinically proven</p>
          {[
            { label: 'Hydration', value: 92 },
            { label: 'Smoothness', value: 88 },
            { label: 'Radiance', value: 85 },
          ].map(stat => (
            <div key={stat.label} className="mb-2.5">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-ivory/50">{stat.label}</span>
                <span className="text-gold font-semibold">+{stat.value}%</span>
              </div>
              <div className="h-1 rounded-full bg-white/5 overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-gradient-gold"
                  initial={{ width: 0 }}
                  animate={{ width: `${stat.value}%` }}
                  transition={{ duration: 1.2, delay: 0.8, ease: [0.16, 1, 0.3, 1] }}
                />
              </div>
            </div>
          ))}
        </motion.div>
      </motion.div>
    </section>
  )
}

// ── Trending Products ─────────────────────────────────────────────────
function TrendingSection() {
  const trending = PRODUCTS.filter(p => p.isTrending).slice(0, 4)

  return (
    <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6">
      <div className="flex items-end justify-between mb-12">
        <div>
          <p className="label-luxury mb-2">Real-time signals</p>
          <h2 className="font-display font-light text-display-lg text-ivory">
            Trending <em className="text-gradient-gold">right now</em>
          </h2>
          <p className="text-ivory/40 mt-2 max-w-md">
            Ranked by actual search growth and bestseller velocity — not paid placement.
          </p>
        </div>
        <Link to="/products?filter=trending" className="hidden sm:flex btn-ghost btn-sm gap-1.5">
          View all <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5 lg:gap-6">
        {trending.map((product, i) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
          >
            <ProductCard product={product} />
          </motion.div>
        ))}
      </div>
    </section>
  )
}

// ── AI Advisor CTA ────────────────────────────────────────────────────
function AdvisorCTA() {
  return (
    <section className="py-8 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative overflow-hidden rounded-3xl"
          style={{ background: 'linear-gradient(135deg, #0F0C06 0%, #1A1208 50%, #0F0C06 100%)' }}
        >
          {/* Background glow */}
          <div className="absolute inset-0">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-gold/8 blur-[96px] rounded-full" />
            <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-gold/5 blur-[64px] rounded-full" />
          </div>
          <div className="absolute inset-0 border border-gold/10 rounded-3xl" />

          <div className="relative p-10 sm:p-16 grid sm:grid-cols-2 gap-10 items-center">
            <div>
              <div className="badge-gold inline-flex mb-6 gap-1.5">
                <Sparkles className="w-3 h-3" />
                AI-Powered Analysis
              </div>
              <h2 className="font-display font-light text-display-lg text-ivory mb-4">
                Your skin. Your{' '}
                <em className="text-gradient-gold">perfect</em> routine.
              </h2>
              <p className="text-ivory/50 leading-relaxed mb-8">
                Upload a photo and our AI analyses your skin type, concerns, and hydration levels — recommending only the products your skin actually needs.
              </p>
              <Link to="/advisor" className="btn-gold btn-lg inline-flex gap-2">
                <Sparkles className="w-4 h-4" />
                Start Skin Analysis
              </Link>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {[
                { icon: '🔬', label: 'Skin Type Analysis', sub: 'Oily · Dry · Combo · Sensitive' },
                { icon: '💧', label: 'Hydration Score', sub: '0–100 confidence rating' },
                { icon: '✨', label: 'Routine Builder', sub: 'AM · PM · Weekly' },
                { icon: '🎯', label: 'Product Matching', sub: 'From our curated catalog' },
              ].map(card => (
                <div key={card.label} className="card-glass p-4">
                  <div className="text-2xl mb-2">{card.icon}</div>
                  <p className="text-xs font-semibold text-ivory">{card.label}</p>
                  <p className="text-[11px] text-ivory/35 mt-0.5">{card.sub}</p>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

// ── All Products Preview ──────────────────────────────────────────────
function AllProductsPreview() {
  const products = PRODUCTS.slice(0, 8)

  return (
    <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6">
      <div className="flex items-end justify-between mb-12">
        <div>
          <p className="label-luxury mb-2">Full collection</p>
          <h2 className="font-display font-light text-display-lg text-ivory">
            All <em className="text-gradient-gold">products</em>
          </h2>
        </div>
        <Link to="/products" className="btn-ghost btn-sm gap-1.5">
          Shop all <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5 lg:gap-6">
        {products.map((product, i) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: (i % 4) * 0.07, ease: [0.16, 1, 0.3, 1] }}
          >
            <ProductCard product={product} />
          </motion.div>
        ))}
      </div>

      <div className="text-center mt-12">
        <Link to="/products" className="btn-outline btn-lg">
          View All Products
        </Link>
      </div>
    </section>
  )
}

// ── Reviews ───────────────────────────────────────────────────────────
const REVIEWS = [
  { stars: 5, quote: "I've tried every pore pad and Medicube is genuinely different. Skin looks airbrushed after two weeks.", name: 'Jessica R.', loc: 'New York', initials: 'JR', product: 'Zero Pore Pad 2.0' },
  { stars: 5, quote: "The Biodance collagen mask is the reason I sleep with something on my face every night. Woke up and my skin looked like I had a facial.", name: 'Amanda L.', loc: 'London', initials: 'AL', product: 'Bio-Collagen Mask' },
  { stars: 5, quote: "My lashes grew back after years of damage. Three months later and I get compliments daily.", name: 'Kemi O.', loc: 'Lagos', initials: 'KO', product: 'RapidLash Serum' },
]

function ReviewsSection() {
  return (
    <section className="py-20 border-y border-white/5 bg-obsidian-50/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <p className="label-luxury mb-2">Social proof</p>
          <h2 className="font-display font-light text-display-lg text-ivory">
            People are <em className="text-gradient-gold">obsessed.</em>
          </h2>
          <div className="flex items-center justify-center gap-2 mt-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-gold text-gold" />
            ))}
            <span className="text-sm text-ivory/50 ml-1">{formatNumber(204700)}+ Reviews</span>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-5">
          {REVIEWS.map((r, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.6 }}
              className="card-glass p-6"
            >
              <div className="flex gap-0.5 mb-4">
                {Array.from({ length: r.stars }).map((_, j) => (
                  <Star key={j} className="w-3.5 h-3.5 fill-gold text-gold" />
                ))}
              </div>
              <p className="font-display italic text-ivory/80 leading-relaxed mb-5">
                "{r.quote}"
              </p>
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-gold flex items-center justify-center text-obsidian text-xs font-bold">
                  {r.initials}
                </div>
                <div>
                  <p className="text-sm font-medium text-ivory">{r.name}</p>
                  <p className="text-xs text-ivory/35">{r.loc} · {r.product}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ── Newsletter ────────────────────────────────────────────────────────
function NewsletterSection() {
  return (
    <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="max-w-lg mx-auto text-center"
      >
        <p className="label-luxury mb-3">Early access</p>
        <h2 className="font-display font-light text-display-lg text-ivory mb-4">
          Get <em className="text-gradient-gold">10% off</em> your first order.
        </h2>
        <p className="text-ivory/40 mb-8">
          Join 24,000+ beauty insiders. Trend alerts, restocks, and exclusive offers — before anyone else.
        </p>
        <form className="flex gap-2" onSubmit={e => e.preventDefault()}>
          <input
            type="email"
            placeholder="your@email.com"
            className="input-luxury flex-1"
            aria-label="Email address"
          />
          <button type="submit" className="btn-gold shrink-0">Join</button>
        </form>
        <p className="text-xs text-ivory/25 mt-3">No spam. Unsubscribe anytime.</p>
      </motion.div>
    </section>
  )
}

// ── Page ──────────────────────────────────────────────────────────────
export default function HomePage() {
  return (
    <div>
      <Ticker />
      <Hero />
      <TrendingSection />
      <AdvisorCTA />
      <AllProductsPreview />
      <ReviewsSection />
      <NewsletterSection />
    </div>
  )
}
