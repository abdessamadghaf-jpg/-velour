// src/features/search/SearchOverlay.tsx
import { useEffect, useRef, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, X, TrendingUp, ArrowUpRight } from 'lucide-react'
import { useUIStore } from '@/features/wishlist/store'
import { PRODUCTS } from '@/shared/constants/products'
import { formatPrice, cn } from '@/shared/utils'

const TRENDING_SEARCHES = ['Collagen mask', 'Glycolic acid', 'Lash serum', 'Copper peptide', 'Pore pad']

export function SearchOverlay() {
  const { searchOpen, searchQuery, setSearchQuery, closeSearch } = useUIStore()
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (searchOpen) setTimeout(() => inputRef.current?.focus(), 100)
  }, [searchOpen])

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeSearch()
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        searchOpen ? closeSearch() : useUIStore.getState().openSearch()
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [searchOpen, closeSearch])

  const results = useMemo(() => {
    if (!searchQuery.trim()) return []
    const q = searchQuery.toLowerCase()
    return PRODUCTS.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.tags.some(t => t.includes(q)) ||
      p.category.includes(q)
    ).slice(0, 6)
  }, [searchQuery])

  return (
    <AnimatePresence>
      {searchOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={closeSearch}
            className="fixed inset-0 bg-obsidian/80 backdrop-blur-md z-[150]"
          />

          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.98 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className="fixed top-0 left-0 right-0 z-[151] p-4 sm:p-6"
          >
            <div className="max-w-2xl mx-auto">
              {/* Search input */}
              <div className="relative card-glass rounded-2xl overflow-hidden border-gold/20">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-gold" />
                <input
                  ref={inputRef}
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search products, brands, ingredients…"
                  className="w-full bg-transparent pl-14 pr-14 py-5 text-base text-ivory placeholder:text-ivory/25 focus:outline-none"
                />
                <button
                  onClick={closeSearch}
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-ivory/30 hover:text-ivory transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Results / suggestions */}
              <div className="card-glass rounded-2xl mt-2 overflow-hidden border-white/5 max-h-[70vh] overflow-y-auto scrollbar-hide">
                {results.length > 0 ? (
                  <div>
                    <p className="label-luxury px-5 pt-4 pb-2">Products</p>
                    {results.map(product => (
                      <Link
                        key={product.id}
                        to={`/products/${product.handle}`}
                        onClick={closeSearch}
                        className="flex items-center gap-4 px-5 py-3 hover:bg-white/5 transition-colors group"
                      >
                        <div className="w-12 h-12 rounded-xl overflow-hidden bg-white/5 shrink-0">
                          <img src={product.images[0]?.url} alt="" className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs text-ivory/30">{product.brand}</p>
                          <p className="text-sm font-medium text-ivory truncate">{product.name}</p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-sm font-semibold text-ivory">{formatPrice(product.variants[0].price)}</span>
                          <ArrowUpRight className="w-3.5 h-3.5 text-ivory/20 group-hover:text-gold transition-colors" />
                        </div>
                      </Link>
                    ))}
                    <Link
                      to={`/products?q=${encodeURIComponent(searchQuery)}`}
                      onClick={closeSearch}
                      className="block px-5 py-3 text-center text-sm text-gold hover:bg-gold/5 transition-colors border-t border-white/5"
                    >
                      View all results for "{searchQuery}"
                    </Link>
                  </div>
                ) : (
                  <div className="p-5">
                    <p className="label-luxury mb-3">Trending Searches</p>
                    <div className="flex flex-wrap gap-2">
                      {TRENDING_SEARCHES.map(term => (
                        <button
                          key={term}
                          onClick={() => setSearchQuery(term)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-gold/10 hover:text-gold border border-white/5 hover:border-gold/20 rounded-full text-xs text-ivory/50 transition-all"
                        >
                          <TrendingUp className="w-3 h-3" />
                          {term}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
