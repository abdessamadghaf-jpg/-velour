// src/features/products/ProductsPage.tsx
import { useState, useMemo } from 'react'
import { useSearchParams } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { SlidersHorizontal, X, ChevronDown } from 'lucide-react'
import { ProductCard } from './ProductCard'
import { ProductGridSkeleton } from '@/shared/components/ui/PageLoader'
import { PRODUCTS } from '@/shared/constants/products'
import type { ProductCategory, SkinType, SortOption } from '@/shared/types'
import { cn } from '@/shared/utils'

const SORT_OPTIONS: { value: SortOption; label: string }[] = [
  { value: 'relevance',  label: 'Relevance'   },
  { value: 'trending',   label: 'Trending'     },
  { value: 'newest',     label: 'Newest'       },
  { value: 'price-asc',  label: 'Price: Low'  },
  { value: 'price-desc', label: 'Price: High' },
  { value: 'rating',     label: 'Top Rated'   },
]

const CATEGORIES: { value: ProductCategory | 'all'; label: string }[] = [
  { value: 'all',          label: 'All'          },
  { value: 'serum',        label: 'Serums'       },
  { value: 'moisturizer',  label: 'Moisturizers' },
  { value: 'toner',        label: 'Toners'       },
  { value: 'mask',         label: 'Masks'        },
  { value: 'eye-care',     label: 'Eye Care'     },
  { value: 'treatment',    label: 'Treatments'   },
  { value: 'cleanser',     label: 'Cleansers'    },
]

const SKIN_TYPES: { value: SkinType; label: string }[] = [
  { value: 'oily',        label: 'Oily'        },
  { value: 'dry',         label: 'Dry'         },
  { value: 'combination', label: 'Combination' },
  { value: 'normal',      label: 'Normal'      },
  { value: 'sensitive',   label: 'Sensitive'   },
]

function FilterSidebar({
  open,
  onClose,
  skinTypes,
  toggleSkinType,
  onlyTrending,
  setOnlyTrending,
  onlyNew,
  setOnlyNew,
  onReset,
}: {
  open: boolean
  onClose: () => void
  skinTypes: SkinType[]
  toggleSkinType: (s: SkinType) => void
  onlyTrending: boolean
  setOnlyTrending: (v: boolean) => void
  onlyNew: boolean
  setOnlyNew: (v: boolean) => void
  onReset: () => void
}) {
  return (
    <>
      {/* Mobile overlay */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-obsidian/80 backdrop-blur-sm z-40 lg:hidden"
            onClick={onClose}
          />
        )}
      </AnimatePresence>

      <aside className={cn(
        'fixed inset-y-0 left-0 z-50 w-72 bg-obsidian border-r border-white/5 p-6 overflow-y-auto',
        'transform transition-transform duration-300 ease-spring',
        'lg:static lg:transform-none lg:w-56 lg:bg-transparent lg:border-0 lg:p-0',
        open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      )}>
        <div className="flex items-center justify-between mb-6 lg:hidden">
          <h2 className="font-display text-xl italic text-ivory">Filters</h2>
          <button onClick={onClose} className="text-ivory/40 hover:text-ivory">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick filters */}
        <div className="mb-6">
          <p className="label-luxury mb-3">Quick Filters</p>
          <div className="space-y-2">
            {[
              { label: 'Trending Now', value: onlyTrending, set: setOnlyTrending },
              { label: 'New Arrivals', value: onlyNew,      set: setOnlyNew      },
            ].map(f => (
              <label key={f.label} className="flex items-center gap-3 cursor-pointer group">
                <div
                  onClick={() => f.set(!f.value)}
                  className={cn(
                    'w-4 h-4 rounded border transition-all',
                    f.value
                      ? 'bg-gold border-gold'
                      : 'border-white/20 group-hover:border-gold/50'
                  )}
                >
                  {f.value && <div className="w-full h-full flex items-center justify-center text-obsidian text-[10px] font-bold">✓</div>}
                </div>
                <span className="text-sm text-ivory/60 group-hover:text-ivory transition-colors">{f.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Skin type */}
        <div className="mb-6">
          <p className="label-luxury mb-3">Skin Type</p>
          <div className="space-y-2">
            {SKIN_TYPES.map(st => (
              <label key={st.value} className="flex items-center gap-3 cursor-pointer group">
                <div
                  onClick={() => toggleSkinType(st.value)}
                  className={cn(
                    'w-4 h-4 rounded border transition-all',
                    skinTypes.includes(st.value)
                      ? 'bg-gold border-gold'
                      : 'border-white/20 group-hover:border-gold/50'
                  )}
                >
                  {skinTypes.includes(st.value) && (
                    <div className="w-full h-full flex items-center justify-center text-obsidian text-[10px] font-bold">✓</div>
                  )}
                </div>
                <span className="text-sm text-ivory/60 group-hover:text-ivory transition-colors">{st.label}</span>
              </label>
            ))}
          </div>
        </div>

        <button onClick={onReset} className="text-xs text-gold/60 hover:text-gold transition-colors">
          Clear all filters
        </button>
      </aside>
    </>
  )
}

export default function ProductsPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [filtersOpen, setFiltersOpen] = useState(false)
  const [sort, setSort] = useState<SortOption>('relevance')
  const [category, setCategory] = useState<ProductCategory | 'all'>(
    (searchParams.get('category') as ProductCategory) ?? 'all'
  )
  const [skinTypes, setSkinTypes] = useState<SkinType[]>([])
  const [onlyTrending, setOnlyTrending] = useState(searchParams.get('filter') === 'trending')
  const [onlyNew, setOnlyNew] = useState(searchParams.get('filter') === 'new')
  const [loading] = useState(false)

  const toggleSkinType = (st: SkinType) => {
    setSkinTypes(prev =>
      prev.includes(st) ? prev.filter(s => s !== st) : [...prev, st]
    )
  }

  const resetFilters = () => {
    setSkinTypes([])
    setOnlyTrending(false)
    setOnlyNew(false)
    setCategory('all')
  }

  const filtered = useMemo(() => {
    let list = [...PRODUCTS]
    if (category !== 'all') list = list.filter(p => p.category === category)
    if (skinTypes.length > 0) list = list.filter(p => skinTypes.some(st => p.skinTypes.includes(st)))
    if (onlyTrending) list = list.filter(p => p.isTrending)
    if (onlyNew) list = list.filter(p => p.isNew)

    switch (sort) {
      case 'trending':   return list.sort((a, b) => b.trendScore - a.trendScore)
      case 'newest':     return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      case 'price-asc':  return list.sort((a, b) => a.variants[0].price - b.variants[0].price)
      case 'price-desc': return list.sort((a, b) => b.variants[0].price - a.variants[0].price)
      case 'rating':     return list.sort((a, b) => b.rating - a.rating)
      default:           return list
    }
  }, [category, skinTypes, onlyTrending, onlyNew, sort])

  const activeFilterCount = skinTypes.length + (onlyTrending ? 1 : 0) + (onlyNew ? 1 : 0)

  return (
    <div className="min-h-screen">
      {/* Page header */}
      <div className="border-b border-white/5 py-10 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
            <p className="label-luxury mb-2">Collection</p>
            <h1 className="font-display font-light text-display-xl text-ivory">
              All <em className="text-gradient-gold">Products</em>
            </h1>
            <p className="text-ivory/40 mt-2">{filtered.length} products</p>
          </motion.div>
        </div>
      </div>

      {/* Category pills */}
      <div className="border-b border-white/5 overflow-x-auto scrollbar-hide">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex gap-2 min-w-max">
          {CATEGORIES.map(cat => (
            <button
              key={cat.value}
              onClick={() => setCategory(cat.value)}
              className={cn(
                'px-4 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all',
                category === cat.value
                  ? 'bg-gold text-obsidian'
                  : 'bg-white/5 text-ivory/50 hover:text-ivory hover:bg-white/10'
              )}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Toolbar */}
        <div className="flex items-center justify-between gap-4 mb-8">
          <button
            onClick={() => setFiltersOpen(true)}
            className={cn(
              'flex items-center gap-2 px-4 py-2 rounded-xl border text-sm transition-all',
              activeFilterCount > 0
                ? 'border-gold text-gold bg-gold/10'
                : 'border-white/10 text-ivory/50 hover:border-white/20 hover:text-ivory'
            )}
          >
            <SlidersHorizontal className="w-4 h-4" />
            Filters
            {activeFilterCount > 0 && (
              <span className="bg-gold text-obsidian text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </button>

          <div className="relative">
            <select
              value={sort}
              onChange={e => setSort(e.target.value as SortOption)}
              className="appearance-none bg-white/5 border border-white/10 rounded-xl pl-4 pr-8 py-2 text-sm text-ivory/60 focus:outline-none focus:border-gold/50 cursor-pointer"
            >
              {SORT_OPTIONS.map(o => (
                <option key={o.value} value={o.value} className="bg-obsidian">
                  {o.label}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-ivory/30 pointer-events-none" />
          </div>
        </div>

        <div className="flex gap-8">
          <FilterSidebar
            open={filtersOpen}
            onClose={() => setFiltersOpen(false)}
            skinTypes={skinTypes}
            toggleSkinType={toggleSkinType}
            onlyTrending={onlyTrending}
            setOnlyTrending={setOnlyTrending}
            onlyNew={onlyNew}
            setOnlyNew={setOnlyNew}
            onReset={resetFilters}
          />

          <div className="flex-1 min-w-0">
            {loading ? (
              <ProductGridSkeleton count={8} />
            ) : filtered.length === 0 ? (
              <div className="text-center py-24">
                <p className="font-display text-5xl text-white/5 mb-4">∅</p>
                <p className="font-display text-xl italic text-ivory/30 mb-6">No products found</p>
                <button onClick={resetFilters} className="btn-ghost btn-sm">Clear filters</button>
              </div>
            ) : (
              <motion.div
                layout
                className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-5 lg:gap-6"
              >
                <AnimatePresence mode="popLayout">
                  {filtered.map(product => (
                    <motion.div
                      key={product.id}
                      layout
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.3 }}
                    >
                      <ProductCard product={product} />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
