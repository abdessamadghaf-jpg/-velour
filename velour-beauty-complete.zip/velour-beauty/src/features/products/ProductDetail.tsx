// src/features/products/ProductDetail.tsx
import { useState } from 'react'
import { useParams, Link, Navigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Heart, ShoppingBag, Star, ChevronRight, Shield, Truck, RotateCcw, Sparkles, Check } from 'lucide-react'
import { PRODUCTS } from '@/shared/constants/products'
import { useCartStore } from '@/features/cart/store'
import { useWishlistStore, useUIStore } from '@/features/wishlist/store'
import { ProductCard } from './ProductCard'
import { formatPrice, getDiscountPercent, formatNumber, cn } from '@/shared/utils'
import type { ProductVariant } from '@/shared/types'

type Tab = 'description' | 'ingredients' | 'how-to-use' | 'reviews'

export default function ProductDetail() {
  const { handle } = useParams<{ handle: string }>()
  const product = PRODUCTS.find(p => p.handle === handle)

  if (!product) return <Navigate to="/products" replace />

  const [selectedVariant, setSelectedVariant] = useState<ProductVariant>(product.variants[0])
  const [activeImage, setActiveImage] = useState(0)
  const [activeTab, setActiveTab] = useState<Tab>('description')
  const [adding, setAdding] = useState(false)
  const [justAdded, setJustAdded] = useState(false)

  const { addItem } = useCartStore()
  const { toggleItem, isWishlisted } = useWishlistStore()
  const { addToast } = useUIStore()

  const isWished = isWishlisted(product.id)
  const hasDiscount = selectedVariant.compareAtPrice !== null
  const discountPct = hasDiscount ? getDiscountPercent(selectedVariant.price, selectedVariant.compareAtPrice!) : 0

  const related = PRODUCTS.filter(p => p.id !== product.id && p.category === product.category).slice(0, 4)

  async function handleAddToCart() {
    if (!selectedVariant.availableForSale || adding) return
    setAdding(true)
    await new Promise(r => setTimeout(r, 600))
    addItem(product, selectedVariant)
    addToast({ type: 'success', title: `${product.name} added to bag` })
    setAdding(false)
    setJustAdded(true)
    setTimeout(() => setJustAdded(false), 2500)
  }

  const TABS: { id: Tab; label: string }[] = [
    { id: 'description',  label: 'Description'  },
    { id: 'ingredients',  label: 'Ingredients'  },
    { id: 'how-to-use',   label: 'How to Use'   },
    { id: 'reviews',      label: `Reviews (${formatNumber(product.reviewCount)})` },
  ]

  return (
    <div className="min-h-screen">
      {/* Breadcrumb */}
      <div className="border-b border-white/5 py-3 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex items-center gap-2 text-xs text-ivory/30">
          <Link to="/" className="hover:text-ivory transition-colors">Home</Link>
          <ChevronRight className="w-3 h-3" />
          <Link to="/products" className="hover:text-ivory transition-colors">Products</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-ivory/60 truncate">{product.name}</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">

          {/* Images */}
          <div className="space-y-3">
            <motion.div
              key={activeImage}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="aspect-square rounded-3xl overflow-hidden bg-gradient-to-br from-white/5 to-white/[0.02] border border-white/5 relative"
            >
              <img
                src={product.images[activeImage]?.url}
                alt={product.images[activeImage]?.alt}
                className="w-full h-full object-cover"
              />
              {product.trendLabel && (
                <div className="absolute top-4 left-4 badge-trending flex items-center gap-1">
                  {product.trendLabel}
                </div>
              )}
            </motion.div>

            {product.images.length > 1 && (
              <div className="flex gap-2">
                {product.images.map((img, i) => (
                  <button
                    key={img.id}
                    onClick={() => setActiveImage(i)}
                    className={cn(
                      'w-16 h-16 rounded-xl overflow-hidden border-2 transition-all',
                      activeImage === i ? 'border-gold' : 'border-white/10 hover:border-white/30'
                    )}
                  >
                    <img src={img.url} alt={img.alt} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <p className="label-luxury mb-2">{product.brand}</p>
              <h1 className="font-display font-light text-display-lg text-ivory mb-3">{product.name}</h1>

              <p className="text-ivory/50 italic font-display mb-4">{product.tagline}</p>

              {/* Rating */}
              <div className="flex items-center gap-3 mb-6">
                <div className="flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className={cn('w-4 h-4', i < Math.round(product.rating) ? 'fill-gold text-gold' : 'text-white/10')} />
                  ))}
                </div>
                <span className="text-sm text-ivory/60">{product.rating} · {formatNumber(product.reviewCount)} reviews</span>
              </div>

              {/* Price */}
              <div className="flex items-baseline gap-3 mb-8 pb-8 border-b border-white/5">
                <span className="font-display text-3xl text-ivory">{formatPrice(selectedVariant.price)}</span>
                {hasDiscount && (
                  <>
                    <span className="text-lg text-ivory/30 line-through">{formatPrice(selectedVariant.compareAtPrice!)}</span>
                    <span className="badge-sale">-{discountPct}%</span>
                  </>
                )}
              </div>

              {/* Variants */}
              {product.variants.length > 1 && (
                <div className="mb-6">
                  <p className="text-sm font-medium text-ivory/60 mb-3">
                    Size / Variant: <span className="text-ivory">{selectedVariant.name}</span>
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {product.variants.map(v => (
                      <button
                        key={v.id}
                        onClick={() => setSelectedVariant(v)}
                        disabled={v.stock === 0}
                        className={cn(
                          'px-4 py-2 rounded-xl text-sm border transition-all',
                          selectedVariant.id === v.id
                            ? 'border-gold bg-gold/10 text-gold'
                            : 'border-white/10 text-ivory/50 hover:border-white/20 hover:text-ivory',
                          v.stock === 0 && 'opacity-30 cursor-not-allowed line-through'
                        )}
                      >
                        {v.name}
                        {v.compareAtPrice && (
                          <span className="ml-1.5 text-[10px] text-red-400">
                            -{getDiscountPercent(v.price, v.compareAtPrice)}%
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3 mb-8">
                <motion.button
                  onClick={handleAddToCart}
                  disabled={!selectedVariant.availableForSale || adding}
                  whileTap={{ scale: 0.97 }}
                  className={cn(
                    'flex-1 flex items-center justify-center gap-2 py-4 rounded-2xl text-sm font-semibold transition-all',
                    justAdded
                      ? 'bg-emerald-500/20 border border-emerald-500/30 text-emerald-400'
                      : 'bg-gradient-gold text-obsidian hover:shadow-gold-lg',
                    'disabled:opacity-40 disabled:cursor-not-allowed'
                  )}
                >
                  {justAdded ? (
                    <><Check className="w-4 h-4" />Added to Bag</>
                  ) : adding ? (
                    <><span className="w-4 h-4 border-2 border-obsidian/30 border-t-obsidian rounded-full animate-spin" />Adding…</>
                  ) : (
                    <><ShoppingBag className="w-4 h-4" />Add to Bag — {formatPrice(selectedVariant.price)}</>
                  )}
                </motion.button>

                <button
                  onClick={() => { toggleItem(product); addToast({ type: 'info', title: isWished ? 'Removed from wishlist' : 'Added to wishlist' }) }}
                  className={cn(
                    'w-14 rounded-2xl border flex items-center justify-center transition-all',
                    isWished ? 'border-red-500/30 bg-red-500/10' : 'border-white/10 hover:border-white/20'
                  )}
                >
                  <Heart className={cn('w-5 h-5', isWished ? 'fill-red-400 text-red-400' : 'text-ivory/50')} />
                </button>
              </div>

              {/* Trust signals */}
              <div className="grid grid-cols-3 gap-3 mb-8">
                {[
                  { icon: Truck,    label: 'Free shipping', sub: 'Orders over $40' },
                  { icon: RotateCcw,label: '30-day returns', sub: 'Hassle-free'    },
                  { icon: Shield,   label: 'Secure payment', sub: 'Encrypted'      },
                ].map(({ icon: Icon, label, sub }) => (
                  <div key={label} className="card-glass p-3 text-center">
                    <Icon className="w-4 h-4 text-gold mx-auto mb-1.5" />
                    <p className="text-[11px] font-medium text-ivory">{label}</p>
                    <p className="text-[10px] text-ivory/30">{sub}</p>
                  </div>
                ))}
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-6">
                {product.isVegan && <span className="badge-new">🌱 Vegan</span>}
                {product.isCrueltyFree && <span className="badge-new">🐰 Cruelty-Free</span>}
                {product.isClean && <span className="badge-new">✓ Clean</span>}
                {product.tags.slice(0, 3).map(tag => (
                  <span key={tag} className="badge bg-white/5 text-ivory/30">{tag}</span>
                ))}
              </div>

              {/* AI Advisor CTA */}
              <Link to="/advisor" className="flex items-center gap-3 card-glass p-4 group hover:border-gold/30 transition-all">
                <div className="w-10 h-10 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center shrink-0">
                  <Sparkles className="w-4 h-4 text-gold" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-ivory">Not sure this is right for you?</p>
                  <p className="text-xs text-ivory/40">Take the AI Skin Analysis →</p>
                </div>
                <ChevronRight className="w-4 h-4 text-ivory/20 group-hover:text-gold transition-colors" />
              </Link>
            </motion.div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-16">
          <div className="flex gap-1 border-b border-white/5 mb-8 overflow-x-auto scrollbar-hide">
            {TABS.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  'relative px-5 py-3 text-sm font-medium whitespace-nowrap transition-colors',
                  activeTab === tab.id ? 'text-ivory' : 'text-ivory/40 hover:text-ivory/70'
                )}
              >
                {tab.label}
                {activeTab === tab.id && (
                  <motion.div layoutId="tab-indicator" className="absolute bottom-0 left-0 right-0 h-px bg-gradient-gold" />
                )}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
              className="max-w-2xl"
            >
              {activeTab === 'description' && (
                <p className="text-ivory/60 leading-relaxed text-base">{product.description}</p>
              )}

              {activeTab === 'ingredients' && (
                <div className="space-y-4">
                  {product.ingredients.map(ing => (
                    <div key={ing.name} className="card-glass p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <p className="text-sm font-semibold text-ivory">{ing.name}</p>
                          <p className="text-xs text-ivory/40 mt-0.5">{ing.benefit}</p>
                        </div>
                        {ing.concentration && (
                          <span className="badge-gold shrink-0">{ing.concentration}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'how-to-use' && (
                <ol className="space-y-4">
                  {product.howToUse.map((step, i) => (
                    <li key={i} className="flex gap-4">
                      <span className="w-7 h-7 rounded-full bg-gold/10 border border-gold/20 flex items-center justify-center text-gold text-xs font-bold shrink-0">
                        {i + 1}
                      </span>
                      <p className="text-ivory/60 leading-relaxed pt-0.5">{step}</p>
                    </li>
                  ))}
                </ol>
              )}

              {activeTab === 'reviews' && (
                <div className="space-y-4">
                  <div className="card-glass p-6 flex items-center gap-6">
                    <div className="text-center">
                      <p className="font-display text-5xl font-light text-ivory">{product.rating}</p>
                      <div className="flex gap-0.5 mt-1 justify-center">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star key={i} className={cn('w-3 h-3', i < Math.round(product.rating) ? 'fill-gold text-gold' : 'text-white/10')} />
                        ))}
                      </div>
                      <p className="text-xs text-ivory/30 mt-1">{formatNumber(product.reviewCount)} reviews</p>
                    </div>
                    <div className="flex-1 space-y-1.5">
                      {[5, 4, 3, 2, 1].map(star => {
                        const pct = star === 5 ? 72 : star === 4 ? 18 : star === 3 ? 6 : star === 2 ? 2 : 2
                        return (
                          <div key={star} className="flex items-center gap-2">
                            <span className="text-xs text-ivory/30 w-3">{star}</span>
                            <div className="flex-1 h-1.5 rounded-full bg-white/5 overflow-hidden">
                              <motion.div
                                className="h-full bg-gradient-gold rounded-full"
                                initial={{ width: 0 }}
                                animate={{ width: `${pct}%` }}
                                transition={{ duration: 0.8, delay: 0.2 }}
                              />
                            </div>
                            <span className="text-xs text-ivory/30 w-6">{pct}%</span>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                  <p className="text-sm text-ivory/30 text-center py-4">Full review integration coming soon.</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Related products */}
        {related.length > 0 && (
          <div className="mt-20">
            <p className="label-luxury mb-2">You may also like</p>
            <h2 className="font-display font-light text-display-md text-ivory mb-8">
              Related <em className="text-gradient-gold">products</em>
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
              {related.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
