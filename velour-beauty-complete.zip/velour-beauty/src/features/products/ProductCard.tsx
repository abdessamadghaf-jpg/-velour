// src/features/products/ProductCard.tsx
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Heart, ShoppingBag, TrendingUp, Star, Eye } from 'lucide-react'
import type { Product } from '@/shared/types'
import { useCartStore } from '@/features/cart/store'
import { useWishlistStore, useUIStore } from '@/features/wishlist/store'
import { formatPrice, getDiscountPercent, cn } from '@/shared/utils'

interface ProductCardProps {
  product: Product
  variant?: 'default' | 'compact' | 'featured'
  className?: string
}

export function ProductCard({ product, variant = 'default', className }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [addingToCart, setAddingToCart] = useState(false)

  const { addItem } = useCartStore()
  const { toggleItem, isWishlisted } = useWishlistStore()
  const { addToast } = useUIStore()

  const primaryVariant = product.variants[0]
  const isWished = isWishlisted(product.id)
  const hasDiscount = primaryVariant.compareAtPrice !== null
  const discountPct = hasDiscount
    ? getDiscountPercent(primaryVariant.price, primaryVariant.compareAtPrice!)
    : 0

  async function handleQuickAdd(e: React.MouseEvent) {
    e.preventDefault()
    if (!product.availableForSale || addingToCart) return
    setAddingToCart(true)
    await new Promise(r => setTimeout(r, 400)) // simulate
    addItem(product, primaryVariant)
    addToast({ type: 'success', title: `${product.name} added to bag` })
    setAddingToCart(false)
  }

  function handleWishlist(e: React.MouseEvent) {
    e.preventDefault()
    toggleItem(product)
    addToast({
      type: 'info',
      title: isWished ? 'Removed from wishlist' : `${product.name} wishlisted`,
    })
  }

  return (
    <motion.div
      className={cn('group relative', className)}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
    >
      <Link to={`/products/${product.handle}`} className="block">
        {/* Image container */}
        <div className={cn(
          'relative overflow-hidden rounded-2xl bg-gradient-to-br from-white/5 to-white/[0.02]',
          'border border-white/5',
          variant === 'featured' ? 'aspect-[2/3]' : 'aspect-[3/4]'
        )}>
          <motion.img
            src={product.images[0]?.url}
            alt={product.images[0]?.alt}
            loading="lazy"
            className="w-full h-full object-cover"
            animate={{ scale: isHovered ? 1.06 : 1 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          />

          {/* Overlay */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-t from-obsidian/60 via-transparent to-transparent"
            animate={{ opacity: isHovered ? 1 : 0.3 }}
            transition={{ duration: 0.3 }}
          />

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            {product.isTrending && product.trendLabel && (
              <motion.div
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                className="badge-trending flex items-center gap-1"
              >
                <TrendingUp className="w-3 h-3" />
                <span className="text-[10px]">{product.trendLabel}</span>
              </motion.div>
            )}
            {product.isNew && <span className="badge-new">New</span>}
            {product.isBestSeller && <span className="badge-gold">Bestseller</span>}
            {hasDiscount && <span className="badge-sale">-{discountPct}%</span>}
          </div>

          {/* Action buttons */}
          <AnimatePresence>
            {isHovered && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 8 }}
                transition={{ duration: 0.2 }}
                className="absolute bottom-3 left-3 right-3 flex gap-2"
              >
                <motion.button
                  onClick={handleQuickAdd}
                  disabled={!product.availableForSale || addingToCart}
                  whileTap={{ scale: 0.95 }}
                  className={cn(
                    'flex-1 flex items-center justify-center gap-2',
                    'bg-gold text-obsidian rounded-xl py-2.5 text-xs font-semibold',
                    'hover:bg-gold-light transition-colors shadow-gold',
                    'disabled:opacity-50 disabled:cursor-not-allowed'
                  )}
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  {addingToCart ? 'Adding…' : !product.availableForSale ? 'Sold Out' : 'Quick Add'}
                </motion.button>

                <motion.button
                  onClick={handleWishlist}
                  whileTap={{ scale: 0.9 }}
                  className="w-10 h-10 rounded-xl bg-obsidian/80 backdrop-blur-sm flex items-center justify-center border border-white/10"
                >
                  <Heart
                    className={cn(
                      'w-3.5 h-3.5 transition-all',
                      isWished ? 'fill-red-400 text-red-400' : 'text-ivory/70'
                    )}
                  />
                </motion.button>

                <Link
                  to={`/products/${product.handle}`}
                  onClick={e => e.stopPropagation()}
                  className="w-10 h-10 rounded-xl bg-obsidian/80 backdrop-blur-sm flex items-center justify-center border border-white/10"
                >
                  <Eye className="w-3.5 h-3.5 text-ivory/70" />
                </Link>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Wishlist shortcut (always visible on mobile) */}
          <button
            onClick={handleWishlist}
            className="md:hidden absolute top-3 right-3 w-8 h-8 rounded-full bg-obsidian/70 backdrop-blur-sm flex items-center justify-center"
          >
            <Heart className={cn('w-3.5 h-3.5', isWished ? 'fill-red-400 text-red-400' : 'text-ivory/70')} />
          </button>
        </div>

        {/* Product info */}
        <div className="mt-3 px-0.5">
          <p className="label-luxury mb-1">{product.brand}</p>
          <h3 className="font-display font-medium text-ivory leading-snug group-hover:text-gold transition-colors line-clamp-2">
            {product.name}
          </h3>

          <div className="flex items-center justify-between mt-2">
            <div className="flex items-baseline gap-2">
              <span className="text-sm font-semibold text-ivory">
                {formatPrice(primaryVariant.price)}
              </span>
              {hasDiscount && (
                <span className="text-xs text-ivory/30 line-through">
                  {formatPrice(primaryVariant.compareAtPrice!)}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1 text-xs text-ivory/40">
              <Star className="w-3 h-3 fill-gold text-gold" />
              <span>{product.rating}</span>
            </div>
          </div>

          {/* Trend grade */}
          {product.isTrending && (
            <div className="mt-2 flex items-center gap-2">
              <div className="h-1 flex-1 rounded-full bg-white/5 overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-gradient-gold"
                  initial={{ width: 0 }}
                  animate={{ width: `${product.trendScore}%` }}
                  transition={{ duration: 1, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
                />
              </div>
              <span className="text-[10px] font-semibold text-gold">{product.trendGrade}</span>
            </div>
          )}
        </div>
      </Link>
    </motion.div>
  )
}
