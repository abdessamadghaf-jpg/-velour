// src/features/wishlist/store.ts
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { WishlistItem, Product } from '@/shared/types'
import { generateId } from '@/shared/utils'

interface WishlistStore {
  items: WishlistItem[]
  addItem: (product: Product) => void
  removeItem: (productId: string) => void
  isWishlisted: (productId: string) => boolean
  toggleItem: (product: Product) => void
  clearWishlist: () => void
}

export const useWishlistStore = create<WishlistStore>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (product) => set(state => ({
        items: [...state.items, {
          id: generateId(),
          productId: product.id,
          product,
          addedAt: new Date().toISOString(),
        }],
      })),
      removeItem: (productId) => set(state => ({
        items: state.items.filter(i => i.productId !== productId),
      })),
      isWishlisted: (productId) => get().items.some(i => i.productId === productId),
      toggleItem: (product) => {
        const { isWishlisted, addItem, removeItem } = get()
        isWishlisted(product.id) ? removeItem(product.id) : addItem(product)
      },
      clearWishlist: () => set({ items: [] }),
    }),
    { name: 'velour-wishlist', version: 1 }
  )
)

// ── UI Store (toasts, theme, search) ─────────────────────────────────
import type { NotificationToast, Theme } from '@/shared/types'

interface UIStore {
  theme: Theme
  toasts: NotificationToast[]
  searchOpen: boolean
  searchQuery: string
  setTheme: (t: Theme) => void
  toggleTheme: () => void
  addToast: (toast: Omit<NotificationToast, 'id'>) => void
  removeToast: (id: string) => void
  openSearch: () => void
  closeSearch: () => void
  setSearchQuery: (q: string) => void
}

export const useUIStore = create<UIStore>()(
  persist(
    (set, get) => ({
      theme: 'dark',
      toasts: [],
      searchOpen: false,
      searchQuery: '',

      setTheme: (theme) => {
        set({ theme })
        document.documentElement.classList.toggle('dark', theme === 'dark')
      },
      toggleTheme: () => {
        const next = get().theme === 'dark' ? 'light' : 'dark'
        get().setTheme(next)
      },

      addToast: (toast) => {
        const id = generateId()
        set(state => ({ toasts: [...state.toasts, { ...toast, id }] }))
        setTimeout(() => get().removeToast(id), toast.duration ?? 4000)
      },
      removeToast: (id) => set(state => ({
        toasts: state.toasts.filter(t => t.id !== id),
      })),

      openSearch: () => set({ searchOpen: true }),
      closeSearch: () => set({ searchOpen: false, searchQuery: '' }),
      setSearchQuery: (q) => set({ searchQuery: q }),
    }),
    { name: 'velour-ui', partialize: (s) => ({ theme: s.theme }) }
  )
)
