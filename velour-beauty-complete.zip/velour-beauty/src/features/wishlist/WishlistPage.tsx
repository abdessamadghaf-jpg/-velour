// src/features/wishlist/WishlistPage.tsx
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Heart, ShoppingBag, Trash2 } from 'lucide-react'
import { useWishlistStore, useUIStore } from './store'
import { useCartStore } from '@/features/cart/store'
import { formatPrice, cn } from '@/shared/utils'

export default function WishlistPage() {
  const { items, removeItem } = useWishlistStore()
  const { addItem } = useCartStore()
  const { addToast } = useUIStore()

  return (
    <div className="min-h-screen py-16 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <p className="label-luxury mb-2">Saved items</p>
          <h1 className="font-display font-light text-display-xl text-ivory">
            Your <em className="text-gradient-gold">Wishlist</em>
          </h1>
          <p className="text-ivory/30 mt-2">{items.length} item{items.length !== 1 ? 's' : ''}</p>
        </motion.div>

        {items.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-32 text-center"
          >
            <div className="w-20 h-20 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center mb-6">
              <Heart className="w-8 h-8 text-white/10" />
            </div>
            <h2 className="font-display text-2xl italic text-ivory/30 mb-3">Nothing saved yet</h2>
            <p className="text-ivory/20 text-sm mb-8">Products you heart will appear here.</p>
            <Link to="/products" className="btn-gold">Discover Products</Link>
          </motion.div>
        ) : (
          <motion.div
            layout
            className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5"
          >
            <AnimatePresence mode="popLayout">
              {items.map(({ product, id }) => {
                const variant = product.variants[0]
                return (
                  <motion.div
                    key={id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    transition={{ duration: 0.3 }}
                    className="card-glass rounded-2xl overflow-hidden group"
                  >
                    <Link to={`/products/${product.handle}`} className="block">
                      <div className="aspect-square overflow-hidden relative">
                        <img
                          src={product.images[0]?.url}
                          alt={product.images[0]?.alt}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                        {product.isTrending && product.trendLabel && (
                          <div className="absolute top-3 left-3 badge-trending text-[10px]">
                            {product.trendLabel}
                          </div>
                        )}
                      </div>
                    </Link>

                    <div className="p-4">
                      <p className="label-luxury mb-1">{product.brand}</p>
                      <p className="text-sm font-medium text-ivory mb-3 line-clamp-2">{product.name}</p>
                      <p className="font-semibold text-ivory mb-4">{formatPrice(variant.price)}</p>

                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            addItem(product, variant)
                            addToast({ type: 'success', title: `${product.name} added to bag` })
                          }}
                          className="flex-1 flex items-center justify-center gap-2 bg-gold text-obsidian rounded-xl py-2.5 text-xs font-semibold hover:bg-gold-light transition-colors"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          Add to Bag
                        </button>
                        <button
                          onClick={() => removeItem(product.id)}
                          className="w-10 rounded-xl border border-white/10 flex items-center justify-center text-ivory/30 hover:text-red-400 hover:border-red-500/30 transition-all"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )
              })}
            </AnimatePresence>
          </motion.div>
        )}
      </div>
    </div>
  )
}
