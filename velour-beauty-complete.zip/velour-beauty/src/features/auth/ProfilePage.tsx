// src/features/auth/ProfilePage.tsx
import { motion } from 'framer-motion'
import { User, Package, Heart, Star, Gift, LogOut, ChevronRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import { formatDate } from '@/shared/utils'

const MOCK_ORDERS = [
  { id: 'VB-001234', date: '2026-05-15', status: 'Delivered', total: 71, items: ['Zero Pore Pad 2.0', 'Bio-Collagen Mask'] },
  { id: 'VB-001098', date: '2026-04-02', status: 'Delivered', total: 39.99, items: ['RapidLash Serum'] },
  { id: 'VB-000891', date: '2026-03-18', status: 'Delivered', total: 22, items: ['Copper Peptide Serum'] },
]

const STATUS_COLORS: Record<string, string> = {
  Delivered:  'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
  Processing: 'text-gold bg-gold/10 border-gold/20',
  Shipped:    'text-blue-400 bg-blue-500/10 border-blue-500/20',
}

export default function ProfilePage() {
  const rewardPoints = 1240
  const tier = 'Gold'

  return (
    <div className="min-h-screen py-16 px-4 sm:px-6">
      <div className="max-w-4xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="mb-10">
          <p className="label-luxury mb-2">Account</p>
          <h1 className="font-display font-light text-display-xl text-ivory">Your Profile</h1>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* Profile card */}
          <div className="card-glass rounded-2xl p-6 text-center">
            <div className="w-16 h-16 rounded-full bg-gradient-gold flex items-center justify-center mx-auto mb-4 text-obsidian text-xl font-bold">
              G
            </div>
            <p className="font-display text-xl italic text-ivory">@goodvibes337</p>
            <p className="text-xs text-ivory/30 mt-1">Member since 2026</p>
            <div className="mt-4 badge-gold mx-auto w-fit">⭐ {tier} Member</div>
          </div>

          {/* Reward points */}
          <div className="card-gold rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <Gift className="w-4 h-4 text-gold" />
              <p className="label-luxury">Reward Points</p>
            </div>
            <p className="font-display text-4xl text-ivory mb-1">{rewardPoints.toLocaleString()}</p>
            <p className="text-xs text-ivory/40">≈ ${(rewardPoints / 100).toFixed(2)} store credit</p>
            <div className="mt-4 h-1.5 rounded-full bg-white/10 overflow-hidden">
              <motion.div
                className="h-full bg-gradient-gold rounded-full"
                initial={{ width: 0 }}
                animate={{ width: '62%' }}
                transition={{ duration: 1, delay: 0.3 }}
              />
            </div>
            <p className="text-[10px] text-ivory/25 mt-1.5">760 points to Platinum</p>
          </div>

          {/* Quick stats */}
          <div className="card-glass rounded-2xl p-6 space-y-4">
            {[
              { icon: Package, label: 'Total orders', value: '3' },
              { icon: Heart,   label: 'Wishlisted',   value: '0' },
              { icon: Star,    label: 'Reviews left',  value: '2' },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-ivory/40">
                  <Icon className="w-3.5 h-3.5" />
                  <span className="text-xs">{label}</span>
                </div>
                <span className="text-sm font-semibold text-ivory">{value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Order history */}
        <div className="card-glass rounded-2xl overflow-hidden mb-6">
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
            <h2 className="font-display text-lg italic text-ivory">Order History</h2>
          </div>
          {MOCK_ORDERS.map((order, i) => (
            <div key={order.id} className={`px-6 py-4 ${i < MOCK_ORDERS.length - 1 ? 'border-b border-white/5' : ''}`}>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <p className="text-sm font-semibold text-ivory">{order.id}</p>
                    <span className={`badge border text-[10px] ${STATUS_COLORS[order.status] ?? ''}`}>
                      {order.status}
                    </span>
                  </div>
                  <p className="text-xs text-ivory/30">{formatDate(order.date)}</p>
                  <p className="text-xs text-ivory/40 mt-1">{order.items.join(' · ')}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-semibold text-ivory">${order.total.toFixed(2)}</p>
                  <button className="text-[10px] text-gold/60 hover:text-gold transition-colors mt-1">
                    View details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3">
          <Link to="/wishlist" className="card-glass rounded-2xl p-4 flex items-center gap-3 hover:border-gold/20 transition-all">
            <Heart className="w-4 h-4 text-gold" />
            <span className="text-sm text-ivory">My Wishlist</span>
            <ChevronRight className="w-4 h-4 text-ivory/20 ml-auto" />
          </Link>
          <button className="card-glass rounded-2xl p-4 flex items-center gap-3 hover:border-red-500/20 transition-all text-left">
            <LogOut className="w-4 h-4 text-ivory/30" />
            <span className="text-sm text-ivory/50">Sign Out</span>
          </button>
        </div>
      </div>
    </div>
  )
}
