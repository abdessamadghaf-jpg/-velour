// src/features/cart/OrderSuccess.tsx
import { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { CheckCircle, Package, Sparkles } from 'lucide-react'

export default function OrderSuccess() {
  const orderNumber = useRef(`VB-${Date.now().toString().slice(-6)}`).current

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="max-w-lg w-full text-center">
        {/* Animated checkmark */}
        <div className="relative flex justify-center mb-8">
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 2.5, opacity: 0 }}
              transition={{ duration: 1.5, repeat: Infinity, ease: 'easeOut', delay: 0.5 }}
              className="w-20 h-20 rounded-full bg-gold/10"
            />
          </div>
          <motion.div
            initial={{ scale: 0, rotate: -20 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 20, delay: 0.2 }}
            className="relative w-20 h-20 rounded-full bg-gradient-gold flex items-center justify-center"
          >
            <CheckCircle className="w-9 h-9 text-obsidian" />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <p className="label-luxury mb-3">Order Confirmed</p>
          <h1 className="font-display font-light text-display-xl text-ivory mb-3">
            Thank you for your order.
          </h1>
          <p className="text-ivory/40 mb-2">
            Order #{orderNumber}
          </p>
          <p className="text-ivory/30 text-sm mb-10">
            A confirmation email has been sent to your inbox. Your beauty is on its way.
          </p>

          {/* Timeline */}
          <div className="card-glass p-6 mb-8 text-left">
            <p className="label-luxury mb-4">What happens next</p>
            <div className="space-y-4">
              {[
                { icon: CheckCircle, label: 'Order received', sub: 'Your order is being processed', done: true },
                { icon: Package, label: 'Preparing shipment', sub: 'Usually within 24 hours', done: false },
                { icon: Sparkles, label: 'On its way', sub: 'Estimated 3-5 business days', done: false },
              ].map((step, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${step.done ? 'bg-gold' : 'bg-white/5 border border-white/10'}`}>
                    <step.icon className={`w-3.5 h-3.5 ${step.done ? 'text-obsidian' : 'text-ivory/20'}`} />
                  </div>
                  <div>
                    <p className={`text-sm font-medium ${step.done ? 'text-ivory' : 'text-ivory/30'}`}>{step.label}</p>
                    <p className="text-xs text-ivory/25">{step.sub}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Link to="/products" className="btn-gold flex-1">Continue Shopping</Link>
            <Link to="/profile" className="btn-ghost flex-1">View Order History</Link>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
