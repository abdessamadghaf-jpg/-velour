// src/features/cart/CartDrawer.tsx
import { useRef } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { X, ShoppingBag, Minus, Plus, Trash2, Tag, ArrowRight } from 'lucide-react'
import { useCartStore } from './store'
import { formatPrice, cn } from '@/shared/utils'
import type { CartItem } from '@/shared/types'

function CartLineItem({ item }: { item: CartItem }) {
  const { updateQuantity, removeItem } = useCartStore()
  const image = item.product.images[0]

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20, height: 0 }}
      transition={{ duration: 0.25 }}
      className="flex gap-4 py-4 border-b border-white/5 last:border-0"
    >
      <Link to={`/products/${item.product.handle}`} className="shrink-0">
        <div className="w-18 h-18 rounded-xl overflow-hidden bg-white/5 border border-white/5">
          <img src={image?.url} alt={image?.alt} className="w-full h-full object-cover" />
        </div>
      </Link>

      <div className="flex-1 min-w-0">
        <p className="label-luxury">{item.product.brand}</p>
        <p className="text-sm font-medium text-ivory leading-tight mt-0.5 truncate">{item.product.name}</p>
        {item.variant.name !== item.product.variants?.[0]?.name && (
          <p className="text-xs text-ivory/30 mt-0.5">{item.variant.name}</p>
        )}

        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center gap-0 border border-white/10 rounded-xl overflow-hidden">
            <button
              onClick={() => updateQuantity(item.id, item.quantity - 1)}
              className="w-8 h-8 flex items-center justify-center text-ivory/40 hover:text-ivory hover:bg-white/5 transition-all"
            >
              <Minus className="w-3 h-3" />
            </button>
            <span className="w-8 text-center text-sm text-ivory font-medium">{item.quantity}</span>
            <button
              onClick={() => updateQuantity(item.id, item.quantity + 1)}
              className="w-8 h-8 flex items-center justify-center text-ivory/40 hover:text-ivory hover:bg-white/5 transition-all"
            >
              <Plus className="w-3 h-3" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-ivory">
              {formatPrice(item.variant.price * item.quantity)}
            </span>
            <button
              onClick={() => removeItem(item.id)}
              className="text-ivory/20 hover:text-red-400 transition-colors"
              aria-label="Remove item"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

export function CartDrawer() {
  const { cart, isOpen, closeCart } = useCartStore()
  const inputRef = useRef<HTMLInputElement>(null)
  const { applyCoupon, couponApplied } = { couponApplied: !!cart.couponCode, ...useCartStore() }

  return (
    <>
      {/* Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeCart}
            className="fixed inset-0 bg-obsidian/70 backdrop-blur-sm z-[100]"
          />
        )}
      </AnimatePresence>

      {/* Drawer */}
      <motion.aside
        initial={{ x: '100%' }}
        animate={{ x: isOpen ? '0%' : '100%' }}
        transition={{ type: 'spring', stiffness: 300, damping: 35 }}
        className="fixed right-0 top-0 bottom-0 z-[101] w-full max-w-md bg-obsidian border-l border-white/5 flex flex-col shadow-luxury-xl"
        aria-label="Shopping bag"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-white/5">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-gold" />
            <h2 className="font-display text-xl italic text-ivory">
              Your Bag
              {cart.items.length > 0 && (
                <span className="font-body font-normal text-sm text-ivory/30 ml-2 not-italic">
                  ({cart.items.reduce((s, i) => s + i.quantity, 0)})
                </span>
              )}
            </h2>
          </div>
          <button
            onClick={closeCart}
            className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-ivory/40 hover:text-ivory hover:bg-white/10 transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6">
          {cart.items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-20">
              <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-4">
                <ShoppingBag className="w-7 h-7 text-white/20" />
              </div>
              <p className="font-display text-xl italic text-ivory/30 mb-2">Your bag is empty</p>
              <p className="text-sm text-ivory/20 mb-6">Add products to get started</p>
              <button
                onClick={closeCart}
                className="btn-ghost btn-sm"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              {cart.items.map(item => (
                <CartLineItem key={item.id} item={item} />
              ))}
            </AnimatePresence>
          )}
        </div>

        {/* Footer */}
        {cart.items.length > 0 && (
          <div className="px-6 py-6 border-t border-white/5 bg-obsidian space-y-4">
            {/* Coupon */}
            {!cart.couponCode ? (
              <form
                onSubmit={e => {
                  e.preventDefault()
                  if (inputRef.current?.value) applyCoupon(inputRef.current.value)
                }}
                className="flex gap-2"
              >
                <div className="relative flex-1">
                  <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-ivory/20" />
                  <input
                    ref={inputRef}
                    placeholder="Coupon code (try VELOUR10)"
                    className="input-luxury pl-8 text-xs"
                  />
                </div>
                <button type="submit" className="btn-ghost btn-sm shrink-0">Apply</button>
              </form>
            ) : (
              <div className="flex items-center gap-2 badge-gold px-3 py-2 rounded-xl">
                <Tag className="w-3.5 h-3.5" />
                <span className="text-xs">{cart.couponCode} applied!</span>
              </div>
            )}

            {/* Totals */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-ivory/50">
                <span>Subtotal</span>
                <span>{formatPrice(cart.subtotal)}</span>
              </div>
              {cart.discount > 0 && (
                <div className="flex justify-between text-sm text-emerald-400">
                  <span>Discount</span>
                  <span>-{formatPrice(cart.discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-semibold text-ivory pt-2 border-t border-white/5">
                <span>Total</span>
                <span>{formatPrice(cart.total)}</span>
              </div>
            </div>

            <Link
              to="/checkout"
              onClick={closeCart}
              className={cn(
                'w-full flex items-center justify-center gap-2 bg-gradient-gold text-obsidian',
                'py-4 rounded-2xl text-sm font-semibold',
                'hover:shadow-gold-lg transition-shadow'
              )}
            >
              Checkout
              <ArrowRight className="w-4 h-4" />
            </Link>

            <p className="text-center text-xs text-ivory/20">
              Free shipping on orders over $40 · Secure checkout
            </p>
          </div>
        )}
      </motion.aside>
    </>
  )
}
