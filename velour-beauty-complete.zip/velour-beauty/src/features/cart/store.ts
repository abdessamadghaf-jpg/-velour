// src/features/cart/store.ts
import { create } from 'zustand'
import { immer } from 'zustand/middleware/immer'
import { persist } from 'zustand/middleware'
import type { Cart, CartItem, Product, ProductVariant } from '@/shared/types'
import { generateId } from '@/shared/utils'

interface CartStore {
  cart: Cart
  isOpen: boolean
  openCart: () => void
  closeCart: () => void
  toggleCart: () => void
  addItem: (product: Product, variant: ProductVariant, qty?: number) => void
  removeItem: (itemId: string) => void
  updateQuantity: (itemId: string, qty: number) => void
  clearCart: () => void
  applyCoupon: (code: string) => void
  removeCoupon: () => void
}

function calcTotals(items: CartItem[], discount: number) {
  const subtotal = items.reduce((s, i) => s + i.variant.price * i.quantity, 0)
  return { subtotal, total: Math.max(0, subtotal - discount) }
}

const emptyCart = (): Cart => ({
  id: generateId(),
  items: [],
  subtotal: 0,
  total: 0,
  discount: 0,
  couponCode: null,
  checkoutUrl: null,
})

export const useCartStore = create<CartStore>()(
  persist(
    immer((set) => ({
      cart: emptyCart(),
      isOpen: false,

      openCart: () => set(state => { state.isOpen = true }),
      closeCart: () => set(state => { state.isOpen = false }),
      toggleCart: () => set(state => { state.isOpen = !state.isOpen }),

      addItem: (product, variant, qty = 1) => set(state => {
        const existingIdx = state.cart.items.findIndex(
          i => i.productId === product.id && i.variantId === variant.id
        )
        if (existingIdx >= 0) {
          state.cart.items[existingIdx].quantity += qty
        } else {
          state.cart.items.push({
            id: generateId(),
            productId: product.id,
            variantId: variant.id,
            product: {
              id: product.id,
              name: product.name,
              brand: product.brand,
              handle: product.handle,
              images: product.images,
            },
            variant,
            quantity: qty,
            addedAt: new Date().toISOString(),
          })
        }
        const { subtotal, total } = calcTotals(state.cart.items, state.cart.discount)
        state.cart.subtotal = subtotal
        state.cart.total = total
        state.isOpen = true
      }),

      removeItem: (itemId) => set(state => {
        state.cart.items = state.cart.items.filter(i => i.id !== itemId)
        const { subtotal, total } = calcTotals(state.cart.items, state.cart.discount)
        state.cart.subtotal = subtotal
        state.cart.total = total
      }),

      updateQuantity: (itemId, qty) => set(state => {
        if (qty <= 0) {
          state.cart.items = state.cart.items.filter(i => i.id !== itemId)
        } else {
          const idx = state.cart.items.findIndex(i => i.id === itemId)
          if (idx >= 0) state.cart.items[idx].quantity = qty
        }
        const { subtotal, total } = calcTotals(state.cart.items, state.cart.discount)
        state.cart.subtotal = subtotal
        state.cart.total = total
      }),

      clearCart: () => set(state => { state.cart = emptyCart() }),

      applyCoupon: (code) => set(state => {
        // Mock: VELOUR10 = 10% off
        if (code.toUpperCase() === 'VELOUR10') {
          state.cart.couponCode = code
          state.cart.discount = state.cart.subtotal * 0.1
          state.cart.total = state.cart.subtotal - state.cart.discount
        }
      }),

      removeCoupon: () => set(state => {
        state.cart.couponCode = null
        state.cart.discount = 0
        state.cart.total = state.cart.subtotal
      }),
    })),
    { name: 'velour-cart', version: 1 }
  )
)
