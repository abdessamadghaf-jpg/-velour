// src/features/cart/CheckoutPage.tsx
import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Check, Lock, CreditCard, ChevronRight } from 'lucide-react'
import { useCartStore } from './store'
import { formatPrice, cn } from '@/shared/utils'

const contactSchema = z.object({
  email: z.string().email('Valid email required'),
  firstName: z.string().min(1, 'Required'),
  lastName: z.string().min(1, 'Required'),
  address: z.string().min(5, 'Required'),
  city: z.string().min(1, 'Required'),
  state: z.string().min(1, 'Required'),
  zip: z.string().min(4, 'Required'),
  country: z.string().min(1, 'Required'),
})

type ContactForm = z.infer<typeof contactSchema>

const paymentSchema = z.object({
  cardNumber: z.string().min(16).max(19),
  cardName: z.string().min(2, 'Required'),
  expiry: z.string().regex(/^\d{2}\/\d{2}$/, 'MM/YY format required'),
  cvv: z.string().min(3).max(4),
})

type PaymentForm = z.infer<typeof paymentSchema>

type Step = 'contact' | 'shipping' | 'payment' | 'review'
const STEPS: { id: Step; label: string }[] = [
  { id: 'contact',  label: 'Contact'  },
  { id: 'shipping', label: 'Shipping' },
  { id: 'payment',  label: 'Payment'  },
  { id: 'review',   label: 'Review'   },
]

function StepIndicator({ current }: { current: Step }) {
  const idx = STEPS.findIndex(s => s.id === current)
  return (
    <div className="flex items-center gap-0 mb-10">
      {STEPS.map((step, i) => (
        <div key={step.id} className="flex items-center">
          <div className={cn(
            'w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-all',
            i < idx  ? 'bg-gold text-obsidian' :
            i === idx ? 'bg-gold text-obsidian ring-4 ring-gold/20' :
            'bg-white/5 text-ivory/20'
          )}>
            {i < idx ? <Check className="w-3.5 h-3.5" /> : i + 1}
          </div>
          <span className={cn(
            'ml-2 text-xs font-medium hidden sm:block',
            i === idx ? 'text-ivory' : i < idx ? 'text-gold' : 'text-ivory/20'
          )}>
            {step.label}
          </span>
          {i < STEPS.length - 1 && (
            <div className={cn('h-px w-8 sm:w-12 mx-3', i < idx ? 'bg-gold/50' : 'bg-white/5')} />
          )}
        </div>
      ))}
    </div>
  )
}

function InputField({ label, error, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string }) {
  return (
    <div>
      <label className="block text-xs text-ivory/40 mb-1.5">{label}</label>
      <input {...props} className={cn('input-luxury', error && 'border-red-500/50')} />
      {error && <p className="text-xs text-red-400 mt-1">{error}</p>}
    </div>
  )
}

export default function CheckoutPage() {
  const [step, setStep] = useState<Step>('contact')
  const [contactData, setContactData] = useState<ContactForm | null>(null)
  const [processing, setProcessing] = useState(false)
  const { cart, clearCart } = useCartStore()
  const navigate = useNavigate()

  const contactForm = useForm<ContactForm>({ resolver: zodResolver(contactSchema) })
  const paymentForm = useForm<PaymentForm>({ resolver: zodResolver(paymentSchema) })

  async function onContactSubmit(data: ContactForm) {
    setContactData(data)
    setStep('shipping')
  }

  function onShippingNext() { setStep('payment') }

  async function onPaymentSubmit() {
    setStep('review')
  }

  async function onPlaceOrder() {
    setProcessing(true)
    await new Promise(r => setTimeout(r, 2000))
    clearCart()
    navigate('/order-success')
  }

  return (
    <div className="min-h-screen py-10 px-4 sm:px-6">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-10">
          <Link to="/" className="font-display text-2xl tracking-[0.1em] text-ivory">VELOUR</Link>
          <div className="flex items-center gap-2 text-xs text-ivory/30">
            <Lock className="w-3 h-3" />
            Secure checkout
          </div>
        </div>

        <StepIndicator current={step} />

        <div className="grid lg:grid-cols-[1fr,380px] gap-10">
          {/* Form area */}
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {step === 'contact' && (
                <form onSubmit={contactForm.handleSubmit(onContactSubmit)} className="space-y-5">
                  <h2 className="font-display text-2xl italic text-ivory mb-6">Contact Information</h2>
                  <InputField label="Email address" type="email" placeholder="you@example.com"
                    {...contactForm.register('email')} error={contactForm.formState.errors.email?.message} />
                  <div className="grid grid-cols-2 gap-4">
                    <InputField label="First name" placeholder="Jane"
                      {...contactForm.register('firstName')} error={contactForm.formState.errors.firstName?.message} />
                    <InputField label="Last name" placeholder="Smith"
                      {...contactForm.register('lastName')} error={contactForm.formState.errors.lastName?.message} />
                  </div>
                  <InputField label="Address" placeholder="123 Beauty Lane"
                    {...contactForm.register('address')} error={contactForm.formState.errors.address?.message} />
                  <div className="grid grid-cols-2 gap-4">
                    <InputField label="City" placeholder="New York"
                      {...contactForm.register('city')} error={contactForm.formState.errors.city?.message} />
                    <InputField label="State / Province" placeholder="NY"
                      {...contactForm.register('state')} error={contactForm.formState.errors.state?.message} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <InputField label="Postal code" placeholder="10001"
                      {...contactForm.register('zip')} error={contactForm.formState.errors.zip?.message} />
                    <InputField label="Country" placeholder="United States"
                      {...contactForm.register('country')} error={contactForm.formState.errors.country?.message} />
                  </div>
                  <button type="submit" className="btn-gold btn-lg w-full mt-4">
                    Continue to Shipping <ChevronRight className="w-4 h-4" />
                  </button>
                </form>
              )}

              {step === 'shipping' && (
                <div className="space-y-5">
                  <h2 className="font-display text-2xl italic text-ivory mb-6">Shipping Method</h2>
                  {[
                    { id: 'standard', label: 'Standard Shipping', sub: '5-7 business days', price: cart.subtotal >= 40 ? 0 : 5.99 },
                    { id: 'express', label: 'Express Shipping', sub: '2-3 business days', price: 14.99 },
                    { id: 'overnight', label: 'Overnight Delivery', sub: 'Next business day', price: 29.99 },
                  ].map(opt => (
                    <label key={opt.id} className="flex items-center gap-4 card-glass p-4 cursor-pointer hover:border-gold/30 transition-all">
                      <input type="radio" name="shipping" defaultChecked={opt.id === 'standard'} className="accent-gold" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-ivory">{opt.label}</p>
                        <p className="text-xs text-ivory/40">{opt.sub}</p>
                      </div>
                      <span className="text-sm font-semibold text-ivory">
                        {opt.price === 0 ? 'FREE' : formatPrice(opt.price)}
                      </span>
                    </label>
                  ))}
                  <button onClick={onShippingNext} className="btn-gold btn-lg w-full mt-4">
                    Continue to Payment <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}

              {step === 'payment' && (
                <form onSubmit={paymentForm.handleSubmit(onPaymentSubmit)} className="space-y-5">
                  <h2 className="font-display text-2xl italic text-ivory mb-6">Payment Details</h2>
                  <div className="flex gap-3 mb-6">
                    {['Visa', 'Mastercard', 'Amex', 'Apple Pay'].map(p => (
                      <div key={p} className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-xs text-ivory/40">{p}</div>
                    ))}
                  </div>
                  <InputField label="Card number" placeholder="1234 5678 9012 3456" maxLength={19}
                    {...paymentForm.register('cardNumber')} error={paymentForm.formState.errors.cardNumber?.message} />
                  <InputField label="Cardholder name" placeholder="Jane Smith"
                    {...paymentForm.register('cardName')} error={paymentForm.formState.errors.cardName?.message} />
                  <div className="grid grid-cols-2 gap-4">
                    <InputField label="Expiry date" placeholder="MM/YY"
                      {...paymentForm.register('expiry')} error={paymentForm.formState.errors.expiry?.message} />
                    <InputField label="CVV" placeholder="123" maxLength={4}
                      {...paymentForm.register('cvv')} error={paymentForm.formState.errors.cvv?.message} />
                  </div>
                  <div className="flex items-center gap-2 text-xs text-ivory/30 mt-2">
                    <Lock className="w-3.5 h-3.5" />
                    Your payment information is encrypted and secure.
                  </div>
                  <button type="submit" className="btn-gold btn-lg w-full mt-4">
                    Review Order <ChevronRight className="w-4 h-4" />
                  </button>
                </form>
              )}

              {step === 'review' && (
                <div>
                  <h2 className="font-display text-2xl italic text-ivory mb-6">Review Your Order</h2>
                  <div className="card-glass p-5 mb-5">
                    <p className="label-luxury mb-3">Shipping to</p>
                    {contactData && (
                      <p className="text-sm text-ivory/60">
                        {contactData.firstName} {contactData.lastName}<br />
                        {contactData.address}, {contactData.city}, {contactData.state} {contactData.zip}
                      </p>
                    )}
                  </div>
                  <div className="card-glass p-5 mb-5">
                    <p className="label-luxury mb-3">Payment</p>
                    <div className="flex items-center gap-2 text-sm text-ivory/60">
                      <CreditCard className="w-4 h-4" />
                      •••• •••• •••• 3456
                    </div>
                  </div>
                  <motion.button
                    onClick={onPlaceOrder}
                    disabled={processing}
                    whileTap={{ scale: 0.98 }}
                    className="btn-gold btn-lg w-full mt-4 relative overflow-hidden"
                  >
                    {processing ? (
                      <>
                        <span className="w-4 h-4 border-2 border-obsidian/30 border-t-obsidian rounded-full animate-spin" />
                        Processing…
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4" />
                        Place Order — {formatPrice(cart.total)}
                      </>
                    )}
                  </motion.button>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Order summary */}
          <div className="card-glass p-6 self-start sticky top-24">
            <p className="label-luxury mb-4">Order Summary</p>
            <div className="space-y-3 max-h-60 overflow-y-auto scrollbar-hide mb-4">
              {cart.items.map(item => (
                <div key={item.id} className="flex gap-3 items-center">
                  <div className="w-12 h-12 rounded-xl overflow-hidden bg-white/5 shrink-0">
                    <img src={item.product.images[0]?.url} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-ivory truncate">{item.product.name}</p>
                    <p className="text-[10px] text-ivory/30">{item.variant.name} × {item.quantity}</p>
                  </div>
                  <span className="text-xs font-semibold text-ivory shrink-0">{formatPrice(item.variant.price * item.quantity)}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-white/5 pt-4 space-y-2">
              <div className="flex justify-between text-sm text-ivory/40">
                <span>Subtotal</span><span>{formatPrice(cart.subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm text-ivory/40">
                <span>Shipping</span><span className="text-emerald-400">Free</span>
              </div>
              {cart.discount > 0 && (
                <div className="flex justify-between text-sm text-emerald-400">
                  <span>Discount</span><span>-{formatPrice(cart.discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-bold text-ivory pt-2 border-t border-white/5">
                <span>Total</span><span>{formatPrice(cart.total)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
