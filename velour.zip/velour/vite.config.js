import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  // Replace 'velour' with your GitHub repo name if different
  base: '/velour/',
})
