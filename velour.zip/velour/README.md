# VELOUR — Viral Beauty Store

Live beauty storefront. Trend-scored products, full cart, product modals, reviews, FAQ.

## → Live in 5 minutes on GitHub Pages

### Step 1: Create GitHub repo
1. Go to github.com → New repository
2. Name it exactly: `velour`
3. Set to **Public**
4. Do NOT initialize with README (leave empty)
5. Click Create repository

### Step 2: Push this code
```bash
cd velour
git init
git add .
git commit -m "feat: launch VELOUR storefront"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/velour.git
git push -u origin main
```

### Step 3: Enable GitHub Pages
1. Go to your repo → **Settings** → **Pages**
2. Source: **GitHub Actions**
3. Save

### Step 4: Wait ~2 minutes
GitHub will automatically build and deploy.
Your store will be live at:
```
https://YOUR-USERNAME.github.io/velour/
```

---

## Local development
```bash
npm install
npm run dev
# → http://localhost:5173/velour/
```

## Connect to Shopify (for real checkout)
Update the checkout button in `src/App.jsx` CartDrawer to redirect to your
Shopify checkout URL, or integrate the Shopify Buy SDK:
```
npm install @shopify/buy-button-js
```

## Customise
- **Products**: edit `src/data/products.js`
- **Colors**: search `#C17B5C` (terracotta), `#7A9E87` (sage), `#1A1208` (dark)
- **Brand name**: search `VELOUR` to replace
- **Images**: swap Unsplash URLs for your product photos

## Stack
- Vite + React 18
- Zero external UI dependencies (pure inline styles)
- localStorage cart persistence
- GitHub Actions auto-deploy
