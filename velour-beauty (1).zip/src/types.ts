export interface Review {
  id: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  details: string;
  price: number;
  rating: number;
  reviewsCount: number;
  image: string;
  category: 'Skincare' | 'Cosmetics' | 'Fragrance' | 'Wellness';
  ingredients: string[];
  usage: string;
  shades?: { name: string; hex: string }[];
  sizes?: string[];
  stock: number;
  bestSeller?: boolean;
  skinType?: ('All' | 'Dry' | 'Oily' | 'Sensitive' | 'Combination')[];
  concern?: ('Hydration' | 'Anti-aging' | 'Brightening' | 'Acne' | 'Texture')[];
  reviews: Review[];
}

export interface CartItem {
  id: string; // Unique ID representing cart row (productId + shade + size)
  product: Product;
  quantity: number;
  selectedShade?: { name: string; hex: string };
  selectedSize?: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: {
    label: string;
    description: string;
    value: string;
  }[];
  key: 'skinType' | 'concern' | 'texture';
}
