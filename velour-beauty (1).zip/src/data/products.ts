import { Product, QuizQuestion } from '../types';

export const HERO_IMAGE = '/src/assets/images/velour_hero_1782661198248.jpg';

export const products: Product[] = [
  {
    id: 'velour-silk-foundation',
    name: 'Velour Silk Luminous Foundation',
    description: 'An ultra-lightweight, skin-breathable foundation that delivers a soft-focus, radiant velvet finish and 24-hour hydration.',
    details: 'Crafted with patented micro-silk technology, this oil-free foundation melts seamlessly into your skin, blurring imperfections while letting your natural radiance shine through. Enriched with Hyaluronic Acid and White Tea extract, it protects your skin barrier while providing medium, buildable coverage.',
    price: 52.00,
    rating: 4.8,
    reviewsCount: 124,
    image: 'https://images.unsplash.com/photo-1631730359575-38e4755d772b?auto=format&fit=crop&w=800&q=80',
    category: 'Cosmetics',
    ingredients: [
      'Hyaluronic Acid (Triple Molecular Weight)',
      'Camellia Sinensis (White Tea) Leaf Extract',
      'Vitamin E (Tocopherol)',
      'Squalane (Plant-Derived)',
      'Titanium Dioxide (Natural Sun Filter)'
    ],
    usage: 'Dispense one pump onto the back of your hand. Using a damp sponge or dense foundation brush, buff the foundation outward from the center of your face. Build coverage where desired.',
    shades: [
      { name: '10N - Alabaster Neutral', hex: '#F9ECE1' },
      { name: '20W - Vanilla Warm', hex: '#F4DECD' },
      { name: '30C - Sand Cool', hex: '#ECCBB2' },
      { name: '45N - Honey Neutral', hex: '#DCA683' },
      { name: '60W - Amber Golden', hex: '#C6875C' },
      { name: '80C - Espresso Deep', hex: '#6D4026' }
    ],
    stock: 12,
    bestSeller: true,
    skinType: ['All', 'Dry', 'Sensitive', 'Combination'],
    concern: ['Hydration', 'Texture'],
    reviews: [
      {
        id: 'rev-1',
        author: 'Elena Rostova',
        rating: 5,
        comment: 'Absolutely spectacular. Feels like putting on a second skin. It hides my redness completely without clinging to dry patches. My holy grail foundation!',
        date: '2026-05-14',
        verified: true
      },
      {
        id: 'rev-2',
        author: 'Marcus Vance',
        rating: 4,
        comment: 'Great natural finish. It sits beautifully all day, though I do need a light touch of powder on my T-zone by lunchtime. Shade matching is very precise.',
        date: '2026-05-02',
        verified: true
      }
    ]
  },
  {
    id: 'midnight-matte-lipstick',
    name: 'Midnight Matte Hydrating Lipstick',
    description: 'A revolutionary matte lipstick providing high-impact pigment with the absolute comfort of a nourishing lip balm.',
    details: 'Infused with organic Shea Butter and cold-pressed Jojoba oil, this matte lipstick defies all expectations by keeping your lips moisturized and cushiony for up to 12 hours. Offers one-stroke full-intensity color payoff with a velvet-matte finish that does not feather, crack, or transfer.',
    price: 34.00,
    rating: 4.7,
    reviewsCount: 88,
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=800&q=80',
    category: 'Cosmetics',
    ingredients: [
      'Organic Shea Butter',
      'Cold-Pressed Jojoba Seed Oil',
      'Pomegranate Seed Extract',
      'Candelilla Wax',
      'Resveratrol (Grape-Derived Antioxidant)'
    ],
    usage: 'Apply directly to clean lips starting from the center and working outward. For ultra-precise definition, pair with the Velour Contour Lip Pencil.',
    shades: [
      { name: 'Velvet Burgundy', hex: '#580A14' },
      { name: 'Crimson Rose', hex: '#A32638' },
      { name: 'Petal Nude', hex: '#C97A7E' },
      { name: 'Toasted Caramel', hex: '#AC7B67' }
    ],
    stock: 25,
    bestSeller: false,
    reviews: [
      {
        id: 'rev-3',
        author: 'Isabella C.',
        rating: 5,
        comment: 'Velvet Burgundy is the most perfect deep red I have ever owned. And it actually stays comfortable! My lips didn’t dry out once.',
        date: '2026-06-18',
        verified: true
      }
    ]
  },
  {
    id: 'velvet-glow-serum',
    name: 'Velvet Glow Botanical Serum',
    description: 'A daily cellular renewal oil-serum that promotes cell turnover, deeply hydrates, and gives a radiant golden hour glow.',
    details: 'This multi-active nectar combines the potency of a targeted anti-aging serum with the deep nourishment of pristine botanical oils. Rich in cold-pressed Rosehip Seed, Squalane, and CoQ10, it stimulates collagen production, targets fine lines, and restores skin elasticity overnight.',
    price: 68.00,
    rating: 4.9,
    reviewsCount: 142,
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=80',
    category: 'Skincare',
    ingredients: [
      'Organic Rosehip Seed Oil',
      'Squalane (Sugar-Cane Derived)',
      'Coenzyme Q10 (Ubiquinone)',
      'Sea Buckthorn Berry Extract',
      'Niacinamide (Vitamin B3)'
    ],
    usage: 'Warm 3 to 4 drops in the palms of your hands and gently press into damp face and neck. Can be used alone or layered under your evening cream.',
    sizes: ['30 ml', '50 ml'],
    stock: 8,
    bestSeller: true,
    skinType: ['Dry', 'Sensitive', 'Combination', 'All'],
    concern: ['Anti-aging', 'Hydration', 'Brightening'],
    reviews: [
      {
        id: 'rev-4',
        author: 'Clara Dupont',
        rating: 5,
        comment: 'Liquid gold in a bottle. I wake up with the softest, most luminous skin. I love that it doesn’t feel heavy or greasy.',
        date: '2026-06-25',
        verified: true
      },
      {
        id: 'rev-5',
        author: 'Sophia Chen',
        rating: 5,
        comment: 'I am highly sensitive to facial oils, but this has been a dream. No breakouts, just gorgeous, plump skin. Truly worth every penny.',
        date: '2026-06-10',
        verified: true
      }
    ]
  },
  {
    id: 'luminous-barrier-cream',
    name: 'Luminous Barrier Rescue Cream',
    description: 'A rich ceramides-and-honey cream that repairs damaged skin barriers, plumps skin, and lock in 72-hour deep moisture.',
    details: 'Specially engineered for dry, distressed, or sensitive skin, this decadent barrier cream uses a clinically proven triple-ceramide complex (NP, AP, EOP) blended with pure Royal Jelly. It instant soothes itching, reduces irritation, and shields your skin against harsh environmental elements.',
    price: 58.00,
    rating: 4.9,
    reviewsCount: 95,
    image: 'https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?auto=format&fit=crop&w=800&q=80',
    category: 'Skincare',
    ingredients: [
      'Ceramide Complex (NP, AP, EOP)',
      'Royal Jelly Extract',
      'Colloidal Oatmeal',
      'Glycerin (99% Pure)',
      'Centella Asiatica (Cica) Extract'
    ],
    usage: 'Apply a dime-sized amount to clean skin morning and evening. Massage in upward, circular motions until fully absorbed.',
    sizes: ['50 ml', '100 ml'],
    stock: 14,
    bestSeller: false,
    skinType: ['Dry', 'Sensitive', 'Combination'],
    concern: ['Hydration', 'Acne', 'Texture'],
    reviews: [
      {
        id: 'rev-6',
        author: 'Miriam S.',
        rating: 5,
        comment: 'This cream saved my skin after a harsh chemical peel. The redness was gone overnight and it felt so soothing on contact.',
        date: '2026-06-01',
        verified: true
      }
    ]
  },
  {
    id: 'velvet-oud-perfume',
    name: 'Velvet Oud Eau de Parfum',
    description: 'An intoxicating, sophisticated fragrance blending rare agarwood, rich damask rose, and luxurious warm amber.',
    details: 'Velvet Oud opens with a striking, warm wave of precious Cambodian oud, transitioning gracefully into a heart of velvety Damask Rose and sweet praline. Sensual vetiver, patchouli, and golden amber linger on your skin, creating a captivating and sophisticated aura that lasts all day and night.',
    price: 110.00,
    rating: 4.6,
    reviewsCount: 76,
    image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=800&q=80',
    category: 'Fragrance',
    ingredients: [
      'Denatured Organic Alcohol',
      'Cambodian Oud Extract',
      'Damask Rose Oil',
      'Warm Amber Absolute',
      'Patchouli Leaf Essential Oil'
    ],
    usage: 'Mist onto pulse points—wrists, inner elbows, and base of neck—from a distance of 6 inches. Do not rub wrists together, as this breaks down the fragrance molecules.',
    sizes: ['50 ml', '100 ml'],
    stock: 5,
    bestSeller: true,
    reviews: [
      {
        id: 'rev-7',
        author: 'Adrian K.',
        rating: 5,
        comment: 'An absolute masterpiece. It is warm, mysterious, and gets me compliments literally every single time I wear it. Incredible sillage.',
        date: '2026-05-29',
        verified: true
      }
    ]
  },
  {
    id: 'royal-clay-exfoliator',
    name: 'Royal Rose Detoxifying Clay Mask',
    description: 'An illuminating French Rose clay mask that draws out toxins, refines pore texture, and reveals healthy, clear skin.',
    details: 'Formulated with ultra-fine French Pink Clay and mineral-rich Kaolin, this decadent mask detoxifies the skin without causing tightness or stripping. Infused with organic rose hydrosol and botanical enzymes, it gently exfoliates dead skin cells, targets blackheads, and evens out tone.',
    price: 42.00,
    rating: 4.7,
    reviewsCount: 54,
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80',
    category: 'Skincare',
    ingredients: [
      'French Pink Clay',
      'Kaolin Clay',
      'Organic Rosewater Hydrosol',
      'Papaya Enzyme Extract',
      'Aloe Barbadensis Leaf Juice'
    ],
    usage: 'Apply an even layer to clean, dry skin, avoiding the eye area. Leave on for 10-15 minutes until dry. Rinse thoroughly with warm water in gentle circular massaging motions.',
    sizes: ['80g'],
    stock: 20,
    bestSeller: false,
    skinType: ['Oily', 'Combination', 'All'],
    concern: ['Acne', 'Texture', 'Brightening'],
    reviews: [
      {
        id: 'rev-8',
        author: 'Zarah Al-Jamil',
        rating: 5,
        comment: 'My pores have never looked this clean. It spreads like absolute butter and washes off easily without leaving my face dry and tight.',
        date: '2026-06-21',
        verified: true
      }
    ]
  },
  {
    id: 'snail-mucin-hydrator',
    name: 'Glass Skin Snail Mucin 96% Hydrator',
    description: 'The TikTok-viral sensation for intense cell repair, deep hydration, and that coveted glossy, dewy glass-skin finish.',
    details: 'This ultra-lightweight, fast-absorbing essence sinks into the skin to repair dry patches, fade dark spots, and rebuild the skin barrier. With 96.3% Snail Secretion Filtrate and pure Hyaluronic Acid, it plumps and heals the skin without any sticky residue. A global bestseller trending on TikTok Shop and Amazon Beauty.',
    price: 22.00,
    rating: 4.9,
    reviewsCount: 3410,
    image: 'https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?auto=format&fit=crop&w=800&q=80',
    category: 'Skincare',
    ingredients: [
      'Snail Secretion Filtrate (96.3%)',
      'Sodium Hyaluronate',
      'Allantoin',
      'Panthenol',
      'Butylene Glycol'
    ],
    usage: 'After cleansing and toning, apply a small amount to your entire face. Gently pat with fingertips to aid absorption, then follow with your favorite serums and moisturizers.',
    sizes: ['100 ml'],
    stock: 45,
    bestSeller: true,
    skinType: ['All', 'Dry', 'Oily', 'Combination', 'Sensitive'],
    concern: ['Hydration', 'Texture', 'Brightening'],
    reviews: [
      {
        id: 'rev-sn1',
        author: 'Chloe M.',
        rating: 5,
        comment: 'Literally lives up to the hype! My skin has never looked so smooth and glossy. Dark spots from acne are fading so fast!',
        date: '2026-06-20',
        verified: true
      },
      {
        id: 'rev-sn2',
        author: 'Tyler J.',
        rating: 5,
        comment: 'I was skeptical because of the name, but this is pure magic. It is so hydrating and my sensitive skin loves it.',
        date: '2026-06-15',
        verified: true
      }
    ]
  },
  {
    id: 'milky-rice-toner',
    name: 'Ceramide Milky Rice Ferment Toner',
    description: 'A dual-phase hydrating milk that deeply nourishes, brightens dull complexions, and instantly calms tired skin.',
    details: 'Combining ancient Korean beauty wisdom with modern dermatological science, this milky toner features organic Yeoju Rice extract fermented to perfection. Paired with a robust Ceramide complex, it forms a protective moisture barrier, leaving your skin plump, radiant, and soft as silk. High TikTok search volume and stellar Amazon velocity.',
    price: 26.00,
    rating: 4.8,
    reviewsCount: 1840,
    image: 'https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?auto=format&fit=crop&w=800&q=80',
    category: 'Skincare',
    ingredients: [
      'Yeoju Rice Ferment Extract (77.78%)',
      'Niacinamide (2%)',
      'Ceramide NP',
      'Adenosine',
      'Portulaca Oleracea Extract'
    ],
    usage: 'Shake well before use to mix the dual layers. Apply a generous amount onto hands or a cotton pad and gently swipe or press onto the face and neck.',
    sizes: ['150 ml'],
    stock: 30,
    bestSeller: true,
    skinType: ['Dry', 'Sensitive', 'Combination', 'All'],
    concern: ['Hydration', 'Texture', 'Brightening'],
    reviews: [
      {
        id: 'rev-rc1',
        author: 'Harriet K.',
        rating: 5,
        comment: 'The absolute best toner for dry and flaky skin. It is like a liquid moisturizer! My skin immediately drinks it up.',
        date: '2026-06-24',
        verified: true
      }
    ]
  },
  {
    id: 'melon-dew-serum',
    name: 'Watermelon Niacinamide Dew Glow Serum',
    description: 'A breathable, vitamin-rich highlighting serum that delivers a luminous, makeup-gripping glow without a grey cast.',
    details: 'This multi-use gel serum instantly floods the skin with hydration while visibly brightening over time. Formulated with antioxidant-packed Watermelon, Niacinamide, and Hyaluronic Acid, it can be used as a hydrating serum, a primer, or a liquid highlighter to achieve an effortless glass-skin glow.',
    price: 32.00,
    rating: 4.7,
    reviewsCount: 2150,
    image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=800&q=80',
    category: 'Skincare',
    ingredients: [
      'Watermelon Fruit Extract',
      'Niacinamide (Vitamin B3)',
      'Hyaluronic Acid',
      'Centella Asiatica (Cica)',
      'Moringa Seed Oil'
    ],
    usage: 'Apply 1-2 pumps as the last step of your skincare routine for an instant glow, or pat on top of makeup as a natural dew-inducing highlighter.',
    sizes: ['40 ml'],
    stock: 50,
    bestSeller: true,
    skinType: ['All', 'Oily', 'Combination'],
    concern: ['Brightening', 'Hydration', 'Texture'],
    reviews: [
      {
        id: 'rev-md1',
        author: 'Sophia L.',
        rating: 5,
        comment: 'This smells like absolute heaven and gives the most gorgeous subtle glow under my makeup. Totally worth the hype!',
        date: '2026-06-27',
        verified: true
      }
    ]
  },
  {
    id: 'peptide-lip-oil',
    name: 'Glaze Peptide Plumping Lip Treatment',
    description: 'A TikTok-viral, ultra-glossy lip oil infused with restorative peptides and rich botanicals for naturally full, shiny lips.',
    details: 'Say goodbye to sticky lip glosses. This luxurious hybrid formula locks in deep moisture like a lip mask while leaving a glassy, high-shine glaze. Packed with active peptides and Cupuacu Butter, it visibly plumps, smooths lip lines, and comes in high-demand sheer pastel shades.',
    price: 24.00,
    rating: 4.9,
    reviewsCount: 1980,
    image: 'https://images.unsplash.com/photo-1599733589046-9b8308b5b50d?auto=format&fit=crop&w=800&q=80',
    category: 'Cosmetics',
    ingredients: [
      'Tripeptide-1 (Volume Builder)',
      'Organic Cupuacu Butter',
      'Babassu Seed Oil',
      'Shea Butter Oil',
      'Vitamin E'
    ],
    usage: 'Swipe onto clean lips daily for ultimate hydration, or layer on top of your favorite lip liner for a glossy, plumped finish.',
    shades: [
      { name: 'Salted Caramel', hex: '#c58f6d' },
      { name: 'Raspberry Glaze', hex: '#cf3c5a' },
      { name: 'Sheer Blossom', hex: '#e8a5ac' }
    ],
    stock: 65,
    bestSeller: true,
    reviews: [
      {
        id: 'rev-lp1',
        author: 'Isabella M.',
        rating: 5,
        comment: 'Salted Caramel is the most delicious lip treatment ever! It is not sticky at all and makes my lips look so plump.',
        date: '2026-06-22',
        verified: true
      }
    ]
  },
  {
    id: 'glow-guard-sunscreen',
    name: 'Water-Light Hyaluronic Sunscreen SPF 50+',
    description: 'A revolutionary, invisible daily sunscreen with an ultra-lightweight watery texture that leaves zero white cast.',
    details: 'The ultimate holy grail of daily sun protection. This organic chemical sunscreen absorbs instantly like a water gel, delivering deep hydration with 8 types of Hyaluronic Acid and Centella Extract. It feels weightless, leaves a dew-drop finish, and acts as a gorgeous primer under makeup. Highly viral on TikTok and Google Analytics.',
    price: 28.00,
    rating: 4.9,
    reviewsCount: 1540,
    image: 'https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=800&q=80',
    category: 'Skincare',
    ingredients: [
      'Octisalate (UV Filter)',
      '8-Type Hyaluronic Acid Complex',
      'Centella Asiatica (Cica)',
      'Astaxanthin (Antioxidant)',
      'Ceramide NP'
    ],
    usage: 'Apply evenly over entire face and neck as the final step in your morning skincare routine, 15 minutes before sun exposure.',
    sizes: ['50 ml'],
    stock: 35,
    bestSeller: true,
    skinType: ['All', 'Dry', 'Oily', 'Combination', 'Sensitive'],
    concern: ['Hydration', 'Anti-aging'],
    reviews: [
      {
        id: 'rev-ss1',
        author: 'Daria V.',
        rating: 5,
        comment: 'Finally a sunscreen that doesn’t burn my eyes, leave a white cast, or pill under makeup! It feels just like a water moisturizer.',
        date: '2026-06-26',
        verified: true
      }
    ]
  }
];

export const skincareQuiz: QuizQuestion[] = [
  {
    id: 1,
    question: "How would you describe your skin's natural state throughout the day?",
    options: [
      { label: "Tight & Dry", description: "Flaky patches, visible fine lines, and feels tight after cleansing.", value: "Dry" },
      { label: "Oily & Shiny", description: "Excess oil and shine, particularly on the T-zone, pores are noticeable.", value: "Oily" },
      { label: "Varies / Combination", description: "Shiny on the forehead, nose, and chin, but dry or normal on cheeks.", value: "Combination" },
      { label: "Easily Irritated", description: "Frequently red, itchy, or stinging in response to active ingredients.", value: "Sensitive" }
    ],
    key: "skinType"
  },
  {
    id: 2,
    question: "What is your primary skincare concern that you want to target today?",
    options: [
      { label: "Deep Dehydration", description: "Restore lost moisture, combat dry skin, and build skin barrier.", value: "Hydration" },
      { label: "Fine Lines & Elasticity", description: "Target wrinkles, sagging skin, and promote collagen renewal.", value: "Anti-aging" },
      { label: "Dullness & Dark Spots", description: "Even out tone, brighten complexion, and boost healthy radiance.", value: "Brightening" },
      { label: "Congestion & Blackheads", description: "Clear active breakouts, tighten pores, and regulate oil sebum.", value: "Acne" }
    ],
    key: "concern"
  }
];
