import { useState, useEffect } from 'react';
import { Product, CartItem } from '../types';

export function useCart() {
  const [cart, setCart] = useState<CartItem[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('velour_cart');
      return saved ? JSON.parse(saved) : [];
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem('velour_cart', JSON.stringify(cart));
  }, [cart]);

  const handleAddToCart = (
    product: Product,
    shade?: { name: string; hex: string },
    size?: string
  ) => {
    const uniqueCartId = `${product.id}-${shade?.name || 'none'}-${size || 'none'}`;

    setCart((prev) => {
      const existing = prev.find((item) => item.id === uniqueCartId);
      if (existing) {
        return prev.map((item) =>
          item.id === uniqueCartId ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [
        ...prev,
        {
          id: uniqueCartId,
          product,
          quantity: 1,
          selectedShade: shade,
          selectedSize: size,
        },
      ];
    });
  };

  const handleUpdateQuantity = (id: string, quantity: number) => {
    setCart((prev) =>
      prev.map((item) => (item.id === id ? { ...item, quantity } : item))
    );
  };

  const handleRemoveItem = (id: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  return {
    cart,
    setCart,
    handleAddToCart,
    handleUpdateQuantity,
    handleRemoveItem,
    handleClearCart,
    addToCart: handleAddToCart,
    removeFromCart: handleRemoveItem,
    updateQuantity: handleUpdateQuantity,
    clearCart: handleClearCart,
  };
}
