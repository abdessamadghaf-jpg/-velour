import { renderHook, act } from '@testing-library/react';
import { useCart } from './useCart';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { Product } from '../types';

// Mock Product for testing
const mockProduct1: Product = {
  id: 'prod-1',
  name: 'Velour Gold Lip Gloss',
  description: 'An ultra-luxurious lip gloss.',
  details: 'Infused with botanical oil.',
  price: 35.0,
  rating: 4.8,
  reviewsCount: 12,
  image: 'https://images.unsplash.com/photo-1596704017254-9b121068fb31?w=500',
  category: 'Cosmetics',
  ingredients: ['Gold leaf', 'Coconut oil'],
  usage: 'Apply directly to lips.',
  stock: 10,
  reviews: [],
};

const mockProduct2: Product = {
  id: 'prod-2',
  name: 'Midnight Rose Scent',
  description: 'Elegant, mysterious aroma.',
  details: 'Organic oils.',
  price: 95.0,
  rating: 4.9,
  reviewsCount: 8,
  image: 'https://images.unsplash.com/photo-1586776977607-310e9c725c37?w=500',
  category: 'Fragrance',
  ingredients: ['Damask Rose', 'Amber'],
  usage: 'Spray on pulse points.',
  stock: 5,
  reviews: [],
};

describe('useCart Hook', () => {
  beforeEach(() => {
    localStorage.clear();
    vi.clearAllMocks();
  });

  it('should initialize with an empty cart', () => {
    const { result } = renderHook(() => useCart());
    expect(result.current.cart).toEqual([]);
  });

  it('should load initial cart items from localStorage', () => {
    const savedCart = [
      {
        id: 'prod-1-none-none',
        product: mockProduct1,
        quantity: 2,
      },
    ];
    localStorage.setItem('velour_cart', JSON.stringify(savedCart));

    const { result } = renderHook(() => useCart());
    expect(result.current.cart).toEqual(savedCart);
  });

  it('should add a new product to the cart', () => {
    const { result } = renderHook(() => useCart());

    act(() => {
      result.current.addToCart(mockProduct1);
    });

    expect(result.current.cart).toHaveLength(1);
    expect(result.current.cart[0]).toEqual({
      id: 'prod-1-none-none',
      product: mockProduct1,
      quantity: 1,
      selectedShade: undefined,
      selectedSize: undefined,
    });
  });

  it('should increment quantity when adding the same product with identical shade and size', () => {
    const { result } = renderHook(() => useCart());

    act(() => {
      result.current.addToCart(mockProduct1);
    });

    act(() => {
      result.current.addToCart(mockProduct1);
    });

    expect(result.current.cart).toHaveLength(1);
    expect(result.current.cart[0].quantity).toBe(2);
  });

  it('should create separate cart items if products have different shades or sizes', () => {
    const { result } = renderHook(() => useCart());
    const shadeA = { name: 'Rose Gold', hex: '#E0B0FF' };
    const shadeB = { name: 'Pure Gold', hex: '#FFD700' };

    act(() => {
      result.current.addToCart(mockProduct1, shadeA, 'Standard');
    });

    act(() => {
      result.current.addToCart(mockProduct1, shadeB, 'Standard');
    });

    expect(result.current.cart).toHaveLength(2);
    expect(result.current.cart[0].id).toBe('prod-1-Rose Gold-Standard');
    expect(result.current.cart[1].id).toBe('prod-1-Pure Gold-Standard');
  });

  it('should remove items from the cart', () => {
    const { result } = renderHook(() => useCart());

    act(() => {
      result.current.addToCart(mockProduct1);
      result.current.addToCart(mockProduct2);
    });

    expect(result.current.cart).toHaveLength(2);

    act(() => {
      result.current.removeFromCart('prod-1-none-none');
    });

    expect(result.current.cart).toHaveLength(1);
    expect(result.current.cart[0].product.id).toBe('prod-2');
  });

  it('should update item quantities correctly', () => {
    const { result } = renderHook(() => useCart());

    act(() => {
      result.current.addToCart(mockProduct1);
    });

    act(() => {
      result.current.updateQuantity('prod-1-none-none', 5);
    });

    expect(result.current.cart[0].quantity).toBe(5);
  });

  it('should clear the cart entirely', () => {
    const { result } = renderHook(() => useCart());

    act(() => {
      result.current.addToCart(mockProduct1);
      result.current.addToCart(mockProduct2);
    });

    expect(result.current.cart).toHaveLength(2);

    act(() => {
      result.current.clearCart();
    });

    expect(result.current.cart).toEqual([]);
  });

  it('should persist cart changes to localStorage', () => {
    const { result } = renderHook(() => useCart());

    act(() => {
      result.current.addToCart(mockProduct1);
    });

    const stored = JSON.parse(localStorage.getItem('velour_cart') || '[]');
    expect(stored).toHaveLength(1);
    expect(stored[0].product.id).toBe('prod-1');
  });
});
