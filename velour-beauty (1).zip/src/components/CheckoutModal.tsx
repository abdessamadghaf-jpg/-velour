import React, { useState } from 'react';
import { X, Check, ShieldCheck, CreditCard, ShoppingBag, Printer, ArrowLeft, Loader2 } from 'lucide-react';
import { CartItem } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface CheckoutModalProps {
  cartItems: CartItem[];
  onClose: () => void;
  onClearCart: () => void;
}

export default function CheckoutModal({ cartItems, onClose, onClearCart }: CheckoutModalProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [submitting, setSubmitting] = useState(false);

  // Form Fields
  const [shippingName, setShippingName] = useState('');
  const [shippingEmail, setShippingEmail] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');
  const [shippingCity, setShippingCity] = useState('');
  const [shippingZip, setShippingZip] = useState('');

  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardName, setCardName] = useState('');

  const [formError, setFormError] = useState('');

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  // Formatting credit card input beautifully
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 16) value = value.slice(0, 16);
    const matches = value.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length > 0) {
      setCardNumber(parts.join(' '));
    } else {
      setCardNumber(value);
    }
  };

  // Formatting expiry MM/YY beautifully
  const handleCardExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 4) value = value.slice(0, 4);
    if (value.length >= 2) {
      setCardExpiry(`${value.slice(0, 2)}/${value.slice(2)}`);
    } else {
      setCardExpiry(value);
    }
  };

  const validateStep1 = () => {
    if (!shippingName.trim() || !shippingEmail.trim() || !shippingAddress.trim() || !shippingCity.trim() || !shippingZip.trim()) {
      setFormError('Please complete all shipping address fields.');
      return false;
    }
    if (!shippingEmail.includes('@')) {
      setFormError('Please enter a valid email address.');
      return false;
    }
    setFormError('');
    return true;
  };

  const validateStep2 = () => {
    if (!cardNumber.trim() || !cardExpiry.trim() || !cardCvv.trim() || !cardName.trim()) {
      setFormError('Please complete all payment fields.');
      return false;
    }
    if (cardNumber.length < 19) {
      setFormError('Invalid credit card number format.');
      return false;
    }
    if (cardExpiry.length < 5) {
      setFormError('Invalid expiration date.');
      return false;
    }
    if (cardCvv.length < 3) {
      setFormError('Invalid CVV code.');
      return false;
    }
    setFormError('');
    return true;
  };

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      if (validateStep1()) setStep(2);
    } else if (step === 2) {
      if (validateStep2()) {
        setSubmitting(true);
        setTimeout(() => {
          setSubmitting(false);
          setStep(3);
        }, 2000);
      }
    }
  };

  const handleBackStep = () => {
    if (step === 2) {
      setFormError('');
      setStep(1);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCompleteOrder = () => {
    onClearCart();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6" id="checkout-modal-overlay">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-[#0A0A0A]/70 backdrop-blur-md"
        onClick={step !== 3 ? onClose : undefined}
      />

      {/* Main Container */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.94, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 15 }}
        transition={{ type: 'spring', stiffness: 350, damping: 28 }}
        className="relative bg-[#0A0A0A] w-full max-w-4xl rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh] md:max-h-[85vh] z-10 border border-white/5 text-[#F5F5F0]"
      >
        
        {/* Close button (not shown on order confirmation) */}
        {step !== 3 && (
          <motion.button
            whileHover={{ scale: 1.1, rotate: 90 }}
            whileTap={{ scale: 0.9 }}
            onClick={onClose}
            className="absolute top-5 right-5 z-20 p-2.5 bg-[#121212] hover:bg-[#1C1C1C] text-white rounded-full border border-white/10 transition-all cursor-pointer"
            aria-label="Cancel checkout"
          >
            <X className="w-5 h-5" />
          </motion.button>
        )}

        {/* Left Column: Form Fields */}
        <div className="w-full md:w-3/5 p-6 sm:p-8 overflow-y-auto border-r border-white/5 flex flex-col justify-between bg-[#0A0A0A]">
          <div>
            {/* Steps indicator */}
            <div className="flex items-center space-x-2 text-[10px] uppercase tracking-wider font-bold text-white/40 mb-6">
              <span className={step === 1 ? 'text-gold font-extrabold' : 'text-white/40'}>Shipping</span>
              <span>/</span>
              <span className={step === 2 ? 'text-gold font-extrabold' : 'text-white/40'}>Payment</span>
              <span>/</span>
              <span className={step === 3 ? 'text-gold font-extrabold' : 'text-white/40'}>Confirmation</span>
            </div>

            {/* Error alerts */}
            <AnimatePresence>
              {formError && (
                <motion.p 
                  initial={{ height: 0, opacity: 0, y: -10 }}
                  animate={{ height: 'auto', opacity: 1, y: 0 }}
                  exit={{ height: 0, opacity: 0, y: -10 }}
                  className="bg-red-950/40 text-red-300 text-xs font-semibold px-3 py-2.5 rounded-xl border border-red-500/20 mb-4 overflow-hidden"
                >
                  ⚠️ {formError}
                </motion.p>
              )}
            </AnimatePresence>

            <AnimatePresence mode="wait">
              {/* Step 1: Shipping Form */}
              {step === 1 && (
                <motion.form 
                  key="step-shipping"
                  initial={{ opacity: 0, x: 15 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -15 }}
                  transition={{ duration: 0.2 }}
                  onSubmit={handleNextStep} 
                  className="space-y-4"
                >
                  <h2 className="text-xl font-medium text-white">Where shall we deliver?</h2>
                  <div className="space-y-3.5">
                    <div>
                      <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1.5 block">Full Name</label>
                      <input
                        type="text"
                        required
                        value={shippingName}
                        onChange={(e) => setShippingName(e.target.value)}
                        className="w-full bg-black/40 border border-white/10 focus:border-gold focus:bg-[#121212] rounded-xl p-3 text-xs focus:outline-none text-white transition-all"
                        placeholder="e.g. Eleanor Vance"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1.5 block">Email Address (For updates)</label>
                      <input
                        type="email"
                        required
                        value={shippingEmail}
                        onChange={(e) => setShippingEmail(e.target.value)}
                        className="w-full bg-black/40 border border-white/10 focus:border-gold focus:bg-[#121212] rounded-xl p-3 text-xs focus:outline-none text-white transition-all"
                        placeholder="eleanor@domain.com"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1.5 block">Delivery Address</label>
                      <input
                        type="text"
                        required
                        value={shippingAddress}
                        onChange={(e) => setShippingAddress(e.target.value)}
                        className="w-full bg-black/40 border border-white/10 focus:border-gold focus:bg-[#121212] rounded-xl p-3 text-xs focus:outline-none text-white transition-all"
                        placeholder="12 Luxury Boulevard, Apt 4"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1.5 block">City</label>
                        <input
                          type="text"
                          required
                          value={shippingCity}
                          onChange={(e) => setShippingCity(e.target.value)}
                          className="w-full bg-black/40 border border-white/10 focus:border-gold focus:bg-[#121212] rounded-xl p-3 text-xs focus:outline-none text-white transition-all"
                          placeholder="Paris"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1.5 block">Postal Code</label>
                        <input
                          type="text"
                          required
                          value={shippingZip}
                          onChange={(e) => setShippingZip(e.target.value)}
                          className="w-full bg-black/40 border border-white/10 focus:border-gold focus:bg-[#121212] rounded-xl p-3 text-xs focus:outline-none text-white transition-all font-mono"
                          placeholder="75001"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-6">
                    <motion.button
                      whileHover={{ scale: 1.02, backgroundColor: '#FFFFFF' }}
                      whileTap={{ scale: 0.98 }}
                      type="submit"
                      className="w-full bg-gold text-black text-xs uppercase tracking-widest font-extrabold py-4 rounded-xl shadow-lg transition-all cursor-pointer"
                    >
                      Continue To Payment
                    </motion.button>
                  </div>
                </motion.form>
              )}

              {/* Step 2: Payment Details */}
              {step === 2 && (
                <motion.form 
                  key="step-payment"
                  initial={{ opacity: 0, x: 15 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -15 }}
                  transition={{ duration: 0.2 }}
                  onSubmit={handleNextStep} 
                  className="space-y-4"
                >
                  <h2 className="text-xl font-medium text-white">Secure Payment</h2>
                  
                  {/* Credit Card Illustration with Motion Spring entry */}
                  <motion.div 
                    initial={{ scale: 0.95, opacity: 0, y: 10 }}
                    animate={{ scale: 1, opacity: 1, y: 0 }}
                    transition={{ type: 'spring', stiffness: 200, damping: 20 }}
                    className="bg-gradient-to-br from-black to-neutral-900 border border-white/10 text-white rounded-2xl p-5 shadow-lg relative overflow-hidden h-40 flex flex-col justify-between mb-4"
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-gold/5 rounded-full blur-2xl" />
                    
                    <div className="flex justify-between items-start">
                      <span className="text-[10px] font-sans font-bold tracking-[0.2em] uppercase text-gold">Velour Premium</span>
                      <CreditCard className="w-6 h-6 text-gold" />
                    </div>

                    <p className="text-sm font-mono tracking-widest py-2 text-white">
                      {cardNumber || '•••• •••• •••• ••••'}
                    </p>

                    <div className="flex justify-between items-end">
                      <div>
                        <span className="text-[7px] uppercase tracking-wider text-white/40 block">Card Holder</span>
                        <span className="text-[11px] font-semibold tracking-wider uppercase font-sans line-clamp-1 block min-h-[14px] text-white">
                          {cardName || 'YOUR FULL NAME'}
                        </span>
                      </div>
                      <div>
                        <span className="text-[7px] uppercase tracking-wider text-white/40 block">Expiry</span>
                        <span className="text-[11px] font-mono tracking-wider text-white">
                          {cardExpiry || 'MM/YY'}
                        </span>
                      </div>
                    </div>
                  </motion.div>

                  {/* Form Fields */}
                  <div className="space-y-3.5">
                    <div>
                      <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1.5 block">Name On Card</label>
                      <input
                        type="text"
                        required
                        value={cardName}
                        onChange={(e) => setCardName(e.target.value)}
                        className="w-full bg-black/40 border border-white/10 focus:border-gold focus:bg-[#121212] rounded-xl p-3 text-xs focus:outline-none text-white transition-all"
                        placeholder="Cardholder Name"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1.5 block">Card Number</label>
                      <input
                        type="text"
                        required
                        value={cardNumber}
                        onChange={handleCardNumberChange}
                        className="w-full bg-black/40 border border-white/10 focus:border-gold focus:bg-[#121212] rounded-xl p-3 text-xs focus:outline-none text-white transition-all font-mono"
                        placeholder="4000 1234 5678 9010"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1.5 block">Expiry Date</label>
                        <input
                          type="text"
                          required
                          value={cardExpiry}
                          onChange={handleCardExpiryChange}
                          className="w-full bg-black/40 border border-white/10 focus:border-gold focus:bg-[#121212] rounded-xl p-3 text-xs focus:outline-none text-white transition-all font-mono"
                          placeholder="MM/YY"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1.5 block">CVV</label>
                        <input
                          type="password"
                          required
                          maxLength={3}
                          value={cardCvv}
                          onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                          className="w-full bg-black/40 border border-white/10 focus:border-gold focus:bg-[#121212] rounded-xl p-3 text-xs focus:outline-none text-white transition-all font-mono"
                          placeholder="•••"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Back / Next Controls */}
                  <div className="flex gap-3 pt-6">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      type="button"
                      onClick={handleBackStep}
                      disabled={submitting}
                      className="flex items-center justify-center p-3 bg-white/10 hover:bg-white/15 text-white border border-white/5 rounded-xl transition-all cursor-pointer disabled:opacity-50"
                    >
                      <ArrowLeft className="w-5 h-5" />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: submitting ? 1 : 1.02, backgroundColor: submitting ? '#D4AF37' : '#FFFFFF' }}
                      whileTap={{ scale: submitting ? 1 : 0.98 }}
                      type="submit"
                      disabled={submitting}
                      className="flex-1 bg-gold text-black text-xs uppercase tracking-widest font-extrabold py-4 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75 disabled:cursor-wait"
                    >
                      {submitting ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" /> Verifying Credentials...
                        </>
                      ) : (
                        <>
                          Authorize Payment & Place Order
                        </>
                      )}
                    </motion.button>
                  </div>
                </motion.form>
              )}

              {/* Step 3: Confirmation Panel */}
              {step === 3 && (
                <motion.div 
                  key="step-confirmation"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 20 }}
                  className="text-center py-6 flex flex-col items-center justify-center h-full space-y-5"
                >
                  <motion.div 
                    initial={{ scale: 0.5 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 400, delay: 0.1 }}
                    className="w-14 h-14 bg-gold/10 rounded-full flex items-center justify-center border border-gold/20"
                  >
                    <Check className="w-7 h-7 text-gold stroke-[3]" />
                  </motion.div>

                  <div className="space-y-1.5">
                    <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Order Ref: #VL-395726</span>
                    <h2 className="text-2xl sm:text-3xl font-sans font-light tracking-tight text-white">
                      Merci Beaucoup!
                    </h2>
                    <p className="text-white/60 text-xs max-w-sm mx-auto leading-relaxed">
                      Thank you for shopping with Velour. Your order has been authorized and our lab is carefully packaging your items for shipment.
                    </p>
                  </div>

                  <div className="bg-[#121212] border border-white/5 rounded-2xl p-4 text-left text-xs text-white/80 w-full max-w-sm space-y-1">
                    <p><strong className="text-white">Deliver to:</strong> {shippingName}</p>
                    <p><strong className="text-white">Shipping Address:</strong> {shippingAddress}, {shippingCity}</p>
                    <p><strong className="text-white">Confirmation sent to:</strong> {shippingEmail}</p>
                  </div>

                  <div className="flex gap-2 w-full max-w-sm">
                    <motion.button
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={handlePrint}
                      className="flex-1 border border-white/10 hover:bg-white/5 text-white text-xs uppercase tracking-widest font-bold py-3.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 bg-[#121212]"
                    >
                      <Printer className="w-4 h-4 text-white/80" /> Print Receipt
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.03, backgroundColor: '#FFFFFF' }}
                      whileTap={{ scale: 0.97 }}
                      onClick={handleCompleteOrder}
                      className="flex-1 bg-gold text-black text-xs uppercase tracking-widest font-extrabold py-3.5 rounded-xl shadow-lg transition-all cursor-pointer"
                    >
                      Return Home
                    </motion.button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Checkout trust indicators */}
          <div className="border-t border-white/5 pt-5 mt-6 flex items-center justify-center gap-1.5 text-[9px] text-white/40 font-bold uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4 text-gold" />
            <span>Bank-Grade 256-Bit SSL Protection</span>
          </div>
        </div>

        {/* Right Column: Order Summary & Review */}
        <div className="w-full md:w-2/5 bg-[#121212]/50 p-6 sm:p-8 flex flex-col justify-between max-h-[40vh] md:max-h-full overflow-y-auto">
          <div>
            <h3 className="text-xs uppercase tracking-widest font-bold text-white mb-4 flex items-center gap-1.5">
              <ShoppingBag className="w-4 h-4 text-gold" />
              Order Summary
            </h3>

            {/* List items */}
            <div className="space-y-4 max-h-[180px] md:max-h-[300px] overflow-y-auto pr-2">
              {cartItems.map((item) => (
                <div key={item.id} className="flex items-center gap-3">
                  <div className="w-12 h-15 bg-[#151515] rounded-lg overflow-hidden border border-white/5 shrink-0">
                    <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover opacity-90" />
                  </div>
                  <div className="flex-1 text-xs">
                    <h4 className="font-bold text-white line-clamp-1">{item.product.name}</h4>
                    <p className="text-white/40 font-medium text-[10px]">
                      Qty: {item.quantity} {item.selectedShade ? `| Shade: ${item.selectedShade.name}` : ''}
                    </p>
                  </div>
                  <span className="text-xs font-bold text-white font-mono shrink-0">
                    ${(item.product.price * item.quantity).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Pricing totals */}
          <div className="pt-4 border-t border-white/5 mt-4 space-y-1.5 text-xs text-white/60 font-semibold">
            <div className="flex justify-between">
              <span>Item Subtotal</span>
              <span className="font-mono text-white font-bold">${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Delivery Charge</span>
              <span className="text-gold uppercase font-bold text-[10px] tracking-wider">Complimentary</span>
            </div>
            <div className="flex justify-between pt-3 border-t border-white/5 text-sm font-bold text-white">
              <span>Estimated Order Total</span>
              <span className="font-mono text-base text-gold">${subtotal.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
