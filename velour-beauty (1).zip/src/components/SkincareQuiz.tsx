import React, { useState } from 'react';
import { X, Sparkles, Check, ArrowRight, Loader2, RefreshCw, ShoppingBag } from 'lucide-react';
import { QuizQuestion, Product } from '../types';
import { skincareQuiz } from '../data/products';
import { motion, AnimatePresence } from 'motion/react';

interface SkincareQuizProps {
  products: Product[];
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

export default function SkincareQuiz({ products, onClose, onAddToCart }: SkincareQuizProps) {
  const [currentStep, setCurrentStep] = useState<'welcome' | 'questions' | 'calculating' | 'results'>('welcome');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [loadingText, setLoadingText] = useState('Analyzing skin concerns...');
  const [recommendedProducts, setRecommendedProducts] = useState<Product[]>([]);

  const handleStartQuiz = () => {
    setCurrentStep('questions');
    setCurrentQuestionIndex(0);
    setAnswers({});
    setSelectedOption(null);
  };

  const handleOptionSelect = (value: string) => {
    setSelectedOption(value);
  };

  const handleNext = () => {
    if (!selectedOption) return;

    const currentQuestion = skincareQuiz[currentQuestionIndex];
    const updatedAnswers = { ...answers, [currentQuestion.key]: selectedOption };
    setAnswers(updatedAnswers);
    setSelectedOption(null);

    if (currentQuestionIndex < skincareQuiz.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Last question completed - start calculation sequence
      setCurrentStep('calculating');
      triggerCalculation(updatedAnswers);
    }
  };

  const triggerCalculation = (finalAnswers: Record<string, string>) => {
    const texts = [
      'Analyzing skin oil barrier...',
      'Mapping botanical active ingredients...',
      'Matching cellular renewal complexes...',
      'Compiling custom Velour Skincare ritual...'
    ];

    let textIdx = 0;
    const interval = setInterval(() => {
      textIdx += 1;
      if (textIdx < texts.length) {
        setLoadingText(texts[textIdx]);
      }
    }, 1000);

    setTimeout(() => {
      clearInterval(interval);
      // Filter products based on skinType or concern
      const recommendations = products.filter(prod => {
        const matchesSkinType = prod.skinType?.includes(finalAnswers.skinType as any) || prod.skinType?.includes('All');
        const matchesConcern = prod.concern?.includes(finalAnswers.concern as any);
        return prod.category === 'Skincare' && (matchesSkinType || matchesConcern);
      });

      // Fallback if no matching skincare products
      setRecommendedProducts(recommendations.length > 0 ? recommendations : products.filter(p => p.category === 'Skincare'));
      setCurrentStep('results');
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6" id="skincare-quiz-overlay">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-[#0A0A0A]/70 backdrop-blur-md"
        onClick={onClose}
      />

      {/* Main Container */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.94, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 15 }}
        transition={{ type: 'spring', stiffness: 350, damping: 28 }}
        className="relative bg-[#0A0A0A] w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl p-6 sm:p-8 z-10 border border-white/5 min-h-[460px] flex flex-col justify-between text-[#F5F5F0]"
      >
        
        {/* Close Button */}
        <motion.button
          whileHover={{ scale: 1.1, rotate: 90 }}
          whileTap={{ scale: 0.9 }}
          onClick={onClose}
          className="absolute top-5 right-5 p-2 bg-white/5 text-white/50 hover:bg-white/10 hover:text-white rounded-full transition-colors cursor-pointer z-20"
          aria-label="Close Quiz"
          id="btn-close-quiz"
        >
          <X className="w-5 h-5" />
        </motion.button>

        <AnimatePresence mode="wait">
          {/* 1. Welcome Screen */}
          {currentStep === 'welcome' && (
            <motion.div 
              key="welcome"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
              className="text-center py-6 flex flex-col items-center justify-center flex-1 space-y-6"
            >
              <motion.div 
                animate={{ scale: [1, 1.08, 1], rotate: [0, 5, -5, 0] }}
                transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                className="w-16 h-16 bg-gold/10 rounded-full flex items-center justify-center border border-gold/20"
              >
                <Sparkles className="w-8 h-8 text-gold" />
              </motion.div>
              
              <div className="space-y-2">
                <h2 className="text-2xl sm:text-3xl font-sans font-light tracking-tight text-white">
                  Virtual Skin Analysis
                </h2>
                <p className="text-white/60 text-sm max-w-md mx-auto leading-relaxed">
                  Take our 1-minute expert consultation to discover a personalized Velour ritual crafted specifically for your cellular health, skin barrier, and beauty goals.
                </p>
              </div>

              <div className="bg-white/5 border border-white/5 rounded-2xl p-4 w-full max-w-md text-left text-xs text-white/70 leading-relaxed">
                ⭐ <strong>What you’ll receive:</strong> An in-depth evaluation of your skin’s concerns, key botanical active recommendations, and a personalized luxury skincare regimen.
              </div>

              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={handleStartQuiz}
                className="w-full max-w-sm bg-gold text-black text-xs uppercase tracking-widest font-extrabold py-4 rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
                id="btn-start-analysis"
              >
                Begin Consultation
                <ArrowRight className="w-4 h-4" />
              </motion.button>
            </motion.div>
          )}

          {/* 2. Questions Phase */}
          {currentStep === 'questions' && (
            <motion.div 
              key={`question-${currentQuestionIndex}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="flex-1 flex flex-col justify-between py-2"
            >
              <div>
                {/* Step indicator */}
                <div className="flex items-center justify-between text-[10px] text-white/40 uppercase tracking-wider font-bold mb-4">
                  <span>Skin Consultation</span>
                  <span>Question {currentQuestionIndex + 1} of {skincareQuiz.length}</span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-white/5 h-1.5 rounded-full mb-6 overflow-hidden">
                  <motion.div
                    className="bg-gold h-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentQuestionIndex + 1) / skincareQuiz.length) * 100}%` }}
                    transition={{ type: 'spring', stiffness: 80, damping: 15 }}
                  />
                </div>

                {/* Question text */}
                <h3 className="text-lg sm:text-xl font-medium text-white mb-6 leading-snug">
                  {skincareQuiz[currentQuestionIndex].question}
                </h3>

                {/* Option blocks */}
                <div className="space-y-3">
                  {skincareQuiz[currentQuestionIndex].options.map((opt) => (
                    <motion.button
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      key={opt.value}
                      onClick={() => handleOptionSelect(opt.value)}
                      className={`w-full text-left p-4 border rounded-2xl transition-all cursor-pointer flex items-start justify-between ${
                        selectedOption === opt.value
                          ? 'border-gold bg-gold/10 shadow-md ring-1 ring-gold'
                          : 'border-white/10 hover:border-white/30 hover:bg-white/5'
                      }`}
                    >
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-white uppercase tracking-wider">{opt.label}</p>
                        <p className="text-xs text-white/50 leading-relaxed">{opt.description}</p>
                      </div>
                      {selectedOption === opt.value && (
                        <motion.div 
                          initial={{ scale: 0.5 }}
                          animate={{ scale: 1 }}
                          className="w-5 h-5 bg-gold text-black rounded-full flex items-center justify-center shadow"
                        >
                          <Check className="w-3 h-3 stroke-[3]" />
                        </motion.div>
                      )}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Next button */}
              <div className="pt-6 border-t border-white/5 mt-6 flex justify-end">
                <motion.button
                  whileHover={{ scale: selectedOption ? 1.03 : 1 }}
                  whileTap={{ scale: selectedOption ? 0.97 : 1 }}
                  disabled={!selectedOption}
                  onClick={handleNext}
                  className="bg-gold hover:bg-white disabled:bg-white/5 disabled:text-white/20 text-black text-xs uppercase tracking-widest font-extrabold py-3.5 px-6 rounded-xl flex items-center gap-2 shadow transition-all duration-300 cursor-pointer disabled:cursor-not-allowed"
                  id="btn-quiz-next"
                >
                  {currentQuestionIndex === skincareQuiz.length - 1 ? 'Analyze Regimen' : 'Next Question'}
                  <ArrowRight className="w-3.5 h-3.5" />
                </motion.button>
              </div>
            </motion.div>
          )}

          {/* 3. Calculating / Matching Phase */}
          {currentStep === 'calculating' && (
            <motion.div 
              key="calculating"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 flex flex-col items-center justify-center text-center space-y-4 py-12"
            >
              <Loader2 className="w-10 h-10 text-gold animate-spin" />
              <div className="space-y-1.5">
                <h4 className="text-sm font-semibold uppercase tracking-widest text-[#F5F5F0]">Velour Lab Formulation</h4>
                <p className="text-xs text-white/50 italic animate-pulse">{loadingText}</p>
              </div>
            </motion.div>
          )}

          {/* 4. Results Screen */}
          {currentStep === 'results' && (
            <motion.div 
              key="results"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex-1 flex flex-col justify-between py-2"
            >
              <div>
                <div className="text-center mb-6">
                  <span className="bg-gold/10 text-gold text-[10px] uppercase tracking-widest font-bold px-3 py-1 rounded-full border border-gold/20 shadow-sm inline-block mb-3">
                    Analysis Complete
                  </span>
                  <h3 className="text-xl sm:text-2xl font-light tracking-tight text-white">
                    Your Curated Velour Regimen
                  </h3>
                  <p className="text-xs text-white/50 mt-1">Based on your {answers.skinType} skin and {answers.concern} concerns.</p>
                </div>

                {/* Recommended items scroll/list */}
                <div className="space-y-4 max-h-[250px] overflow-y-auto pr-2 mb-6">
                  {recommendedProducts.map((prod, idx) => (
                    <motion.div
                      key={prod.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="flex items-center gap-4 bg-[#121212] border border-white/5 p-3 rounded-2xl hover:border-gold/20 transition-all"
                    >
                      <div className="w-16 h-16 bg-[#151515] rounded-xl overflow-hidden shrink-0 border border-white/5">
                        <img src={prod.image} alt={prod.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </div>
                      <div className="flex-1 text-xs">
                        <h4 className="font-bold text-white leading-tight">{prod.name}</h4>
                        <p className="text-white/50 text-[11px] line-clamp-1 mt-0.5">{prod.description}</p>
                        <span className="text-gold font-bold font-mono block mt-1">${prod.price.toFixed(2)}</span>
                      </div>
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => onAddToCart(prod)}
                        className="p-2.5 bg-gold hover:bg-white text-black rounded-xl transition-all cursor-pointer shadow"
                        title="Add to Bag"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                      </motion.button>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Bottom panel */}
              <div className="pt-6 border-t border-white/5 flex items-center justify-between gap-4">
                <button
                  onClick={handleStartQuiz}
                  className="flex items-center gap-1.5 text-xs font-bold text-white/50 hover:text-white transition-all cursor-pointer uppercase tracking-wider"
                >
                  <RefreshCw className="w-3.5 h-3.5" /> Retake Analysis
                </button>
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={onClose}
                  className="bg-gold hover:bg-white text-black text-xs uppercase tracking-widest font-extrabold py-3 px-6 rounded-xl shadow cursor-pointer transition-all"
                >
                  Apply Recommendations
                </motion.button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
