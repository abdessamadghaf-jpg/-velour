import React from 'react';
import { X, ShoppingBag, Trash2, Plus, Minus, ArrowRight, ShieldCheck, Heart } from 'lucide-react';
import { CartItem, Product } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface CartDrawerProps {
  isOpen: boolean;
  cartItems: CartItem[];
  onClose: () => void;
  onUpdateQuantity: (id: string, quantity: number) => void;
  onRemoveItem: (id: string) => void;
  onCheckout: () => void;
  onMoveToWishlist?: (item: CartItem) => void;
}

export default function CartDrawer({
  isOpen,
  cartItems,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  onMoveToWishlist,
}: CartDrawerProps) {
  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const totalQuantity = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden" id="cart-drawer-overlay">
          {/* Backdrop with elegant fade */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-[#0A0A0A]/70 backdrop-blur-md"
            onClick={onClose}
          />

          {/* Drawer Panel container */}
          <div className="fixed inset-y-0 right-0 max-w-full flex pl-10 pointer-events-none">
            {/* Slide over sheet panel */}
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="pointer-events-auto w-screen max-w-md bg-[#0A0A0A] text-[#F5F5F0] shadow-2xl flex flex-col h-full border-l border-white/5"
            >
              
              {/* Header */}
              <div className="px-6 py-6 border-b border-white/5 flex items-center justify-between">
                <h2 className="text-lg font-semibold uppercase tracking-wider text-white flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-gold" />
                  Your Shopping Bag ({totalQuantity})
                </h2>
                <motion.button
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={onClose}
                  className="p-2 text-white/50 hover:text-white transition-colors cursor-pointer"
                  aria-label="Close cart"
                  id="btn-close-cart"
                >
                  <X className="w-6 h-6" />
                </motion.button>
              </div>

              {/* Cart items list with Staggered animations */}
              <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
                {cartItems.length === 0 ? (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex flex-col items-center justify-center h-full text-center space-y-4"
                  >
                    <div className="p-4 bg-white/5 rounded-full text-white/30 animate-pulse">
                      <ShoppingBag className="w-12 h-12" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-white uppercase text-sm tracking-wider">Your bag is empty</h3>
                      <p className="text-white/60 text-xs mt-1.5 leading-relaxed">
                        Explore our curated collection of premium cosmetics and find your signature beauty.
                      </p>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={onClose}
                      className="px-6 py-3 bg-gold text-black text-xs font-bold uppercase tracking-widest rounded-xl transition-all cursor-pointer shadow-md font-extrabold"
                    >
                      Continue Shopping
                    </motion.button>
                  </motion.div>
                ) : (
                  <AnimatePresence initial={false}>
                    {cartItems.map((item, index) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, height: 0, scale: 0.9, marginBottom: 0, padding: 0 }}
                        transition={{ duration: 0.25 }}
                        className="flex bg-[#121212] rounded-2xl p-4 border border-white/5 space-x-4 hover:border-gold/20 transition-all overflow-hidden"
                      >
                        {/* Item Image */}
                        <div className="w-20 h-24 bg-[#151515] rounded-xl overflow-hidden border border-white/5 shrink-0">
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        {/* Item details */}
                        <div className="flex-1 flex flex-col justify-between">
                          <div>
                            <div className="flex items-start justify-between">
                              <h4 className="font-semibold text-xs text-white line-clamp-1">{item.product.name}</h4>
                              <motion.button
                                whileHover={{ scale: 1.1, color: '#f87171' }}
                                whileTap={{ scale: 0.9 }}
                                onClick={() => onRemoveItem(item.id)}
                                className="p-1 text-white/40 rounded-lg transition-colors cursor-pointer"
                                aria-label="Remove item"
                              >
                                <Trash2 className="w-4 h-4" />
                              </motion.button>
                            </div>

                            {/* Display variants (shade / size) if chosen */}
                            <div className="flex flex-wrap gap-2 mt-1.5">
                              {item.selectedShade && (
                                <span className="flex items-center gap-1.5 bg-white/5 border border-white/10 px-2 py-0.5 rounded-full text-[10px] text-white/80 font-medium">
                                  <span
                                    className="w-2.5 h-2.5 rounded-full border border-white/20"
                                    style={{ backgroundColor: item.selectedShade.hex }}
                                  />
                                  {item.selectedShade.name}
                                </span>
                              )}
                              {item.selectedSize && (
                                <span className="bg-white/5 border border-white/10 px-2 py-0.5 rounded-full text-[10px] text-white/80 font-medium">
                                  {item.selectedSize}
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center justify-between mt-3">
                            {/* Quantity Controls with bouncy tap feedback */}
                            <div className="flex items-center border border-white/10 bg-[#151515] rounded-xl overflow-hidden shadow-sm">
                              <button
                                disabled={item.quantity <= 1}
                                onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                                className="px-2.5 py-1.5 hover:bg-white/5 text-white/50 disabled:text-white/20 disabled:hover:bg-transparent transition-colors cursor-pointer"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="px-3 text-xs font-bold text-white font-mono">{item.quantity}</span>
                              <button
                                onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                                className="px-2.5 py-1.5 hover:bg-white/5 text-white/50 transition-colors cursor-pointer"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>

                            {/* Line Price & optional Save to Wishlist */}
                            <div className="flex items-center gap-2">
                              {onMoveToWishlist && (
                                <motion.button
                                  whileHover={{ scale: 1.1, color: '#D4AF37' }}
                                  whileTap={{ scale: 0.9 }}
                                  onClick={() => onMoveToWishlist(item)}
                                  className="p-1.5 bg-white/5 border border-white/5 hover:border-gold/20 text-white/50 rounded-lg transition-colors cursor-pointer"
                                  title="Save to Wishlist"
                                >
                                  <Heart className="w-3.5 h-3.5" />
                                </motion.button>
                              )}
                              <span className="text-xs font-bold text-white font-mono">
                                ${(item.product.price * item.quantity).toFixed(2)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                )}
              </div>

              {/* Checkout Footer block */}
              {cartItems.length > 0 && (
                <div className="border-t border-white/5 px-6 py-6 bg-[#121212] space-y-4">
                  {/* Checkout details */}
                  <div className="space-y-1.5 text-xs text-white/60 font-semibold">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span className="font-mono text-white font-bold">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Shipping</span>
                      <span className="text-gold uppercase font-bold text-[10px] tracking-wider">Complimentary</span>
                    </div>
                    <div className="flex justify-between pt-3 border-t border-white/10 text-sm font-bold text-white">
                      <span>Estimated Total</span>
                      <span className="font-mono text-lg text-gold">${subtotal.toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Secure Checkout button */}
                  <motion.button
                    whileHover={{ scale: 1.02, backgroundColor: '#FFFFFF' }}
                    whileTap={{ scale: 0.98 }}
                    onClick={onCheckout}
                    className="w-full bg-gold text-black text-xs uppercase tracking-widest font-extrabold py-4 rounded-2xl flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
                    id="btn-checkout-drawer"
                  >
                    Proceed To Checkout
                    <ArrowRight className="w-4 h-4" />
                  </motion.button>

                  <div className="flex items-center justify-center gap-1.5 text-[10px] text-white/40 font-semibold uppercase tracking-wider text-center pt-2">
                    <ShieldCheck className="w-4 h-4 text-gold" />
                    <span>Secure SSL Checkout & Free Returns</span>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
}
