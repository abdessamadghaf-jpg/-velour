import React, { useState } from 'react';
import { Sparkles, ArrowRight, ArrowDown } from 'lucide-react';
import { HERO_IMAGE } from '../data/products';
import { motion } from 'motion/react';

interface HeroSectionProps {
  onOpenQuiz: () => void;
  onExploreProducts: () => void;
}

export default function HeroSection({ onOpenQuiz, onExploreProducts }: HeroSectionProps) {
  // Parallax coordinates tracking
  const [coords, setCoords] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const { currentTarget, clientX, clientY } = e;
    const { left, top, width, height } = currentTarget.getBoundingClientRect();
    // Normalize coordinates to range of -1 to 1
    const x = ((clientX - left) / width - 0.5) * 2;
    const y = ((clientY - top) / height - 0.5) * 2;
    setCoords({ x, y });
  };

  const handleMouseLeave = () => {
    setCoords({ x: 0, y: 0 });
  };

  // Motion variants for staggered container
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { type: 'spring', stiffness: 100, damping: 20 },
    },
  };

  return (
    <section
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative bg-[#0A0A0A] text-[#F5F5F0] min-h-[65vh] sm:min-h-[75vh] flex items-center justify-center overflow-hidden border-b border-white/5 cursor-default select-none"
    >
      {/* Background Image with interactive parallax */}
      <div className="absolute inset-0 z-0">
        <motion.img
          src={HERO_IMAGE}
          alt="Premium Cosmetics Arrangement"
          animate={{
            x: coords.x * 25,
            y: coords.y * 25,
            scale: 1.05,
          }}
          transition={{ type: 'spring', stiffness: 45, damping: 22 }}
          className="w-full h-full object-cover opacity-45"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/60 to-[#0A0A0A]/35" />
      </div>

      {/* Dynamic Liquid/Fluid Ambient Light Flares (Inspired by Digital Gravity) */}
      <motion.div
        animate={{
          x: -coords.x * 55,
          y: -coords.y * 55,
        }}
        transition={{ type: 'spring', stiffness: 35, damping: 25 }}
        className="absolute -top-12 -left-12 w-80 h-80 bg-gold/10 rounded-full blur-[100px] z-1 pointer-events-none"
      />
      <motion.div
        animate={{
          x: coords.x * 45,
          y: coords.y * 45,
        }}
        transition={{ type: 'spring', stiffness: 30, damping: 20 }}
        className="absolute -bottom-16 -right-16 w-[400px] h-[400px] bg-gold/5 rounded-full blur-[120px] z-1 pointer-events-none"
      />

      {/* Content Container */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-10 py-16"
      >
        <div className="space-y-5">
          {/* Elegant Tagline Badge */}
          <motion.div 
            variants={itemVariants}
            className="inline-flex items-center gap-2 bg-[#121212]/85 backdrop-blur-xl border border-gold/30 px-4 py-2 rounded-full shadow-md"
          >
            <Sparkles className="w-4 h-4 text-gold animate-pulse" />
            <span className="text-[10px] uppercase tracking-[0.25em] font-bold text-gold">
              Introducing Velour L'Elixir
            </span>
          </motion.div>

          {/* Main Headline with Split Style Transition */}
          <motion.h1 
            variants={itemVariants}
            className="text-4xl sm:text-6xl md:text-7xl font-sans font-light tracking-tight leading-none text-white max-w-4xl mx-auto"
          >
            Experience Cellular{' '}
            <motion.span 
              animate={{ color: ['#FFFFFF', '#D4AF37', '#FFFFFF'] }}
              transition={{ repeat: Infinity, duration: 12, ease: "easeInOut" }}
              className="font-serif italic font-normal text-gold inline-block"
            >
              Beauty
            </motion.span>
          </motion.h1>

          {/* Luxury Subtitle */}
          <motion.p 
            variants={itemVariants}
            className="text-white/70 text-sm sm:text-base md:text-lg max-w-xl mx-auto font-light leading-relaxed"
          >
            Advanced botanical formulas meet refined aesthetics. Discover our signature silk-finish collection designed for effortless radiance.
          </motion.p>
        </div>

        {/* CTA Actions */}
        <motion.div 
          variants={itemVariants}
          className="flex flex-col sm:flex-row items-center justify-center gap-5 pt-4"
        >
          <motion.button
            whileHover={{ 
              scale: 1.05, 
              boxShadow: "0 10px 30px -10px rgba(212,175,55,0.5)"
            }}
            whileTap={{ scale: 0.96 }}
            onClick={onOpenQuiz}
            className="w-full sm:w-auto bg-gold text-black text-xs uppercase tracking-widest font-extrabold py-4 px-9 rounded-xl shadow-xl transition-all cursor-pointer flex items-center justify-center gap-2"
            id="hero-btn-quiz"
          >
            Virtual Skin Consultation
            <Sparkles className="w-4 h-4 text-black" />
          </motion.button>
          
          <motion.button
            whileHover={{ 
              scale: 1.05,
              backgroundColor: "rgba(255, 255, 255, 0.1)"
            }}
            whileTap={{ scale: 0.96 }}
            onClick={onExploreProducts}
            className="w-full sm:w-auto bg-white/5 border border-white/20 text-white text-xs uppercase tracking-widest font-bold py-4 px-9 rounded-xl backdrop-blur-md transition-all cursor-pointer flex items-center justify-center gap-2"
            id="hero-btn-catalog"
          >
            Explore Catalog
            <ArrowRight className="w-4 h-4 text-white/80" />
          </motion.button>
        </motion.div>

        {/* Scroll down indicator */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="pt-10 hidden sm:block"
        >
          <motion.button
            onClick={onExploreProducts}
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
            className="text-white/30 hover:text-white transition-colors cursor-pointer"
            aria-label="Scroll down to products"
          >
            <ArrowDown className="w-5 h-5 mx-auto" />
          </motion.button>
        </motion.div>
      </motion.div>
    </section>
  );
}
