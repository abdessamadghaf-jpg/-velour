import React, { useState } from 'react';
import { X, Star, Heart, Check, ChevronDown, Award, Sparkles, MessageSquare, Plus, Loader2, ShoppingBag } from 'lucide-react';
import { Product, Review } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface ProductDetailModalProps {
  product: Product;
  isWishlisted: boolean;
  onClose: () => void;
  onToggleWishlist: () => void;
  onAddToCart: (shade?: { name: string; hex: string }, size?: string) => void;
  onAddReview: (productId: string, review: Omit<Review, 'id' | 'date' | 'verified'>) => void;
}

export default function ProductDetailModal({
  product,
  isWishlisted,
  onClose,
  onToggleWishlist,
  onAddToCart,
  onAddReview,
}: ProductDetailModalProps) {
  const [selectedShade, setSelectedShade] = useState(product.shades?.[0] || undefined);
  const [selectedSize, setSelectedSize] = useState(product.sizes?.[0] || undefined);
  const [activeTab, setActiveTab] = useState<'details' | 'ingredients' | 'usage'>('details');

  // State for Add to Bag feedback animation
  const [addingState, setAddingState] = useState<'idle' | 'loading' | 'success'>('idle');

  // Review Form States
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [newAuthor, setNewAuthor] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [reviewError, setReviewError] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState(false);

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newComment.trim()) {
      setReviewError('Please complete all fields.');
      return;
    }
    onAddReview(product.id, {
      author: newAuthor,
      rating: newRating,
      comment: newComment,
    });
    setNewAuthor('');
    setNewRating(5);
    setNewComment('');
    setReviewError('');
    setShowReviewForm(false);
    setReviewSuccess(true);
    setTimeout(() => setReviewSuccess(false), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6" id={`modal-${product.id}`}>
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-[#0A0A0A]/70 backdrop-blur-md"
        onClick={onClose}
      />

      {/* Modal Container */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.93, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.93, y: 20 }}
        transition={{ type: 'spring', stiffness: 350, damping: 28 }}
        className="relative bg-[#0A0A0A] w-full max-w-5xl rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh] md:max-h-[85vh] z-10 border border-white/5 text-[#F5F5F0]"
      >
        
        {/* Close Button */}
        <motion.button
          whileHover={{ scale: 1.1, rotate: 90 }}
          whileTap={{ scale: 0.9 }}
          onClick={onClose}
          className="absolute top-5 right-5 z-20 p-2.5 bg-[#121212] text-white hover:bg-[#1C1C1C] rounded-full shadow-lg border border-white/10 transition-all cursor-pointer"
          aria-label="Close details"
          id="btn-close-modal"
        >
          <X className="w-5 h-5" />
        </motion.button>

        {/* Left Column: Product Imagery */}
        <div className="md:w-1/2 bg-[#151515] relative flex items-center justify-center p-4 overflow-hidden h-[300px] md:h-auto">
          <motion.img
            initial={{ scale: 1.1, opacity: 0 }}
            animate={{ scale: 1, opacity: 0.95 }}
            transition={{ duration: 0.6 }}
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover max-h-[300px] md:max-h-full"
            referrerPolicy="no-referrer"
          />
          
          {/* Glassmorphic Trust badges */}
          <div className="absolute bottom-4 left-4 right-4 hidden sm:flex justify-around bg-black/40 backdrop-blur-md rounded-2xl p-3 border border-white/5 shadow-sm">
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-semibold text-white/80">
              <Award className="w-4 h-4 text-gold" />
              <span>Clean Formula</span>
            </div>
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-semibold text-white/80">
              <Sparkles className="w-4 h-4 text-gold animate-pulse" />
              <span>Cruelty Free</span>
            </div>
          </div>
        </div>

        {/* Right Column: Detailed Product Info */}
        <div className="md:w-1/2 overflow-y-auto p-6 sm:p-8 flex flex-col justify-between">
          <div>
            {/* Category / Star Badge */}
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase tracking-widest text-gold/80 font-bold">
                {product.category}
              </span>
              <div className="flex items-center gap-1 bg-gold/10 border border-gold/20 px-2.5 py-1 rounded-full">
                <Star className="w-3.5 h-3.5 fill-gold text-gold" />
                <span className="text-xs font-bold text-gold">{product.rating}</span>
              </div>
            </div>

            {/* Product Title */}
            <h2 className="text-2xl sm:text-3xl font-sans font-light tracking-tight text-white mb-2">
              {product.name}
            </h2>

            {/* Product Price */}
            <p className="text-xl font-semibold text-gold font-mono mb-4">
              ${product.price.toFixed(2)}
            </p>

            {/* Sub-Navigation Tabs */}
            <div className="flex border-b border-white/5 mb-5 relative">
              {(['details', 'ingredients', 'usage'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`relative py-2 px-4 text-xs font-semibold uppercase tracking-wider cursor-pointer transition-all ${
                    activeTab === tab
                      ? 'text-gold'
                      : 'text-white/50 hover:text-white'
                  }`}
                  id={`tab-${tab}`}
                >
                  <span className="relative z-10">{tab}</span>
                  {activeTab === tab && (
                    <motion.span 
                      layoutId="activeModalTab"
                      transition={{ type: 'spring', stiffness: 350, damping: 28 }}
                      className="absolute bottom-0 left-0 w-full h-[2px] bg-gold z-0" 
                    />
                  )}
                </button>
              ))}
            </div>

            {/* Tab Contents with subtle animation */}
            <div className="text-white/70 text-sm leading-relaxed mb-6">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  transition={{ duration: 0.15 }}
                >
                  {activeTab === 'details' && (
                    <div>
                      <p>{product.details}</p>
                      {product.skinType && (
                        <div className="mt-4 flex flex-wrap gap-2 items-center">
                          <span className="text-xs font-bold text-white/80">Skin Type:</span>
                          {product.skinType.map((type) => (
                            <span key={type} className="bg-white/5 text-white/80 text-[11px] px-2.5 py-0.5 rounded-md font-medium">
                              {type}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                  {activeTab === 'ingredients' && (
                    <div>
                      <p className="font-semibold text-white/80 mb-2">Key Ingredients:</p>
                      <ul className="list-disc list-inside space-y-1 text-white/70">
                        {product.ingredients.map((ing, i) => (
                          <li key={i}>{ing}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {activeTab === 'usage' && (
                    <p className="text-white/70">{product.usage}</p>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Variant Selectors: Shades */}
            {product.shades && product.shades.length > 0 && (
              <div className="mb-6">
                <span className="text-xs uppercase tracking-wider font-semibold text-white/80 mb-3 block">
                  Select Shade: <span className="font-medium text-gold">{selectedShade?.name}</span>
                </span>
                <div className="flex flex-wrap gap-2.5">
                  {product.shades.map((shade) => (
                    <motion.button
                      whileHover={{ scale: 1.15 }}
                      whileTap={{ scale: 0.9 }}
                      key={shade.name}
                      onClick={() => setSelectedShade(shade)}
                      className={`w-8 h-8 rounded-full border-2 transition-all relative flex items-center justify-center cursor-pointer ${
                        selectedShade?.name === shade.name ? 'border-gold scale-110 shadow-md' : 'border-white/10'
                      }`}
                      style={{ backgroundColor: shade.hex }}
                      title={shade.name}
                    >
                      {selectedShade?.name === shade.name && (
                        <Check className="w-4 h-4 text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)] font-bold" />
                      )}
                    </motion.button>
                  ))}
                </div>
              </div>
            )}

            {/* Variant Selectors: Sizes */}
            {product.sizes && product.sizes.length > 0 && (
              <div className="mb-6">
                <span className="text-xs uppercase tracking-wider font-semibold text-white/80 mb-3 block">
                  Select Size:
                </span>
                <div className="flex gap-2">
                  {product.sizes.map((size) => (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-4 py-2 border rounded-xl text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
                        selectedSize === size
                          ? 'border-gold bg-gold text-black shadow-sm font-bold'
                          : 'border-white/10 text-white/80 hover:border-white/30'
                      }`}
                    >
                      {size}
                    </motion.button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Add To Cart & Wishlist Controls */}
          <div className="space-y-6">
            <div className="flex gap-3 pt-4 border-t border-white/5">
              <motion.button
                whileHover={{ scale: 1.02, backgroundColor: addingState === 'success' ? '#10B981' : '#FFFFFF', color: addingState === 'success' ? '#FFFFFF' : '#000000' }}
                whileTap={{ scale: 0.98 }}
                disabled={addingState !== 'idle'}
                onClick={() => {
                  setAddingState('loading');
                  setTimeout(() => {
                    setAddingState('success');
                    onAddToCart(selectedShade, selectedSize);
                    setTimeout(() => {
                      setAddingState('idle');
                    }, 1500);
                  }, 700);
                }}
                className={`flex-1 text-xs uppercase tracking-widest font-extrabold py-4 px-6 rounded-2xl flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                  addingState === 'success'
                    ? 'bg-emerald-600 text-white border border-emerald-500'
                    : 'bg-gold text-black'
                }`}
                id="btn-add-to-cart-modal"
              >
                <AnimatePresence mode="wait">
                  {addingState === 'idle' && (
                    <motion.span
                      key="idle"
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      transition={{ duration: 0.15 }}
                      className="flex items-center justify-center gap-2"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      Add To Shopping Bag
                    </motion.span>
                  )}
                  {addingState === 'loading' && (
                    <motion.span
                      key="loading"
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      transition={{ duration: 0.15 }}
                      className="flex items-center justify-center gap-2"
                    >
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Adding to Bag...
                    </motion.span>
                  )}
                  {addingState === 'success' && (
                    <motion.span
                      key="success"
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      transition={{ duration: 0.15 }}
                      className="flex items-center justify-center gap-2 font-bold"
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                      Added to Bag!
                    </motion.span>
                  )}
                </AnimatePresence>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.92 }}
                onClick={onToggleWishlist}
                className="p-4 bg-white/5 text-white/80 border border-white/5 rounded-2xl transition-all cursor-pointer"
                aria-label="Wishlist"
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-gold text-gold' : ''}`} />
              </motion.button>
            </div>

            {/* Review Section */}
            <div className="border-t border-white/5 pt-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-sm font-semibold uppercase tracking-wider text-white flex items-center gap-1.5">
                  <MessageSquare className="w-4 h-4 text-gold" />
                  Verified Reviews ({product.reviews.length})
                </h4>
                <button
                  onClick={() => setShowReviewForm(!showReviewForm)}
                  className="text-xs font-semibold text-gold hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" /> Write Review
                </button>
              </div>

              {/* Review Submission Success Alert */}
              {reviewSuccess && (
                <div className="bg-emerald-950/40 text-emerald-300 border border-emerald-500/20 rounded-xl p-3 text-xs font-medium mb-4 animate-fadeIn">
                  Thank you! Your verified review has been published instantly.
                </div>
              )}

              {/* Interactive Write Review Form */}
              <AnimatePresence>
                {showReviewForm && (
                  <motion.form 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    onSubmit={handleReviewSubmit} 
                    className="bg-[#121212] rounded-2xl p-4 border border-white/5 mb-4 space-y-3 text-[#F5F5F0] overflow-hidden"
                  >
                    <p className="text-xs font-bold text-gold uppercase tracking-wider">Share Your Experience</p>
                    
                    {reviewError && (
                      <p className="text-xs text-red-400 font-medium">{reviewError}</p>
                    )}

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1 block">Your Name</label>
                        <input
                          type="text"
                          value={newAuthor}
                          onChange={(e) => setNewAuthor(e.target.value)}
                          className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-xs focus:outline-none focus:border-gold text-white"
                          placeholder="e.g. Marie L."
                          id="review-author"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1 block">Rating</label>
                        <select
                          value={newRating}
                          onChange={(e) => setNewRating(Number(e.target.value))}
                          className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-xs focus:outline-none focus:border-gold text-white font-semibold"
                          id="review-rating"
                        >
                          <option value={5}>⭐⭐⭐⭐⭐ (5/5)</option>
                          <option value={4}>⭐⭐⭐⭐ (4/5)</option>
                          <option value={3}>⭐⭐⭐ (3/5)</option>
                          <option value={2}>⭐⭐ (2/5)</option>
                          <option value={1}>⭐ (1/5)</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] text-white/40 uppercase tracking-wider font-bold mb-1 block">Your Comments</label>
                      <textarea
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-xs h-16 focus:outline-none focus:border-gold text-white resize-none"
                        placeholder="What did you love about this product?"
                        id="review-comment"
                      />
                    </div>

                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setShowReviewForm(false)}
                        className="px-3 py-1.5 bg-white/10 text-white text-xs rounded-lg font-medium hover:bg-white/15 cursor-pointer transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 bg-gold text-black text-xs rounded-lg font-bold hover:bg-white shadow-sm cursor-pointer transition-colors"
                      >
                        Post Review
                      </button>
                    </div>
                  </motion.form>
                )}
              </AnimatePresence>

              {/* Reviews Stack */}
              <div className="space-y-4 max-h-[220px] overflow-y-auto pr-2">
                {product.reviews.length === 0 ? (
                  <p className="text-white/40 text-xs italic text-center py-4">Be the first to leave a review for this product!</p>
                ) : (
                  product.reviews.map((rev) => (
                    <div key={rev.id} className="bg-[#121212] rounded-xl p-3 border border-white/5 text-xs space-y-1 text-white/80">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white">{rev.author}</span>
                        <span className="text-[10px] text-white/40">{rev.date}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${
                                i < rev.rating ? 'fill-gold text-gold' : 'text-white/10'
                              }`}
                            />
                          ))}
                        </div>
                        {rev.verified && (
                          <span className="text-[9px] uppercase tracking-wider font-bold text-gold bg-gold/10 px-1.5 py-0.5 rounded border border-gold/20">
                            Verified Buyer
                          </span>
                        )}
                      </div>
                      <p className="text-white/70 leading-relaxed mt-1">{rev.comment}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
