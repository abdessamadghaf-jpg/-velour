import React, { useState } from 'react';
import { ShoppingBag, Search, Sparkles, Heart, Menu, X, TrendingUp } from 'lucide-react';
import { Product } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenQuiz: () => void;
  onOpenDropship: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
}

export default function Navbar({
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onOpenQuiz,
  onOpenDropship,
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
}: NavbarProps) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const categories = ['All', 'Skincare', 'Cosmetics', 'Fragrance'];

  return (
    <header className="sticky top-0 z-40 bg-[#0A0A0A]/95 backdrop-blur-md border-b border-white/5 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Mobile Menu Toggle */}
          <div className="flex md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-white/70 hover:text-white transition-colors"
              aria-label="Toggle Menu"
              id="btn-mobile-menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Logo */}
          <div className="flex-1 md:flex-initial flex justify-center md:justify-start">
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSearchQuery('');
              }}
              className="text-2xl font-sans tracking-[0.25em] font-light text-white uppercase focus:outline-none cursor-pointer group"
              id="logo-brand"
            >
              Velour<motion.span 
                animate={{ scale: [1, 1.3, 1] }} 
                transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                className="text-gold font-normal inline-block"
              >.</motion.span>
            </button>
          </div>

          {/* Desktop Navigation Category Tabs */}
          <nav className="hidden md:flex space-x-8 lg:space-x-12">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`relative py-2 text-xs uppercase tracking-widest font-medium transition-all duration-300 cursor-pointer ${
                  selectedCategory === cat
                    ? 'text-gold font-semibold'
                    : 'text-white/60 hover:text-white'
                }`}
                id={`nav-cat-${cat.toLowerCase()}`}
              >
                <span className="relative z-10">{cat}</span>
                {selectedCategory === cat && (
                  <motion.span 
                    layoutId="activeCategory"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    className="absolute bottom-0 left-0 w-full h-[1.5px] bg-gold" 
                  />
                )}
              </button>
            ))}
          </nav>

          {/* Interactive Utility Icons */}
          <div className="flex items-center space-x-3 sm:space-x-6">
            {/* Search Toggle */}
            <div className="relative flex items-center">
              <AnimatePresence>
                {isSearchOpen && (
                  <motion.input
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: window.innerWidth < 640 ? 120 : 240, opacity: 1 }}
                    exit={{ width: 0, opacity: 0 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                    type="text"
                    placeholder="Search products, ingredients..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-white/5 border border-white/10 text-white text-xs px-3 py-1.5 pr-8 rounded-full focus:outline-none focus:border-gold placeholder-white/30"
                    autoFocus
                    id="nav-search-input"
                  />
                )}
              </AnimatePresence>
              <button
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                className="p-2 text-white/70 hover:text-white transition-colors cursor-pointer"
                aria-label="Search"
                id="btn-search-toggle"
              >
                <Search className="w-[18px] h-[18px]" />
              </button>
            </div>

            {/* Virtual Skin Consultation / Quiz Button */}
            <motion.button
              whileHover={{ scale: 1.05, shadow: "0px 0px 15px rgba(212,175,55,0.3)" }}
              whileTap={{ scale: 0.95 }}
              onClick={onOpenQuiz}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gold/10 hover:bg-gold/20 text-gold text-[10px] sm:text-xs font-semibold tracking-wider uppercase rounded-full border border-gold/30 transition-all cursor-pointer shadow-sm"
              id="btn-skin-consultation"
            >
              <Sparkles className="w-3.5 h-3.5 text-gold animate-pulse" />
              <span className="hidden sm:inline">Skin Care Analysis</span>
              <span className="sm:hidden">Consult</span>
            </motion.button>

            {/* Dropship Strategy Hub Button */}
            <motion.button
              whileHover={{ scale: 1.05, shadow: "0px 0px 15px rgba(212,175,55,0.3)" }}
              whileTap={{ scale: 0.95 }}
              onClick={onOpenDropship}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-gold/10 text-white hover:text-gold text-[10px] sm:text-xs font-semibold tracking-wider uppercase rounded-full border border-white/10 hover:border-gold/30 transition-all cursor-pointer shadow-sm"
              id="btn-dropship-strategy"
            >
              <TrendingUp className="w-3.5 h-3.5 text-gold" />
              <span className="hidden sm:inline">Partner Strategy</span>
              <span className="sm:hidden">Partner</span>
            </motion.button>

            {/* Wishlist */}
            <button
              onClick={onOpenWishlist}
              className="relative p-2 text-white/70 hover:text-white transition-colors cursor-pointer"
              aria-label="Wishlist"
              id="btn-wishlist-toggle"
            >
              <Heart className={`w-[18px] h-[18px] ${wishlistCount > 0 ? 'fill-gold text-gold' : ''}`} />
              {wishlistCount > 0 && (
                <motion.span 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 bg-gold text-black text-[9px] rounded-full w-4 h-4 flex items-center justify-center font-bold"
                >
                  {wishlistCount}
                </motion.span>
              )}
            </button>

            {/* Shopping Cart Drawer Trigger */}
            <motion.button
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.95 }}
              onClick={onOpenCart}
              className="relative p-2.5 bg-gold hover:bg-white text-black rounded-full transition-all duration-300 shadow-sm cursor-pointer"
              aria-label="Cart"
              id="btn-cart-toggle"
            >
              <ShoppingBag className="w-4 h-4" />
              {cartCount > 0 && (
                <motion.span 
                  initial={{ scale: 0, y: 10 }}
                  animate={{ scale: 1, y: 0 }}
                  transition={{ type: 'spring', stiffness: 500, damping: 15 }}
                  className="absolute -top-1.5 -right-1.5 bg-white text-black text-[9px] rounded-full w-5 h-5 flex items-center justify-center font-bold border-2 border-gold shadow-sm"
                >
                  {cartCount}
                </motion.span>
              )}
            </motion.button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden border-t border-white/5 bg-[#0A0A0A] px-4 py-6 space-y-4 shadow-lg overflow-hidden"
          >
            <div className="flex flex-col space-y-3">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => {
                    setSelectedCategory(cat);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`py-2 text-left text-xs uppercase tracking-widest font-medium ${
                    selectedCategory === cat ? 'text-gold font-semibold' : 'text-white/60'
                  }`}
                  id={`mobile-cat-${cat.toLowerCase()}`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
