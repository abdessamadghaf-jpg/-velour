import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';

interface Sparkle {
  id: string;
  x: number;
  y: number;
  size: number;
  color: string;
  isPercent?: boolean;
}

export default function SparkleOverlay() {
  const [sparkles, setSparkles] = useState<Sparkle[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  const lastMoveTime = useRef(0);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const parent = container.parentElement;
    if (!parent) return;

    // Mouse move handler for interactive golden sparkles
    const handleMouseMove = (e: MouseEvent) => {
      const now = Date.now();
      if (now - lastMoveTime.current < 60) return; // Elegant throttle for performance and beauty
      lastMoveTime.current = now;

      const rect = parent.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      // Ensure cursor is within physical boundaries
      if (x < 0 || x > rect.width || y < 0 || y > rect.height) return;

      const colors = ['#D4AF37', '#FFFFFF', '#ECE2C6', '#F5F5F0'];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      const randomSize = Math.random() * 8 + 6; // Exquisite 6px - 14px sparkles

      const newSparkle: Sparkle = {
        id: `mouse-${now}-${Math.random()}`,
        x,
        y,
        size: randomSize,
        color: randomColor,
      };

      // Keep array small to prevent memory leaks or rendering overhead
      setSparkles((prev) => [...prev.slice(-8), newSparkle]);
    };

    // Ambient floating golden star icons
    let ambientInterval: NodeJS.Timeout | null = null;

    const handleMouseEnter = () => {
      ambientInterval = setInterval(() => {
        const colors = ['#D4AF37', '#FFFFFF', '#ECE2C6', '#F5F5F0'];
        const randomColor = colors[Math.floor(Math.random() * colors.length)];
        const randomSize = Math.random() * 6 + 4; // Tiny ambient star (4px - 10px)
        
        const x = Math.random() * 100;
        const y = Math.random() * 100;

        const newSparkle: Sparkle = {
          id: `ambient-${Date.now()}-${Math.random()}`,
          x,
          y,
          size: randomSize,
          color: randomColor,
          isPercent: true,
        };

        setSparkles((prev) => [...prev.slice(-8), newSparkle]);
      }, 450);
    };

    const handleMouseLeave = () => {
      if (ambientInterval) {
        clearInterval(ambientInterval);
        ambientInterval = null;
      }
      setSparkles([]);
    };

    parent.addEventListener('mousemove', handleMouseMove);
    parent.addEventListener('mouseenter', handleMouseEnter);
    parent.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      parent.removeEventListener('mousemove', handleMouseMove);
      parent.removeEventListener('mouseenter', handleMouseEnter);
      parent.removeEventListener('mouseleave', handleMouseLeave);
      if (ambientInterval) clearInterval(ambientInterval);
    };
  }, []);

  return (
    <div ref={containerRef} className="absolute inset-0 pointer-events-none overflow-hidden z-20">
      {sparkles.map((sparkle) => (
        <motion.div
          key={sparkle.id}
          initial={{ opacity: 0, scale: 0, rotate: 0 }}
          animate={{ 
            opacity: [0, 1, 1, 0], 
            scale: [0, 1.2, 0.8, 0],
            rotate: [0, 90, 180],
            y: [0, Math.random() * -30 - 15], // Subtle rising motion
            x: [0, (Math.random() - 0.5) * 20] // Elegant side drift
          }}
          transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
          onAnimationComplete={() => {
            setSparkles((prev) => prev.filter((s) => s.id !== sparkle.id));
          }}
          className="absolute flex items-center justify-center"
          style={{
            left: sparkle.isPercent ? `${sparkle.x}%` : sparkle.x,
            top: sparkle.isPercent ? `${sparkle.y}%` : sparkle.y,
            width: sparkle.size,
            height: sparkle.size,
            color: sparkle.color,
            transform: 'translate(-50%, -50%)',
          }}
        >
          <svg viewBox="0 0 24 24" className="w-full h-full fill-current drop-shadow-[0_0_4px_rgba(212,175,55,0.5)]">
            <path d="M12 0L14.6 9.4L24 12L14.6 14.6L12 24L9.4 14.6L0 12L9.4 9.4L12 0Z" />
          </svg>
        </motion.div>
      ))}
    </div>
  );
}
