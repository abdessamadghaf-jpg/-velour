import React from 'react';
import { Heart, Star, ShoppingBag, Info, Check, Loader2 } from 'lucide-react';
import { Product } from '../types';
import { motion, AnimatePresence, useMotionValue, useSpring, useTransform } from 'motion/react';
import SparkleOverlay from './SparkleOverlay';

interface ProductCardProps {
  key?: string;
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: () => void;
  onOpenDetails: () => void;
  onAddToCart: (shade?: { name: string; hex: string }, size?: string) => void;
}

export default function ProductCard({
  product,
  isWishlisted,
  onToggleWishlist,
  onOpenDetails,
  onAddToCart,
}: ProductCardProps) {
  // Determine if product has shade/size pickers that prevent instant checkout
  const hasVariants = (product.shades && product.shades.length > 0) || (product.sizes && product.sizes.length > 0);

  // Motion values for high-performance 3D perspective tilt without triggering state re-renders
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  // We map the normalized mouse values (-0.5 to 0.5) to beautiful tilt degrees (-8 to 8)
  const rotateX = useTransform(y, [-0.5, 0.5], [8, -8]);
  const rotateY = useTransform(x, [-0.5, 0.5], [-8, 8]);

  // Buttery smooth spring physics for high-end luxury feel
  const rotateXSpring = useSpring(rotateX, { stiffness: 90, damping: 18 });
  const rotateYSpring = useSpring(rotateY, { stiffness: 90, damping: 18 });

  // States for Add to Bag loading/success feedback
  const [addingState, setAddingState] = React.useState<'idle' | 'loading' | 'success'>('idle');

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    
    // Normalize coordinates from -0.5 to 0.5
    const valX = (e.clientX - rect.left) / width - 0.5;
    const valY = (e.clientY - rect.top) / height - 0.5;

    x.set(valX);
    y.set(valY);
  };

  const handleMouseLeave = () => {
    // Smoothly spring back to flat resting state
    x.set(0);
    y.set(0);
  };

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (hasVariants) {
      // If it has variants, open details modal to let them select
      onOpenDetails();
    } else {
      // Direct add to cart with temporary state animations
      setAddingState('loading');
      setTimeout(() => {
        setAddingState('success');
        onAddToCart();
        setTimeout(() => {
          setAddingState('idle');
        }, 800); // Success state check-mark persists for exactly 800ms
      }, 700);
    }
  };

  return (
    <motion.div
      variants={{
        hidden: { 
          opacity: 0, 
          y: 45, 
          rotateX: 10, 
          rotateY: -4, 
          scale: 0.97 
        },
        show: { 
          opacity: 1, 
          y: 0, 
          rotateX: 0, 
          rotateY: 0, 
          scale: 1,
          transition: {
            duration: 0.85,
            ease: [0.16, 1, 0.3, 1]
          }
        }
      }}
      whileHover={{ 
        y: -6, 
        scale: 1.015,
        rotateX: rotateXSpring,
        rotateY: rotateYSpring,
      }}
      style={{
        transformStyle: 'preserve-3d',
        perspective: 1000,
      }}
      onClick={onOpenDetails}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="group bg-[#121212] border border-white/5 rounded-2xl overflow-hidden cursor-pointer shadow-sm hover:shadow-2xl hover:border-gold/20 transition-all duration-300 flex flex-col h-full relative"
      id={`product-card-${product.id}`}
    >
      {/* Reusable premium cursor sparkles & ambient stars overlay */}
      <SparkleOverlay />

      {/* Product Image Stage */}
      <div className="relative aspect-[4/5] bg-[#151515] overflow-hidden" style={{ transform: 'translateZ(20px)' }}>
        <motion.img
          src={product.image}
          alt={product.name}
          whileHover={{ scale: 1.06 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="w-full h-full object-cover opacity-90 group-hover:opacity-100"
          referrerPolicy="no-referrer"
          loading="lazy"
        />

        {/* Decorative Glassmorphic Header Badges */}
        <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
          {product.bestSeller && (
            <motion.span 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="backdrop-blur-md bg-gold/90 text-black text-[9px] uppercase tracking-widest font-extrabold px-2.5 py-1 rounded-full shadow-sm"
            >
              Best Seller
            </motion.span>
          )}
          {product.stock <= 5 && (
            <span className="backdrop-blur-md bg-amber-500/90 text-white text-[9px] uppercase tracking-widest font-semibold px-2.5 py-1 rounded-full shadow-sm">
              Only {product.stock} Left
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <motion.button
          whileHover={{ scale: 1.15 }}
          whileTap={{ scale: 0.9 }}
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist();
          }}
          className="absolute top-4 right-4 p-2.5 bg-black/80 backdrop-blur-md border border-white/10 text-white/70 hover:text-gold rounded-full transition-all duration-300 shadow-sm cursor-pointer z-10"
          aria-label="Add to Wishlist"
          id={`btn-wishlist-${product.id}`}
        >
          <Heart className={`w-[15px] h-[15px] transition-colors ${isWishlisted ? 'fill-gold text-gold' : ''}`} />
        </motion.button>

        {/* Quick Add Overlay on Hover - Smooth slide-up transition with responsive states */}
        <div className="absolute inset-x-4 bottom-4 translate-y-3 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 ease-out flex gap-2 z-10">
          <motion.button
            whileHover={{ scale: 1.02, backgroundColor: addingState === 'success' ? '#10B981' : '#FFFFFF', color: addingState === 'success' ? '#FFFFFF' : '#000000' }}
            whileTap={{ scale: 0.98 }}
            disabled={addingState !== 'idle'}
            onClick={handleQuickAdd}
            className={`flex-1 text-[10px] uppercase tracking-widest font-extrabold py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-lg transition-all duration-200 cursor-pointer ${
              addingState === 'success' 
                ? 'bg-emerald-600 text-white border border-emerald-500' 
                : 'bg-gold text-black'
            }`}
            id={`btn-quick-add-${product.id}`}
          >
            <AnimatePresence mode="wait">
              {addingState === 'idle' && (
                <motion.span
                  key="idle"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  transition={{ duration: 0.15 }}
                  className="flex items-center justify-center gap-1.5"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  {hasVariants ? 'Select Options' : 'Quick Add'}
                </motion.span>
              )}
              {addingState === 'loading' && (
                <motion.span
                  key="loading"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  transition={{ duration: 0.15 }}
                  className="flex items-center justify-center gap-1.5"
                >
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Adding...
                </motion.span>
              )}
              {addingState === 'success' && (
                <motion.span
                  key="success"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  transition={{ duration: 0.15 }}
                  className="flex items-center justify-center gap-1.5 font-bold"
                >
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                  Added!
                </motion.span>
              )}
            </AnimatePresence>
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.1, backgroundColor: 'rgba(255, 255, 255, 0.15)' }}
            whileTap={{ scale: 0.9 }}
            onClick={(e) => {
              e.stopPropagation();
              onOpenDetails();
            }}
            className="p-3 bg-white/5 text-white rounded-xl shadow-lg border border-white/10 flex items-center justify-center transition-all cursor-pointer"
            aria-label="View Details"
          >
            <Info className="w-4 h-4" />
          </motion.button>
        </div>
      </div>

      {/* Product Information Body */}
      <div className="p-5 flex-1 flex flex-col justify-between" style={{ transform: 'translateZ(10px)' }}>
        <div>
          {/* Category */}
          <span className="text-[10px] uppercase tracking-widest text-gold/80 font-bold mb-1 block">
            {product.category}
          </span>

          {/* Product Name */}
          <h3 className="font-sans font-medium text-sm text-[#F5F5F0] line-clamp-1 group-hover:text-gold transition-colors duration-200">
            {product.name}
          </h3>

          {/* Short Description */}
          <p className="text-white/60 text-xs mt-1.5 line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Pricing & Ratings */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5">
          <span className="text-sm font-semibold text-gold font-mono">
            ${product.price.toFixed(2)}
          </span>

          <div className="flex items-center space-x-1">
            <Star className="w-3.5 h-3.5 fill-gold text-gold" />
            <span className="text-xs font-bold text-white/80">{product.rating}</span>
            <span className="text-[10px] text-white/40 font-medium">({product.reviewsCount})</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
