import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  TrendingUp, 
  Coins, 
  Percent, 
  Video, 
  Search, 
  Share2, 
  DollarSign, 
  Calculator, 
  Award, 
  ArrowUpRight, 
  CheckCircle2, 
  X,
  Target,
  FileText,
  MousePointer,
  Sparkles,
  BarChart3,
  Flame,
  Check
} from 'lucide-react';
import { Product } from '../types';

interface DropshipDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
}

export default function DropshipDashboard({ isOpen, onClose, products }: DropshipDashboardProps) {
  const [activeTab, setActiveTab] = useState<'trends' | 'calculator' | 'tiktok' | 'seo'>('trends');
  
  // Custom strategic dropship details mapped for the trending best sellers
  const dropshipDetails: Record<string, {
    cogs: number; // Cost of goods sold (wholesale price)
    suggestedRetail: number;
    amazonRank: string; // Amazon Best Seller Rank
    tiktokViews: string; // TikTok hashtag views
    googleTrendIndex: number; // Search index score (out of 100)
    targetAudience: string;
    aliexpressLink: string;
    hookScript: string;
  }> = {
    'snail-mucin-hydrator': {
      cogs: 3.50,
      suggestedRetail: 22.00,
      amazonRank: '#1 in Facial Serums & Essences',
      tiktokViews: '1.4 Billion Views (#snailmucin)',
      googleTrendIndex: 98,
      targetAudience: 'Skincare enthusiasts, Gen-Z / Millennials targeting acne scarring & hydration',
      aliexpressLink: 'https://aliexpress.com',
      hookScript: '“Stop wasting $100 on multi-step routines. This 1 viral Korean ingredient literally gave me glass skin in 3 days. Here is the proof…”'
    },
    'milky-rice-toner': {
      cogs: 4.10,
      suggestedRetail: 26.00,
      amazonRank: '#4 in Facial Toners',
      tiktokViews: '420 Million Views (#ricetoner)',
      googleTrendIndex: 85,
      targetAudience: 'People seeking skin barrier repair, soothing redness, and gentle whitening',
      aliexpressLink: 'https://aliexpress.com',
      hookScript: '“If your skin barrier is red, flaky, or damaged, stop using active acids. You need a dual-phase milky rice shake. Look what it does on contact…”'
    },
    'melon-dew-serum': {
      cogs: 4.80,
      suggestedRetail: 32.00,
      amazonRank: '#8 in Face Primers & Illuminators',
      tiktokViews: '780 Million Views (#glowdrops)',
      googleTrendIndex: 91,
      targetAudience: 'Highlighters and makeup lovers looking for organic non-grey glowing bases',
      aliexpressLink: 'https://aliexpress.com',
      hookScript: '“The beauty industry is lying to you about liquid highlighters. Watch this zero-makeup dew drops primer melt into glass-skin instantly…”'
    },
    'peptide-lip-oil': {
      cogs: 1.90,
      suggestedRetail: 24.00,
      amazonRank: '#2 in Lip Gloss & Plumpers',
      tiktokViews: '1.2 Billion Views (#lipoil)',
      googleTrendIndex: 95,
      targetAudience: 'Beauty, lip care, trend-driven makeup users, clean-girl aesthetic followers',
      aliexpressLink: 'https://aliexpress.com',
      hookScript: '“The real secret to high-shine plumped lips without the sticky hair trap? It is peptides, not plastic surgery. Let’s do a smudge-proof test…”'
    },
    'glow-guard-sunscreen': {
      cogs: 3.20,
      suggestedRetail: 28.00,
      amazonRank: '#3 in Face Sunscreens',
      tiktokViews: '610 Million Views (#koreansunscreen)',
      googleTrendIndex: 89,
      targetAudience: 'Daily sun protection users, makeup-wearers wanting lightweight water gel bases',
      aliexpressLink: 'https://aliexpress.com',
      hookScript: '“If your sunscreen leaves a white ghost cast, burns your eyes, or pilled your makeup, you are using the wrong SPF. Watch this clear water gel test…”'
    }
  };

  // Interactive Profit Calculator States
  const [selectedProductCalculator, setSelectedProductCalculator] = useState<string>('snail-mucin-hydrator');
  const [dailyOrderCount, setDailyOrderCount] = useState<number>(30);
  const [adSpendPerOrder, setAdSpendPerOrder] = useState<number>(8); // Target CPA (Cost per Acquisition)
  const [otherFees, setOtherFees] = useState<number>(1.5); // Shopify, transaction fees, shipping fees

  const currentCalcProduct = products.find(p => p.id === selectedProductCalculator) || products[0];
  const calcData = dropshipDetails[selectedProductCalculator] || { cogs: 3.5, suggestedRetail: 22.00 };

  const marginPerUnit = calcData.suggestedRetail - calcData.cogs - adSpendPerOrder - otherFees;
  const dailyRevenue = dailyOrderCount * calcData.suggestedRetail;
  const dailyCost = dailyOrderCount * (calcData.cogs + adSpendPerOrder + otherFees);
  const dailyProfit = dailyOrderCount * marginPerUnit;
  const monthlyProfit = dailyProfit * 30;
  const returnOnAdSpend = (calcData.suggestedRetail / adSpendPerOrder).toFixed(2);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/85 backdrop-blur-md"
          />

          {/* Modal content */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', duration: 0.6 }}
            className="relative bg-[#0E0E0E] border border-white/10 w-full max-w-5xl rounded-3xl overflow-hidden shadow-2xl z-10 flex flex-col max-h-[90vh]"
            id="dropship-strategy-modal"
          >
            {/* Elegant Header */}
            <div className="p-6 border-b border-white/5 flex items-center justify-between bg-gradient-to-r from-gold/10 via-transparent to-transparent">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-gold/10 border border-gold/30 rounded-xl text-gold">
                  <TrendingUp className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h2 className="text-xl font-sans font-light tracking-widest text-white uppercase flex items-center gap-2">
                    Partner Dropship <span className="text-gold font-normal">Strategy Hub</span>
                  </h2>
                  <p className="text-[11px] text-white/40 tracking-wider font-mono">
                    REAL-TIME MARKET ANALYSIS • AMAZON BSR • TIKTOK SHOP HYPER-GROWTH • ANALYTICS BLUEPRINT
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="p-2 bg-white/5 text-white/60 hover:text-white rounded-full border border-white/10 transition-colors cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content Stage */}
            <div className="flex-1 overflow-y-auto p-6 md:p-8 flex flex-col md:flex-row gap-6">
              
              {/* Left sidebar: Tabs & Summary */}
              <div className="w-full md:w-64 flex flex-col gap-4 shrink-0">
                <div className="p-4 bg-white/5 border border-white/5 rounded-2xl">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-gold font-mono block mb-1">
                    Partnership Status
                  </span>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-xs font-semibold text-[#F5F5F0]">100% Dropship Connected</span>
                  </div>
                  <p className="text-[10px] text-white/50 mt-2 leading-relaxed">
                    Product margins, suppliers, ad copies, and custom SEO templates are synced live.
                  </p>
                </div>

                {/* Tabs */}
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => setActiveTab('trends')}
                    className={`flex items-center gap-3 px-4 py-3.5 rounded-xl text-xs uppercase tracking-widest font-semibold transition-all border text-left cursor-pointer ${
                      activeTab === 'trends'
                        ? 'bg-gold text-black border-gold shadow-lg font-bold'
                        : 'bg-white/5 text-white/60 hover:text-white border-white/5 hover:bg-white/10'
                    }`}
                  >
                    <BarChart3 className="w-4 h-4" />
                    Catalog & Margin
                  </button>

                  <button
                    onClick={() => setActiveTab('calculator')}
                    className={`flex items-center gap-3 px-4 py-3.5 rounded-xl text-xs uppercase tracking-widest font-semibold transition-all border text-left cursor-pointer ${
                      activeTab === 'calculator'
                        ? 'bg-gold text-black border-gold shadow-lg font-bold'
                        : 'bg-white/5 text-white/60 hover:text-white border-white/5 hover:bg-white/10'
                    }`}
                  >
                    <Calculator className="w-4 h-4" />
                    Profit Calculator
                  </button>

                  <button
                    onClick={() => setActiveTab('tiktok')}
                    className={`flex items-center gap-3 px-4 py-3.5 rounded-xl text-xs uppercase tracking-widest font-semibold transition-all border text-left cursor-pointer ${
                      activeTab === 'tiktok'
                        ? 'bg-gold text-black border-gold shadow-lg font-bold'
                        : 'bg-white/5 text-white/60 hover:text-white border-white/5 hover:bg-white/10'
                    }`}
                  >
                    <Video className="w-4 h-4" />
                    TikTok Ad Copy
                  </button>

                  <button
                    onClick={() => setActiveTab('seo')}
                    className={`flex items-center gap-3 px-4 py-3.5 rounded-xl text-xs uppercase tracking-widest font-semibold transition-all border text-left cursor-pointer ${
                      activeTab === 'seo'
                        ? 'bg-gold text-black border-gold shadow-lg font-bold'
                        : 'bg-white/5 text-white/60 hover:text-white border-white/5 hover:bg-white/10'
                    }`}
                  >
                    <Search className="w-4 h-4" />
                    SEO Search Matrix
                  </button>
                </div>
              </div>

              {/* Right Panel: Tab Contents */}
              <div className="flex-1 bg-white/[0.02] border border-white/5 rounded-3xl p-6 overflow-y-auto">
                
                {/* 1. Trends & Margins Tab */}
                {activeTab === 'trends' && (
                  <div className="space-y-6">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-lg font-sans font-medium text-white flex items-center gap-2">
                          High-Converting Viral Dropship Catalog
                        </h3>
                        <p className="text-xs text-white/60 leading-relaxed mt-1">
                          We mapped these five absolute best-sellers with real TikTok and Amazon momentum. Leverage extreme markup potentials with ultra-low COGS.
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-4">
                      {products
                        .filter(p => dropshipDetails[p.id])
                        .map(product => {
                          const details = dropshipDetails[product.id];
                          const margin = ((product.price - details.cogs) / product.price * 100).toFixed(0);
                          return (
                            <div key={product.id} className="p-4 bg-white/5 border border-white/5 rounded-2xl hover:border-gold/30 transition-all flex flex-col sm:flex-row gap-4 items-center">
                              <img 
                                src={product.image} 
                                alt={product.name} 
                                className="w-16 h-16 rounded-xl object-cover border border-white/10"
                                referrerPolicy="no-referrer"
                              />
                              <div className="flex-1 text-center sm:text-left">
                                <div className="flex items-center justify-center sm:justify-start gap-2">
                                  <h4 className="text-xs font-bold text-white uppercase tracking-wide">
                                    {product.name}
                                  </h4>
                                  <span className="text-[9px] bg-gold/10 text-gold border border-gold/20 px-1.5 py-0.5 rounded">
                                    {margin}% Margin
                                  </span>
                                </div>
                                <p className="text-[11px] text-white/50 mt-1 line-clamp-1">
                                  {product.description}
                                </p>
                                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-x-4 gap-y-1 mt-2 font-mono text-[10px]">
                                  <span className="text-gold flex items-center gap-1">
                                    <Flame className="w-3.5 h-3.5 text-orange-500 fill-orange-500" /> BSR: {details.amazonRank}
                                  </span>
                                  <span className="text-white/60">
                                    TikTok: {details.tiktokViews}
                                  </span>
                                </div>
                              </div>
                              <div className="flex gap-4 shrink-0 font-mono text-center sm:text-right border-t sm:border-t-0 border-white/5 pt-3 sm:pt-0 w-full sm:w-auto justify-around sm:justify-end">
                                <div>
                                  <span className="text-[9px] text-white/40 uppercase block">COGS</span>
                                  <span className="text-xs font-bold text-white">${details.cogs.toFixed(2)}</span>
                                </div>
                                <div>
                                  <span className="text-[9px] text-white/40 uppercase block">RRP</span>
                                  <span className="text-xs font-bold text-gold">${product.price.toFixed(2)}</span>
                                </div>
                                <div>
                                  <span className="text-[9px] text-[#10B981] uppercase block">Net Gain</span>
                                  <span className="text-xs font-bold text-[#10B981]">${(product.price - details.cogs).toFixed(2)}</span>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                    </div>

                    <div className="p-4 bg-gold/5 border border-gold/10 rounded-2xl flex items-start gap-3 mt-4">
                      <Award className="w-5 h-5 text-gold shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-xs font-bold text-gold uppercase tracking-wider">
                          Partner Sourcing Recommendation
                        </h4>
                        <p className="text-[11px] text-white/70 leading-relaxed mt-1">
                          We recommend starting with custom dropship integration through private sourcing agents on <b>CJ Dropshipping</b> or <b>AliExpress VIP</b> to handle 7-12 day delivery worldwide. Once you reach 20 orders/day, negotiate custom aesthetic packaging (private labeling) to elevate the perceived luxury value of Velour.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* 2. Dropship Profit Calculator */}
                {activeTab === 'calculator' && (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-sans font-medium text-white flex items-center gap-2">
                        Interactive Profit Engine
                      </h3>
                      <p className="text-xs text-white/60 mt-1">
                        Select a viral product and fine-tune your marketing numbers to view simulated daily and monthly revenue, ROAS, and net margins.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      
                      {/* Left inputs */}
                      <div className="space-y-4">
                        <div>
                          <label className="text-[10px] uppercase font-bold tracking-widest text-white/60 font-mono block mb-1.5">
                            Select Target Product
                          </label>
                          <select 
                            value={selectedProductCalculator} 
                            onChange={(e) => setSelectedProductCalculator(e.target.value)}
                            className="w-full bg-[#151515] border border-white/10 text-white text-xs px-3 py-2.5 rounded-xl focus:border-gold focus:outline-none"
                          >
                            {products
                              .filter(p => dropshipDetails[p.id])
                              .map(p => (
                                <option key={p.id} value={p.id}>{p.name}</option>
                              ))}
                          </select>
                        </div>

                        <div>
                          <div className="flex justify-between text-[10px] uppercase font-bold tracking-widest text-white/60 font-mono mb-1.5">
                            <span>Daily Order Velocity</span>
                            <span className="text-gold font-bold font-mono">{dailyOrderCount} Orders / Day</span>
                          </div>
                          <input 
                            type="range" 
                            min="5" 
                            max="150" 
                            value={dailyOrderCount} 
                            onChange={(e) => setDailyOrderCount(Number(e.target.value))}
                            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-gold"
                          />
                        </div>

                        <div>
                          <div className="flex justify-between text-[10px] uppercase font-bold tracking-widest text-white/60 font-mono mb-1.5">
                            <span>Target Ad Cost per Sale (CPA)</span>
                            <span className="text-gold font-bold font-mono">${adSpendPerOrder} CPA</span>
                          </div>
                          <input 
                            type="range" 
                            min="3" 
                            max="18" 
                            value={adSpendPerOrder} 
                            onChange={(e) => setAdSpendPerOrder(Number(e.target.value))}
                            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-gold"
                          />
                          <p className="text-[10px] text-white/40 mt-1">
                            Calculated average cost on TikTok Ads/Meta Ads to secure a single customer conversion.
                          </p>
                        </div>

                        <div>
                          <div className="flex justify-between text-[10px] uppercase font-bold tracking-widest text-white/60 font-mono mb-1.5">
                            <span>Shipping & Shopify Fees</span>
                            <span className="text-gold font-bold font-mono">${otherFees} / Order</span>
                          </div>
                          <input 
                            type="range" 
                            min="0.5" 
                            max="5" 
                            step="0.5"
                            value={otherFees} 
                            onChange={(e) => setOtherFees(Number(e.target.value))}
                            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-gold"
                          />
                        </div>
                      </div>

                      {/* Right output analytics */}
                      <div className="p-5 bg-white/5 border border-white/5 rounded-2xl flex flex-col justify-between space-y-4">
                        <div className="flex items-center gap-3 border-b border-white/5 pb-3">
                          <img 
                            src={currentCalcProduct.image} 
                            alt={currentCalcProduct.name} 
                            className="w-12 h-12 rounded-xl object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <span className="text-[9px] uppercase font-bold tracking-wider text-gold font-mono block">
                              Live Financial Analysis
                            </span>
                            <h4 className="text-xs font-bold text-white line-clamp-1 uppercase">
                              {currentCalcProduct.name}
                            </h4>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4 font-mono text-center">
                          <div className="bg-white/[0.02] p-3 rounded-xl border border-white/5">
                            <span className="text-[9px] text-white/50 block uppercase">Product Price</span>
                            <span className="text-sm font-bold text-white">${currentCalcProduct.price.toFixed(2)}</span>
                          </div>
                          <div className="bg-white/[0.02] p-3 rounded-xl border border-white/5">
                            <span className="text-[9px] text-white/50 block uppercase">Fulfillment Cost</span>
                            <span className="text-sm font-bold text-white">${calcData.cogs.toFixed(2)}</span>
                          </div>
                          <div className="bg-white/[0.02] p-3 rounded-xl border border-white/5">
                            <span className="text-[9px] text-white/50 block uppercase">Simulated ROAS</span>
                            <span className="text-sm font-bold text-gold">{returnOnAdSpend}x</span>
                          </div>
                          <div className="bg-white/[0.02] p-3 rounded-xl border border-[#10B981]/10">
                            <span className="text-[9px] text-white/50 block uppercase">Net margin %</span>
                            <span className="text-sm font-bold text-[#10B981]">
                              {((marginPerUnit / currentCalcProduct.price) * 100).toFixed(0)}%
                            </span>
                          </div>
                        </div>

                        <div className="space-y-2 border-t border-white/5 pt-3">
                          <div className="flex justify-between text-xs font-mono">
                            <span className="text-white/60">Estimated Daily Revenue</span>
                            <span className="text-white font-bold">${dailyRevenue.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-xs font-mono">
                            <span className="text-white/60">Estimated Daily Marketing Cost</span>
                            <span className="text-[#EF4444] font-bold">-${dailyCost.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-sm font-mono font-bold border-t border-white/5 pt-2">
                            <span className="text-gold">Estimated Net Daily Profit</span>
                            <span className="text-[#10B981]">${dailyProfit.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-base font-mono font-bold pt-1">
                            <span className="text-white uppercase tracking-wider text-[11px]">Est. Monthly Passive Income</span>
                            <span className="text-gold font-extrabold text-lg">${monthlyProfit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>
                )}

                {/* 3. TikTok Ad Script & Hook Formulas */}
                {activeTab === 'tiktok' && (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-sans font-medium text-white flex items-center gap-2">
                        TikTok Viral Ads Playbook
                      </h3>
                      <p className="text-xs text-white/60 mt-1">
                        Dropshipping conversion rests 90% on the first 3 seconds of your video ad. Use these custom, high-converting hook formulations specifically written for our viral products.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 gap-4">
                      {products
                        .filter(p => dropshipDetails[p.id])
                        .map(p => {
                          const details = dropshipDetails[p.id];
                          return (
                            <div key={p.id} className="p-4 bg-white/5 border border-white/5 rounded-2xl space-y-3">
                              <div className="flex items-center gap-2">
                                <span className="p-1 bg-gold/10 text-gold rounded-lg">
                                  <Video className="w-4 h-4" />
                                </span>
                                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                                  {p.name} — High-CTR Video Hook
                                </h4>
                              </div>
                              
                              <blockquote className="border-l-2 border-gold pl-3 py-1 text-xs italic text-white/80 bg-gold/[0.02]">
                                {details.hookScript}
                              </blockquote>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 text-[11px]">
                                <div className="space-y-1">
                                  <span className="text-[9px] uppercase font-bold tracking-widest text-white/40 block font-mono">
                                    Creator Content Angle
                                  </span>
                                  <p className="text-white/60 leading-relaxed">
                                    Show a close-up texture shot, apply the skin essence to wet skin showing zero sticky fibers, and show clear, makeup-free glass skin with beautiful light reflections.
                                  </p>
                                </div>
                                <div className="space-y-1">
                                  <span className="text-[9px] uppercase font-bold tracking-widest text-white/40 block font-mono">
                                    Target Demographics (Meta/TikTok Ads)
                                  </span>
                                  <p className="text-white/60 leading-relaxed">
                                    Female, age 18-34, interests: Korean Beauty (K-Beauty), Acne Solutions, Glass Skin, Sephora, Selfcare.
                                  </p>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                )}

                {/* 4. Google SEO and Search Intent Matrix */}
                {activeTab === 'seo' && (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-sans font-medium text-white flex items-center gap-2">
                        Google & SEO Search Matrix
                      </h3>
                      <p className="text-xs text-white/60 mt-1">
                        Capture high-intent searches of buyers looking for answers to skincare issues. Ranking for these search terms delivers organic, high-converting traffic with zero ad cost.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-white/5 border border-white/5 rounded-2xl space-y-3">
                        <div className="flex items-center gap-2 text-gold">
                          <Search className="w-4 h-4" />
                          <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                            High-Volume Search Queries
                          </h4>
                        </div>
                        <ul className="space-y-2 text-xs text-white/60">
                          <li className="flex justify-between border-b border-white/5 pb-1.5">
                            <span>"snail mucin break out treatment"</span>
                            <span className="text-gold font-mono font-bold">54K/mo</span>
                          </li>
                          <li className="flex justify-between border-b border-white/5 pb-1.5">
                            <span>"milky rice toner for red skin"</span>
                            <span className="text-gold font-mono font-bold">32K/mo</span>
                          </li>
                          <li className="flex justify-between border-b border-white/5 pb-1.5">
                            <span>"non greasy peptide lip glazes"</span>
                            <span className="text-gold font-mono font-bold">41K/mo</span>
                          </li>
                          <li className="flex justify-between border-b border-white/5 pb-1.5">
                            <span>"best korean sunscreen zero white cast"</span>
                            <span className="text-gold font-mono font-bold">88K/mo</span>
                          </li>
                        </ul>
                      </div>

                      <div className="p-4 bg-white/5 border border-white/5 rounded-2xl space-y-3">
                        <div className="flex items-center gap-2 text-gold">
                          <FileText className="w-4 h-4" />
                          <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                            Blog Title Content Templates
                          </h4>
                        </div>
                        <ul className="space-y-2.5 text-[11px] text-white/70">
                          <li className="flex gap-2">
                            <span className="text-gold shrink-0">•</span>
                            <p><b>"Why Korean Sunscreen is 10 Years Ahead of US SPF Filters"</b> (Link to Glow Guard Sunscreen)</p>
                          </li>
                          <li className="flex gap-2">
                            <span className="text-gold shrink-0">•</span>
                            <p><b>"I Swapped My Routine for Rice Water and Snail Mucin for 14 Days"</b> (Combo offer: Snail Mucin & Rice Toner)</p>
                          </li>
                          <li className="flex gap-2">
                            <span className="text-gold shrink-0">•</span>
                            <p><b>"The Sticky Truth: Lip Oils vs Sticky Lip Glosses Explained"</b> (Link to Peptide Lip Glaze)</p>
                          </li>
                        </ul>
                      </div>
                    </div>

                    <div className="p-4 bg-[#121212] border border-white/5 rounded-2xl flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <CheckCircle2 className="w-5 h-5 text-[#10B981] shrink-0" />
                        <div>
                          <h5 className="text-xs font-bold text-white uppercase tracking-wide">
                            Partnership Campaign Strategy Approved
                          </h5>
                          <p className="text-[10px] text-white/50 leading-relaxed mt-0.5">
                            All search keywords, TikTok ad models, and margin targets are ready for active scaling. Let's make passive income together.
                          </p>
                        </div>
                      </div>
                      <span className="text-[10px] uppercase font-bold text-[#10B981] bg-[#10B981]/10 px-2 py-1 rounded-full font-mono">
                        Ready To Scale
                      </span>
                    </div>

                  </div>
                )}

              </div>
            </div>

            {/* Sticky Action Footer */}
            <div className="p-5 border-t border-white/5 bg-[#0A0A0A] flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-[11px] text-white/40 font-mono">
                <span>© 2026 VELOUR PARTNER CO. • SECURE DROPSHIP PIPELINE</span>
              </div>
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <button
                  onClick={onClose}
                  className="w-full sm:w-auto px-5 py-2.5 bg-white/5 hover:bg-white/10 text-white text-xs uppercase tracking-widest font-semibold rounded-xl border border-white/10 transition-colors cursor-pointer text-center"
                >
                  Close Blueprint
                </button>
                <button
                  onClick={() => {
                    alert("Dropship Strategy Synced! Checkouts will be redirected through wholesale API tunnels.");
                    onClose();
                  }}
                  className="w-full sm:w-auto px-5 py-2.5 bg-gold text-black text-xs uppercase tracking-widest font-extrabold rounded-xl hover:bg-white transition-all cursor-pointer shadow-lg text-center flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  Sync Wholesale API
                </button>
              </div>
            </div>

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
