import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import ProductCard from './components/ProductCard';
import ProductDetailModal from './components/ProductDetailModal';
import CartDrawer from './components/CartDrawer';
import SkincareQuiz from './components/SkincareQuiz';
import CheckoutModal from './components/CheckoutModal';
import DropshipDashboard from './components/DropshipDashboard';
import { products as initialProducts } from './data/products';
import { Product, CartItem, Review } from './types';
import { Sparkles, Heart, Shield, HelpCircle, Truck, RotateCcw, Mail, Instagram, MessageSquare, ArrowRight, Check, X } from 'lucide-react';
import { useCart } from './hooks/useCart';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  // Products state (to allow writing live, persistent mock reviews)
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('velour_products');
    return saved ? JSON.parse(saved) : initialProducts;
  });

  // Save products to local storage whenever they change (e.g. new review)
  useEffect(() => {
    localStorage.setItem('velour_products', JSON.stringify(products));
  }, [products]);

  // Use custom cart hook
  const {
    cart,
    setCart,
    handleAddToCart: baseAddToCart,
    handleUpdateQuantity,
    handleRemoveItem,
    handleClearCart,
  } = useCart();

  // Wishlist state with persistence
  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('velour_wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('velour_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  // UI state managers
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isQuizOpen, setIsQuizOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isDropshipOpen, setIsDropshipOpen] = useState(false);

  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedSkinType, setSelectedSkinType] = useState('All');
  const [selectedConcern, setSelectedConcern] = useState('All');

  // Newsletter state
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  // Scroll to catalog helper
  const exploreCatalog = () => {
    const section = document.getElementById('catalog-section');
    section?.scrollIntoView({ behavior: 'smooth' });
  };

  // Cart operations (wrap base to trigger UI drawers)
  const handleAddToCart = (
    product: Product,
    shade?: { name: string; hex: string },
    size?: string
  ) => {
    baseAddToCart(product, shade, size);
    // Soft trigger drawer open for visual feedback
    setIsCartOpen(true);
  };


  // Wishlist operations
  const toggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const handleMoveToWishlist = (cartItem: CartItem) => {
    toggleWishlist(cartItem.product.id);
    handleRemoveItem(cartItem.id);
  };

  // Add review dynamically to products
  const handleAddReview = (
    productId: string,
    newReview: Omit<Review, 'id' | 'date' | 'verified'>
  ) => {
    setProducts((prevProducts) =>
      prevProducts.map((prod) => {
        if (prod.id === productId) {
          const reviewWithMetadata: Review = {
            ...newReview,
            id: `rev-${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
            verified: true, // Auto-verify in our e-commerce simulation
          };
          const updatedReviews = [reviewWithMetadata, ...prod.reviews];
          // Calculate new average rating
          const avgRating = Number(
            (updatedReviews.reduce((sum, r) => sum + r.rating, 0) / updatedReviews.length).toFixed(1)
          );

          return {
            ...prod,
            reviews: updatedReviews,
            reviewsCount: updatedReviews.length,
            rating: avgRating,
          };
        }
        return prod;
      })
    );

    // Update active product detail modal if open
    setActiveProduct((prevActive) => {
      if (prevActive && prevActive.id === productId) {
        const reviewWithMetadata: Review = {
          ...newReview,
          id: `rev-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          verified: true,
        };
        const updatedReviews = [reviewWithMetadata, ...prevActive.reviews];
        const avgRating = Number(
          (updatedReviews.reduce((sum, r) => sum + r.rating, 0) / updatedReviews.length).toFixed(1)
        );
        return {
          ...prevActive,
          reviews: updatedReviews,
          reviewsCount: updatedReviews.length,
          rating: avgRating,
        };
      }
      return prevActive;
    });
  };

  // Filter logic
  const filteredProducts = products.filter((prod) => {
    const matchesSearch =
      prod.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prod.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prod.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prod.ingredients.some((ing) => ing.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = selectedCategory === 'All' || prod.category === selectedCategory;

    // Secondary Skincare filters
    const matchesSkinType =
      selectedSkinType === 'All' ||
      !prod.skinType ||
      prod.skinType.includes(selectedSkinType as any);

    const matchesConcern =
      selectedConcern === 'All' ||
      !prod.concern ||
      prod.concern.includes(selectedConcern as any);

    return matchesSearch && matchesCategory && matchesSkinType && matchesConcern;
  });

  // Newsletter submit
  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim() && newsletterEmail.includes('@')) {
      setNewsletterSubscribed(true);
      setNewsletterEmail('');
      setTimeout(() => setNewsletterSubscribed(false), 5000);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F5F5F0] font-sans selection:bg-gold/20 selection:text-gold flex flex-col justify-between">
      
      {/* 1. Global Promo Announcement Strip */}
      <div className="bg-[#121212] border-b border-white/5 text-white text-[10px] uppercase tracking-[0.25em] font-semibold text-center py-3 px-4 flex items-center justify-center gap-2">
        <Sparkles className="w-3 h-3 text-gold animate-pulse" />
        <span>Complimentary Worldwide Express Delivery on All Orders Over $75</span>
      </div>

      {/* 2. Primary Navigation */}
      <Navbar
        cartCount={cart.reduce((acc, item) => acc + item.quantity, 0)}
        wishlistCount={wishlist.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenQuiz={() => setIsQuizOpen(true)}
        onOpenDropship={() => setIsDropshipOpen(true)}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        selectedCategory={selectedCategory}
        setSelectedCategory={(cat) => {
          setSelectedCategory(cat);
          // Reset child filters on category shift
          setSelectedSkinType('All');
          setSelectedConcern('All');
        }}
      />

      {/* 3. Hero Brand Presentation */}
      <HeroSection onOpenQuiz={() => setIsQuizOpen(true)} onExploreProducts={exploreCatalog} />

      {/* 4. Trust Pillars & Values Grid */}
      <section className="bg-[#121212]/30 border-y border-white/5 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="space-y-2 flex flex-col items-center">
              <div className="p-3 bg-[#121212] border border-white/5 rounded-full shadow-sm text-white">
                <Truck className="w-5 h-5 text-gold" />
              </div>
              <p className="text-xs font-bold uppercase tracking-widest text-[#F5F5F0]">Elite Courier</p>
              <p className="text-[11px] text-white/50 max-w-[150px]">Priority air cargo with live temperature control.</p>
            </div>
            <div className="space-y-2 flex flex-col items-center">
              <div className="p-3 bg-[#121212] border border-white/5 rounded-full shadow-sm text-white">
                <RotateCcw className="w-5 h-5 text-gold" />
              </div>
              <p className="text-xs font-bold uppercase tracking-widest text-[#F5F5F0]">Flawless Return</p>
              <p className="text-[11px] text-white/50 max-w-[150px]">30-day return policy on all opened products.</p>
            </div>
            <div className="space-y-2 flex flex-col items-center">
              <div className="p-3 bg-[#121212] border border-white/5 rounded-full shadow-sm text-white">
                <Shield className="w-5 h-5 text-gold" />
              </div>
              <p className="text-xs font-bold uppercase tracking-widest text-[#F5F5F0]">Botanical Purity</p>
              <p className="text-[11px] text-white/50 max-w-[150px]">Hypoallergenic, cruelty-free, organic compounds.</p>
            </div>
            <div className="space-y-2 flex flex-col items-center">
              <div className="p-3 bg-[#121212] border border-white/5 rounded-full shadow-sm text-white">
                <Sparkles className="w-5 h-5 text-gold animate-pulse" />
              </div>
              <p className="text-xs font-bold uppercase tracking-widest text-[#F5F5F0]">Clinically Proven</p>
              <p className="text-[11px] text-white/50 max-w-[150px]">Formulations verified by international dermatologists.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Main Catalog & Filters Section */}
      <main id="catalog-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 flex-1 w-full space-y-12">
        
        {/* Dynamic Section Header with Filters */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row items-start md:items-end justify-between gap-6 pb-6 border-b border-white/5"
        >
          <div className="space-y-2">
            <h2 className="text-3xl font-sans font-light tracking-tight text-white">
              The {selectedCategory !== 'All' ? selectedCategory : 'Signature'} Collection
            </h2>
            <p className="text-xs text-white/50 leading-relaxed max-w-md">
              Browse our luxury formulas crafted with active concentrations and exquisite organic ingredients to enhance your beauty routine.
            </p>
          </div>

          {/* Secondary dynamic filter pills for Skincare */}
          {selectedCategory === 'Skincare' && (
            <div className="flex flex-wrap gap-4 w-full md:w-auto">
              {/* Skin Type Filter */}
              <div className="space-y-1.5 flex flex-col">
                <label className="text-[9px] uppercase tracking-wider font-extrabold text-white/40">Skin Type</label>
                <div className="flex gap-1.5">
                  {['All', 'Dry', 'Oily', 'Sensitive', 'Combination'].map((type) => (
                    <button
                      key={type}
                      onClick={() => setSelectedSkinType(type)}
                      className={`px-3 py-1.5 text-[10px] uppercase tracking-wider font-semibold rounded-lg border transition-all cursor-pointer ${
                        selectedSkinType === type
                          ? 'bg-gold text-black border-gold font-extrabold shadow-sm'
                          : 'bg-white/5 text-white/70 border-white/10 hover:border-white/20'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Concern Filter */}
              <div className="space-y-1.5 flex flex-col">
                <label className="text-[9px] uppercase tracking-wider font-extrabold text-white/40">Skin Concern</label>
                <div className="flex gap-1.5">
                  {['All', 'Hydration', 'Anti-aging', 'Brightening', 'Acne'].map((concern) => (
                    <button
                      key={concern}
                      onClick={() => setSelectedConcern(concern)}
                      className={`px-3 py-1.5 text-[10px] uppercase tracking-wider font-semibold rounded-lg border transition-all cursor-pointer ${
                        selectedConcern === concern
                          ? 'bg-gold text-black border-gold font-extrabold shadow-sm'
                          : 'bg-white/5 text-white/70 border-white/10 hover:border-white/20'
                      }`}
                    >
                      {concern}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </motion.div>

        {/* Catalog Grid View */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-20 bg-[#121212] rounded-3xl border border-white/5 flex flex-col items-center justify-center space-y-4">
            <HelpCircle className="w-10 h-10 text-white/30" />
            <div>
              <p className="text-sm font-bold uppercase tracking-wider text-white">No matching formulas found</p>
              <p className="text-xs text-white/50 mt-1">Try resetting your search query or product filters.</p>
            </div>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
                setSelectedSkinType('All');
                setSelectedConcern('All');
              }}
              className="px-5 py-2.5 bg-gold text-black text-[10px] uppercase tracking-widest font-extrabold rounded-xl shadow cursor-pointer hover:bg-white"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <motion.div 
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: '-40px' }}
            variants={{
              hidden: { opacity: 0 },
              show: {
                opacity: 1,
                transition: {
                  staggerChildren: 0.08
                }
              }
            }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                isWishlisted={wishlist.includes(product.id)}
                onToggleWishlist={() => toggleWishlist(product.id)}
                onOpenDetails={() => setActiveProduct(product)}
                onAddToCart={(shade?: { name: string; hex: string }, size?: string) => handleAddToCart(product, shade, size)}
              />
            ))}
          </motion.div>
        )}

        {/* 6. Mid-Page Skin Consultation CTA Banner */}
        <section className="bg-[#121212] rounded-3xl border border-white/5 p-8 sm:p-12 flex flex-col md:flex-row items-center justify-between gap-8 shadow-sm">
          <div className="space-y-3 text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 bg-gold/10 px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-widest text-gold border border-gold/20">
              <Sparkles className="w-3 h-3 text-gold" />
              <span>Complimentary Service</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-sans font-light tracking-tight text-white leading-tight">
              Unsure about your cellular formula?
            </h3>
            <p className="text-white/50 text-xs sm:text-sm max-w-xl leading-relaxed font-light">
              Answer 2 simple questions to analyze your sebum matrix and receive custom laboratory recommendations matched to your dry, oily, or hyper-sensitive skin barrier.
            </p>
          </div>
          <button
            onClick={() => setIsQuizOpen(true)}
            className="w-full md:w-auto bg-gold hover:bg-white text-black text-xs uppercase tracking-widest font-extrabold py-4 px-8 rounded-xl shadow-lg transition-all hover:scale-105 active:scale-95 whitespace-nowrap cursor-pointer"
          >
            Launch Skin Analysis
          </button>
        </section>
      </main>

      {/* 7. Footer Newsletter & Navigation Links */}
      <footer className="bg-[#0D0D0D] text-white border-t border-white/5 pt-16 pb-12 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          {/* Main Footer Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {/* Newsletter Subscription */}
            <div className="space-y-4">
              <h4 className="text-xs uppercase tracking-widest font-extrabold text-gold">Velour Gazette</h4>
              <p className="text-white/50 text-xs leading-relaxed max-w-sm">
                Subscribe to receive private invitations to botanical product launches, expert skin health guides, and luxury member privileges.
              </p>

              {newsletterSubscribed ? (
                <div className="bg-emerald-950/40 text-emerald-300 border border-emerald-500/20 p-3 rounded-xl text-xs font-medium flex items-center gap-2 animate-fadeIn">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Invited! Please check your inbox shortly.</span>
                </div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} className="flex gap-2 max-w-sm">
                  <input
                    type="email"
                    required
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    className="flex-1 bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-white/30 focus:outline-none focus:border-gold transition-all"
                    placeholder="Enter email address"
                  />
                  <button
                    type="submit"
                    className="bg-gold hover:bg-white text-black text-xs uppercase tracking-widest font-bold px-4 rounded-xl transition-all cursor-pointer"
                  >
                    Invite
                  </button>
                </form>
              )}
            </div>

            {/* Quick Links */}
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="text-xs uppercase tracking-widest font-extrabold text-white">The Brand</h4>
                <ul className="space-y-2 text-xs text-white/50 font-semibold">
                  <li><a href="#" className="hover:text-gold transition-colors">Our Botanical Source</a></li>
                  <li><a href="#" className="hover:text-gold transition-colors">Sustainability Guarantee</a></li>
                  <li><a href="#" className="hover:text-gold transition-colors">Clinical Research Labs</a></li>
                  <li><a href="#" className="hover:text-gold transition-colors">Press & Media</a></li>
                </ul>
              </div>
              <div className="space-y-4">
                <h4 className="text-xs uppercase tracking-widest font-extrabold text-white">Guest Care</h4>
                <ul className="space-y-2 text-xs text-white/50 font-semibold">
                  <li><a href="#" className="hover:text-gold transition-colors">Elite Concierge</a></li>
                  <li><a href="#" className="hover:text-gold transition-colors">Track Cargo</a></li>
                  <li><a href="#" className="hover:text-gold transition-colors">Dermatologist Hotline</a></li>
                  <li><a href="#" className="hover:text-gold transition-colors">Store Locator</a></li>
                </ul>
              </div>
            </div>

            {/* Contact / Socials */}
            <div className="space-y-4">
              <h4 className="text-xs uppercase tracking-widest font-extrabold text-white">Velour Atelier</h4>
              <p className="text-white/50 text-xs leading-relaxed">
                Headquarters:<br />
                8 Champs-Élysées, 75008 Paris, France<br />
                Atelier: London · New York · Milan
              </p>
              <div className="flex items-center gap-4 text-white/50 pt-2">
                <a href="#" className="hover:text-white transition-colors" aria-label="Instagram">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href="#" className="hover:text-white transition-colors" aria-label="Reviews">
                  <MessageSquare className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          {/* Sub-Footer Row */}
          <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-center">
            <p className="text-[10px] text-white/30 font-medium">
              © {new Date().getFullYear()} Velour Beauty SAS. All rights reserved. Registered trademark of Velour Cosmetics.
            </p>
            <div className="flex gap-4 text-[10px] text-white/30 font-medium">
              <a href="#" className="hover:text-white">Privacy Policy</a>
              <span>·</span>
              <a href="#" className="hover:text-white">Terms of Luxury Service</a>
              <span>·</span>
              <a href="#" className="hover:text-white">Cookie Matrix</a>
            </div>
          </div>
        </div>
      </footer>

      {/* 8. Interactive Slide-out Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        cartItems={cart}
        onClose={() => setIsCartOpen(false)}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onMoveToWishlist={handleMoveToWishlist}
        onCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />

      {/* 9. Skincare Virtual Analysis Quiz Modal */}
      <AnimatePresence>
        {isQuizOpen && (
          <SkincareQuiz
            products={products}
            onClose={() => setIsQuizOpen(false)}
            onAddToCart={(prod) => {
              handleAddToCart(prod);
              setIsQuizOpen(false);
            }}
          />
        )}
      </AnimatePresence>

      {/* 10. Product Detailed Information Overlay */}
      <AnimatePresence>
        {activeProduct && (
          <ProductDetailModal
            product={activeProduct}
            isWishlisted={wishlist.includes(activeProduct.id)}
            onClose={() => setActiveProduct(null)}
            onToggleWishlist={() => toggleWishlist(activeProduct.id)}
            onAddToCart={(shade, size) => {
              handleAddToCart(activeProduct, shade, size);
              setActiveProduct(null);
            }}
            onAddReview={handleAddReview}
          />
        )}
      </AnimatePresence>

      {/* 11. Multi-step Shipping & Payment Checkout Wizard */}
      <AnimatePresence>
        {isCheckoutOpen && (
          <CheckoutModal
            cartItems={cart}
            onClose={() => setIsCheckoutOpen(false)}
            onClearCart={handleClearCart}
          />
        )}
      </AnimatePresence>

      {/* 12. Wishlist Overlay Modal */}
      <AnimatePresence>
        {isWishlistOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6" id="wishlist-modal-overlay">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-[#0A0A0A]/70 backdrop-blur-md"
              onClick={() => setIsWishlistOpen(false)}
            />
            {/* Content box */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.94, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 15 }}
              transition={{ type: 'spring', stiffness: 350, damping: 28 }}
              className="relative bg-[#0A0A0A] w-full max-w-xl rounded-3xl p-6 sm:p-8 shadow-2xl z-10 border border-white/5 flex flex-col justify-between max-h-[80vh] text-[#F5F5F0]"
            >
              <motion.button
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsWishlistOpen(false)}
                className="absolute top-5 right-5 p-2 bg-white/5 text-white/50 hover:bg-white/10 hover:text-white rounded-full transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </motion.button>
              
              <div className="space-y-4 flex-1 flex flex-col">
                <h3 className="text-lg font-semibold uppercase tracking-wider text-white flex items-center gap-2">
                  <Heart className="w-5 h-5 text-gold fill-gold animate-pulse" />
                  Your Wishlist ({wishlist.length})
                </h3>
                
                <div className="flex-1 overflow-y-auto pr-2 space-y-4">
                  {wishlist.length === 0 ? (
                    <p className="text-white/40 text-xs italic text-center py-12">No products saved to wishlist yet.</p>
                  ) : (
                    <AnimatePresence initial={false}>
                      {products
                        .filter((p) => wishlist.includes(p.id))
                        .map((prod) => (
                          <motion.div 
                            key={prod.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95, height: 0, marginBottom: 0, padding: 0 }}
                            transition={{ duration: 0.2 }}
                            className="flex items-center gap-4 bg-[#121212] p-3 rounded-2xl border border-white/5 overflow-hidden"
                          >
                            <div className="w-16 h-16 rounded-xl overflow-hidden bg-[#151515] shrink-0 border border-white/5">
                              <img src={prod.image} alt={prod.name} className="w-full h-full object-cover" />
                            </div>
                            <div className="flex-1 text-xs">
                              <h4 className="font-bold text-white">{prod.name}</h4>
                              <span className="text-gold font-bold block mt-1 font-mono">${prod.price.toFixed(2)}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <motion.button
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                onClick={() => {
                                  handleAddToCart(prod);
                                  toggleWishlist(prod.id);
                                  setIsWishlistOpen(false);
                                }}
                                className="bg-gold text-black text-[10px] uppercase tracking-wider font-extrabold py-2 px-3 rounded-lg cursor-pointer transition-colors"
                              >
                                Add To Bag
                              </motion.button>
                              <button
                                onClick={() => toggleWishlist(prod.id)}
                                className="text-white/40 hover:text-gold font-bold text-xs p-2 cursor-pointer transition-colors"
                                title="Remove"
                              >
                                Remove
                              </button>
                            </div>
                          </motion.div>
                        ))}
                    </AnimatePresence>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 11. Dropship Strategy & Partner Dashboard */}
      <DropshipDashboard 
        isOpen={isDropshipOpen} 
        onClose={() => setIsDropshipOpen(false)} 
        products={products} 
      />
    </div>
  );
}
